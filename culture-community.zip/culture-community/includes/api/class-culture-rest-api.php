<?php
/**
 * REST API endpoints for check-in and Paystack webhook.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class Culture_REST_API {

    public static function init() {
        add_action( 'rest_api_init', array( __CLASS__, 'register_routes' ) );
        add_action( 'save_post_culture_post', array( 'Culture_Directory', 'recompute_aggregates_on_post_save' ), 10, 2 );
        // Propagate directory entry cover image to all linked community posts whenever the entry is saved.
        add_action( 'save_post_culture_directory', array( 'Culture_Directory', 'sync_linked_post_covers' ), 20, 1 );
        // Award reputation when a community post is created via the REST API.
        add_action( 'rest_after_insert_culture_post', array( __CLASS__, 'handle_community_post_created' ), 10, 3 );
        // Inject platform avatar URL into WP comment REST responses.
        add_filter( 'rest_prepare_comment', array( __CLASS__, 'inject_comment_author_avatar' ), 10, 3 );
    }

    /**
     * Adds `author_custom_avatar` to comment REST responses so the frontend
     * can display the commenter's platform profile photo instead of Gravatar.
     */
    public static function inject_comment_author_avatar( $response, $comment, $request ) {
        $author_id = (int) $comment->user_id;
        if ( $author_id > 0 ) {
            $avatar = get_user_meta( $author_id, '_culture_avatar_url', true );
            if ( $avatar ) {
                $data = $response->get_data();
                $data['author_custom_avatar'] = esc_url_raw( $avatar );
                $response->set_data( $data );
            }
        }
        return $response;
    }

    /**
     * Fires after a culture_post is inserted/updated via the REST API — this
     * covers *every* REST-created culture_post regardless of which route
     * created it (fires on post_type, not on REST base), including the web
     * community composer, which calls native wp/v2/community-posts directly
     * via HTTP Basic Auth and bypasses handle_submit_post() entirely. This is
     * the one place web-created posts get the same side effects
     * handle_submit_post() gives mobile-created posts: gamification award +
     * rep-tier snapshot, @mention notifications, Follow-system "notify on new
     * post", and Hub follower notifications.
     */
    public static function handle_community_post_created( $post, $request, $creating ) {
        if ( ! $creating ) return;
        if ( 'publish' !== $post->post_status ) return;

        // WP's native REST meta handler silently drops underscore-prefixed keys
        // in some server configurations even when show_in_rest + auth_callback
        // are set. Explicitly re-save event/template meta from the raw request
        // so web-composer event posts get the same stored meta as mobile posts.
        $req_meta = $request->get_param( 'meta' );
        if ( is_array( $req_meta ) ) {
            $safe_meta_keys = array(
                '_template_type'               => 'string',
                '_event_date'                  => 'string',
                '_event_end_date'              => 'string',
                '_event_venue'                 => 'string',
                '_event_city'                  => 'string',
                '_event_address'               => 'string',
                '_event_admission'             => 'string',
                '_event_ticket_url'            => 'string',
                '_event_category'              => 'string',
                '_culture_event_organiser_id'  => 'int',
                '_culture_rsvp_enabled'        => 'bool',
                '_culture_rsvp_capacity'       => 'int',
                '_culture_rsvp_price'          => 'int',
                '_culture_rsvp_price_currency' => 'string',
            );
            foreach ( $safe_meta_keys as $key => $type ) {
                if ( ! isset( $req_meta[ $key ] ) ) {
                    continue;
                }
                $val = $req_meta[ $key ];
                if ( $val === '' || $val === false || $val === null ) {
                    continue;
                }
                if ( $type === 'int' ) {
                    $val = (int) $val;
                } elseif ( $type === 'bool' ) {
                    $val = (bool) $val;
                } else {
                    $val = sanitize_text_field( (string) $val );
                }
                update_post_meta( $post->ID, $key, $val );
            }
        }

        $author_id = (int) get_post_meta( $post->ID, 'community_author_id', true );
        if ( ! $author_id ) return;

        $hub_id = (int) get_post_meta( $post->ID, '_hub_id', true );

        if ( class_exists( 'Culture_Gamification' ) ) {
            // Hub posts award the same tier as an ordinary post, just under a
            // distinct action key so Hub-specific analytics can be pulled
            // later — not a separate incentive tier (docs/hubs-plan.md §6.1).
            Culture_Gamification::award_points( $author_id, $hub_id ? 'hub_post_published' : 'community_post' );
            $rep      = Culture_Gamification::get_reputation( $author_id );
            $rep_tier = Culture_Gamification::get_reputation_tier( $rep, $author_id );
            update_post_meta( $post->ID, 'community_author_rep_tier', $rep_tier );
        }

        // Extract @mentions from post content and notify mentioned users.
        $content = wp_strip_all_tags( $post->post_content );
        if ( class_exists( 'Culture_Notifications' ) ) {
            $mention_matches = array();
            preg_match_all( '/@(\w+)/', $content, $mention_matches );
            $mentioned_usernames = array_unique( $mention_matches[1] );
            if ( ! empty( $mentioned_usernames ) ) {
                $author_data = get_userdata( $author_id );
                $author_name = $author_data ? $author_data->display_name : 'Someone';
                $post_slug   = get_post_field( 'post_name', $post->ID );
                foreach ( $mentioned_usernames as $username ) {
                    $mentioned = get_user_by( 'login', $username );
                    if ( $mentioned && (int) $mentioned->ID !== (int) $author_id ) {
                        Culture_Notifications::add(
                            (int) $mentioned->ID,
                            'mention',
                            $author_name . ' mentioned you',
                            wp_trim_words( $content, 15, '…' ),
                            '/community/' . $post_slug,
                            array( 'post_id' => $post->ID, 'author_id' => $author_id )
                        );
                    }
                }
            }
        }

        // Notify followers who opted in to be told when this author posts.
        if ( class_exists( 'Culture_Follows' ) ) {
            Culture_Follows::notify_followers_of_post( $author_id, $post->ID );
        }

        // Notify opted-in Hub followers of a new post (§6.3/§6.4).
        if ( $hub_id && class_exists( 'Culture_Hubs' ) ) {
            Culture_Hubs::notify_followers_of_hub_post( $hub_id, $post->ID, $author_id );
        }

        self::sync_post_side_effects( $post->ID, $author_id );
    }

    /**
     * Fires after any culture_post is created — via the web REST API
     * (handle_community_post_created above) or the mobile submit-post
     * endpoint (Culture_Mobile_API::handle_submit_post) — to sync the
     * author's logbook shelf and portfolio from the post's template data.
     *
     * Shelf upsert: review posts set the linked directory item to "read" +
     * capture the rating. Plain update posts advance to "currently_reading"
     * (never downgrade from "read"). No shelf write happens when there is no
     * _linked_directory_id, so unlinked posts are untouched.
     *
     * Portfolio auto-pin: "project" posts (formerly creative-showcase) are
     * appended to _portfolio_pinned_posts so the Portfolio page reflects
     * every Project post without manual curation.
     */
    public static function sync_post_side_effects( int $post_id, int $author_id ): void {
        $template     = get_post_meta( $post_id, '_template_type', true ) ?: 'post';
        $directory_id = (int) get_post_meta( $post_id, '_linked_directory_id', true );

        // ── Logbook: shelf upsert ─────────────────────────────────────────
        if ( $directory_id > 0 && class_exists( 'Culture_Reading_Tracker' ) ) {
            $review_templates = array( 'book-review', 'film-review', 'music-review', 'food-review', 'hidden-gem' );
            // food-review has three breakdown ratings, not one overall score —
            // we skip a rating write for it rather than averaging client-side.
            $rating_meta = array(
                'book-review'  => '_book_overall_rating',
                'film-review'  => '_film_overall_rating',
                'music-review' => '_music_overall_rating',
                'hidden-gem'   => '_star_rating',
            );

            if ( in_array( $template, $review_templates, true ) ) {
                $rating = null;
                if ( isset( $rating_meta[ $template ] ) ) {
                    $r = (int) get_post_meta( $post_id, $rating_meta[ $template ], true );
                    if ( $r >= 1 && $r <= 5 ) {
                        $rating = $r;
                    }
                }
                Culture_Reading_Tracker::set_shelf_status( $author_id, $directory_id, 'read', $rating );

            } elseif ( 'post' === $template ) {
                // Plain update linked to an item — advance to currently_reading,
                // but never downgrade a row already at "read".
                global $wpdb;
                $existing_status = $wpdb->get_var( $wpdb->prepare(
                    "SELECT status FROM {$wpdb->prefix}culture_reading_shelf
                     WHERE user_id = %d AND directory_id = %d",
                    $author_id, $directory_id
                ) );
                if ( 'read' !== $existing_status ) {
                    Culture_Reading_Tracker::set_shelf_status( $author_id, $directory_id, 'currently_reading' );
                }
            }
        }

        // ── Review cover URL: fill from directory entry if missing ───────
        // Covers cases where the client didn't send a cover URL (e.g. a film
        // already in the directory without an external cover, or an older app
        // version that didn't include the field). Runs for both web and mobile
        // submit paths — idempotent, skipped if the meta is already set.
        $cover_meta_map = array(
            'film-review'  => '_film_cover_url',
            'music-review' => '_music_cover_url',
            'book-review'  => '_book_cover_url',
        );
        if ( $directory_id > 0 && isset( $cover_meta_map[ $template ] ) ) {
            $cover_meta_key = $cover_meta_map[ $template ];
            $existing_cover = get_post_meta( $post_id, $cover_meta_key, true );
            if ( ! $existing_cover ) {
                $cover = get_the_post_thumbnail_url( $directory_id, 'thumbnail' )
                       ?: get_post_meta( $directory_id, '_external_cover_url', true );
                if ( $cover ) {
                    update_post_meta( $post_id, $cover_meta_key, esc_url_raw( $cover ) );
                }
            }
        }

        // ── Portfolio: auto-pin project posts ─────────────────────────────
        if ( 'project' === $template ) {
            $raw = get_user_meta( $author_id, '_portfolio_pinned_posts', true );
            $ids = json_decode( $raw ?: '[]', true ) ?: array();
            $ids = array_values( array_unique( array_map( 'absint', $ids ) ) );
            if ( ! in_array( $post_id, $ids, true ) ) {
                $ids[] = $post_id;
                update_user_meta( $author_id, '_portfolio_pinned_posts', wp_json_encode( $ids ) );
            }
        }
    }

    /**
     * Register REST API routes.
     */
    public static function register_routes() {
        // Paystack webhook endpoint (public, verified by signature).
        register_rest_route( 'culture/v1', '/paystack-webhook', array(
            'methods'             => 'POST',
            'callback'            => array( 'Culture_Paystack', 'handle_webhook' ),
            'permission_callback' => '__return_true',
        ) );

        // Stripe webhook endpoint (public).
        register_rest_route( 'culture/v1', '/stripe-webhook', array(
            'methods'             => 'POST',
            'callback'            => array( 'Culture_Stripe', 'handle_webhook' ),
            'permission_callback' => '__return_true',
        ) );

        // Flutterwave membership subscription webhook endpoint (public, verified by hash).
        register_rest_route( 'culture/v1', '/flutterwave-member-webhook', array(
            'methods'             => 'POST',
            'callback'            => array( 'Culture_Flutterwave_Subscriptions', 'handle_webhook' ),
            'permission_callback' => '__return_true',
        ) );

        // Unified Flutterwave webhook — single URL for all Flutterwave events (RSVPs, services, subscriptions).
        register_rest_route( 'culture/v1', '/flutterwave-webhook', array(
            'methods'             => 'POST',
            'callback'            => array( __CLASS__, 'handle_flutterwave_unified_webhook' ),
            'permission_callback' => '__return_true',
        ) );

        // Newsletter subscribe endpoint (public).
        register_rest_route( 'culture/v1', '/newsletter-subscribe', array(
            'methods'             => 'POST',
            'callback'            => array( __CLASS__, 'handle_newsletter_subscribe' ),
            'permission_callback' => '__return_true',
            'args'                => array(
                'email' => array(
                    'required'          => true,
                    'type'              => 'string',
                    'sanitize_callback' => 'sanitize_email',
                    'validate_callback' => function( $value ) {
                        return is_email( $value );
                    },
                ),
                'name' => array(
                    'required'          => false,
                    'type'              => 'string',
                    'sanitize_callback' => 'sanitize_text_field',
                    'default'           => '',
                ),
                'list' => array(
                    'required'          => false,
                    'type'              => 'string',
                    'sanitize_callback' => 'sanitize_key',
                    'default'           => 'culture-drop',
                ),
                'segment' => array(
                    'required'          => false,
                    'type'              => 'string',
                    'sanitize_callback' => 'sanitize_key',
                    'default'           => '',
                ),
            ),
        ) );

        // Games subscriber list — separate from the GetMeLit newsletter.
        register_rest_route( 'culture/v1', '/games-subscribe', array(
            'methods'             => 'POST',
            'callback'            => array( __CLASS__, 'handle_games_subscribe' ),
            'permission_callback' => '__return_true',
            'args'                => array(
                'email' => array(
                    'required'          => true,
                    'type'              => 'string',
                    'sanitize_callback' => 'sanitize_email',
                    'validate_callback' => function( $value ) {
                        return is_email( $value );
                    },
                ),
            ),
        ) );

        // Newsletter unsubscribe endpoint — called by the Next.js frontend page.
        // Token is verified here so the CMS backend is never exposed to subscribers.
        register_rest_route( 'culture/v1', '/newsletter-unsubscribe', array(
            'methods'             => 'POST',
            'callback'            => array( __CLASS__, 'handle_newsletter_unsubscribe' ),
            'permission_callback' => '__return_true',
            'args'                => array(
                'email' => array(
                    'required'          => true,
                    'type'              => 'string',
                    'sanitize_callback' => 'sanitize_email',
                    'validate_callback' => function( $value ) {
                        return is_email( $value );
                    },
                ),
                'token' => array(
                    'required'          => true,
                    'type'              => 'string',
                    'sanitize_callback' => 'sanitize_text_field',
                ),
                'campaign_id' => array(
                    'required'          => false,
                    'type'              => 'integer',
                    'sanitize_callback' => 'absint',
                ),
            ),
        ) );

        // Front-end (Next.js) draft preview — resolves a signed token from
        // Culture_Preview into the actual draft post/product payload. Public:
        // the token itself is the credential (verified + expiry-checked
        // server-side in Culture_Preview::verify_token()), so no separate
        // api_key_permission secret needs to also live in the Next.js env.
        register_rest_route( 'culture/v1', '/preview/resolve', array(
            'methods'             => 'GET',
            'callback'            => array( __CLASS__, 'handle_preview_resolve' ),
            'permission_callback' => '__return_true',
            'args'                => array(
                'token' => array(
                    'required'          => true,
                    'type'              => 'string',
                    'sanitize_callback' => 'sanitize_text_field',
                ),
            ),
        ) );

        // The Moveee Literary — email/OTP verification (metered soft-paywall +
        // Pro-gating for Literary pieces). See class-culture-literary-access.php.
        register_rest_route( 'culture/v1', '/literary/request-code', array(
            'methods'             => 'POST',
            'callback'            => array( __CLASS__, 'handle_literary_request_code' ),
            'permission_callback' => '__return_true',
            'args'                => array(
                'email' => array(
                    'required'          => true,
                    'type'              => 'string',
                    'sanitize_callback' => 'sanitize_email',
                ),
            ),
        ) );
        register_rest_route( 'culture/v1', '/literary/verify-code', array(
            'methods'             => 'POST',
            'callback'            => array( __CLASS__, 'handle_literary_verify_code' ),
            'permission_callback' => '__return_true',
            'args'                => array(
                'email' => array(
                    'required'          => true,
                    'type'              => 'string',
                    'sanitize_callback' => 'sanitize_email',
                ),
                'code' => array(
                    'required'          => true,
                    'type'              => 'string',
                    'sanitize_callback' => 'sanitize_text_field',
                ),
            ),
        ) );

        // Magic-code sign-in — verifies a code, finds-or-creates an account,
        // subscribes it to a newsletter list, returns the same profile shape
        // as /login. See class-culture-magic-otp.php.
        register_rest_route( 'culture/v1', '/magic-otp/request', array(
            'methods'             => 'POST',
            'callback'            => array( __CLASS__, 'handle_magic_otp_request' ),
            'permission_callback' => '__return_true',
            'args'                => array(
                'email' => array(
                    'required'          => true,
                    'type'              => 'string',
                    'sanitize_callback' => 'sanitize_email',
                ),
            ),
        ) );
        register_rest_route( 'culture/v1', '/magic-otp/verify', array(
            'methods'             => 'POST',
            'callback'            => array( __CLASS__, 'handle_magic_otp_verify' ),
            'permission_callback' => '__return_true',
            'args'                => array(
                'email' => array(
                    'required'          => true,
                    'type'              => 'string',
                    'sanitize_callback' => 'sanitize_email',
                ),
                'code' => array(
                    'required'          => true,
                    'type'              => 'string',
                    'sanitize_callback' => 'sanitize_text_field',
                ),
                'list' => array(
                    'required'          => false,
                    'type'              => 'string',
                    'sanitize_callback' => 'sanitize_title',
                ),
                'referral' => array(
                    'required'          => false,
                    'type'              => 'string',
                    'sanitize_callback' => 'sanitize_key',
                ),
            ),
        ) );

        // Next.js-owned OTP — Next.js generates and verifies the code itself
        // (stored in a signed HttpOnly cookie). These two endpoints are the
        // only WP surface that OTP needs: one to email the code, one to
        // find-or-create the account after Next.js has verified the code.
        register_rest_route( 'culture/v1', '/otp/send-email', array(
            'methods'             => 'POST',
            'callback'            => array( __CLASS__, 'handle_otp_send_email' ),
            'permission_callback' => array( __CLASS__, 'api_key_permission' ),
            'args'                => array(
                'email' => array(
                    'required'          => true,
                    'type'              => 'string',
                    'sanitize_callback' => 'sanitize_email',
                ),
                'code' => array(
                    'required'          => true,
                    'type'              => 'string',
                    'sanitize_callback' => 'sanitize_text_field',
                ),
            ),
        ) );
        register_rest_route( 'culture/v1', '/otp/find-or-create', array(
            'methods'             => 'POST',
            'callback'            => array( __CLASS__, 'handle_otp_find_or_create' ),
            'permission_callback' => array( __CLASS__, 'api_key_permission' ),
            'args'                => array(
                'email'    => array(
                    'required'          => true,
                    'type'              => 'string',
                    'sanitize_callback' => 'sanitize_email',
                ),
                'list'     => array(
                    'required'          => false,
                    'type'              => 'string',
                    // sanitize_title($title, $fallback_title) returns $fallback_title when $title
                    // resolves to ''. WP REST passes $request as arg 2, so wrap to avoid storing
                    // the request object as the sanitized value.
                    'sanitize_callback' => static function( $value ) {
                        return sanitize_title( is_string( $value ) ? $value : '' );
                    },
                ),
                'referral' => array(
                    'required'          => false,
                    'type'              => 'string',
                    'sanitize_callback' => 'sanitize_key',
                ),
            ),
        ) );

        // Login endpoint — validates WP credentials, returns user profile.
        register_rest_route( 'culture/v1', '/login', array(
            'methods'             => 'POST',
            'callback'            => array( __CLASS__, 'handle_login' ),
            'permission_callback' => '__return_true',
            'args'                => array(
                'username' => array(
                    'required'          => true,
                    'type'              => 'string',
                    'sanitize_callback' => 'sanitize_text_field',
                ),
                'password' => array(
                    'required' => true,
                    'type'     => 'string',
                ),
            ),
        ) );

        // Google Sign-In — verifies a Google ID token, finds/creates the WP user, returns profile.
        register_rest_route( 'culture/v1', '/login-google', array(
            'methods'             => 'POST',
            'callback'            => array( __CLASS__, 'handle_login_google' ),
            'permission_callback' => '__return_true',
            'args'                => array(
                'id_token' => array(
                    'required' => true,
                    'type'     => 'string',
                ),
            ),
        ) );

        // Quote creation (logged-in users) — this is the live backend for the
        // composer's own "Quote" template (packages/shared/components/pulse/
        // SubmitPost.tsx posts here directly), not just the retired /quotes
        // archive's own submission modal. Keep it registered.
        register_rest_route( 'culture/v1', '/quotes', array(
            'methods'             => 'POST',
            'callback'            => array( __CLASS__, 'handle_create_quote' ),
            'permission_callback' => array( __CLASS__, 'api_key_permission' ),
            'args'                => array(
                'text'   => array( 'required' => true, 'type' => 'string', 'sanitize_callback' => 'wp_kses_post' ),
                'author' => array( 'required' => true, 'type' => 'string', 'sanitize_callback' => 'sanitize_text_field' ),
                'source' => array( 'required' => false, 'type' => 'string', 'sanitize_callback' => 'sanitize_text_field' ),
                // Optional culture_directory links. Both are additive: the
                // freeform `author`/`source` strings above are still written
                // exactly as before, so every existing reader keeps working
                // whether or not a link was supplied.
                'linked_directory_id'      => array( 'required' => false, 'type' => 'integer', 'sanitize_callback' => 'absint' ),
                'quote_author_directory_id' => array( 'required' => false, 'type' => 'integer', 'sanitize_callback' => 'absint' ),
            ),
        ) );

        // Games — trivia daily cache (same questions for every player each day).
        register_rest_route( 'culture/v1', '/games/trivia-daily', array(
            array(
                'methods'             => 'GET',
                'callback'            => array( __CLASS__, 'handle_get_trivia_daily' ),
                'permission_callback' => '__return_true',
            ),
            array(
                'methods'             => 'POST',
                'callback'            => array( __CLASS__, 'handle_set_trivia_daily' ),
                'permission_callback' => array( __CLASS__, 'api_key_permission' ),
                'args'                => array(
                    'questions' => array( 'required' => true, 'type' => 'array' ),
                ),
            ),
        ) );

        // Games — crossword daily cache (same puzzle for every player each day).
        register_rest_route( 'culture/v1', '/games/crossword-daily', array(
            array(
                'methods'             => 'GET',
                'callback'            => array( __CLASS__, 'handle_get_crossword_daily' ),
                'permission_callback' => '__return_true',
                'args'                => array(
                    'date' => array( 'required' => false, 'type' => 'string', 'sanitize_callback' => 'sanitize_text_field' ),
                ),
            ),
            array(
                'methods'             => 'POST',
                'callback'            => array( __CLASS__, 'handle_set_crossword_daily' ),
                'permission_callback' => array( __CLASS__, 'api_key_permission' ),
                'args'                => array(
                    'date'   => array( 'required' => true, 'type' => 'string', 'sanitize_callback' => 'sanitize_text_field' ),
                    'puzzle' => array( 'required' => true, 'type' => 'object' ),
                ),
            ),
        ) );

        // Games — crossword rotation tracking (no repeat until all shown).
        register_rest_route( 'culture/v1', '/games/crossword-rotation', array(
            array(
                'methods'             => 'GET',
                'callback'            => array( __CLASS__, 'handle_get_crossword_rotation' ),
                'permission_callback' => array( __CLASS__, 'api_key_permission' ),
            ),
            array(
                'methods'             => 'POST',
                'callback'            => array( __CLASS__, 'handle_set_crossword_rotation' ),
                'permission_callback' => array( __CLASS__, 'api_key_permission' ),
                'args'                => array(
                    'index' => array( 'required' => true, 'type' => 'integer' ),
                    'total' => array( 'required' => true, 'type' => 'integer' ),
                ),
            ),
        ) );

        // Quote audit batch — fetch unaudited quotes for the Next.js audit bot.
        register_rest_route( 'culture/v1', '/quotes/audit-batch', array(
            'methods'             => 'GET',
            'callback'            => array( __CLASS__, 'handle_get_audit_batch' ),
            'permission_callback' => array( __CLASS__, 'api_key_permission' ),
            'args'                => array(
                'size' => array(
                    'required'          => false,
                    'type'              => 'integer',
                    'default'           => 20,
                    'sanitize_callback' => 'absint',
                ),
            ),
        ) );

        // Quote audit update — write verdict + optional quarantine from audit bot.
        register_rest_route( 'culture/v1', '/quotes/audit-update', array(
            'methods'             => 'POST',
            'callback'            => array( __CLASS__, 'handle_update_audit_status' ),
            'permission_callback' => array( __CLASS__, 'api_key_permission' ),
            'args'                => array(
                'post_id'      => array( 'required' => true,  'type' => 'integer', 'sanitize_callback' => 'absint' ),
                'audit_status' => array( 'required' => true,  'type' => 'string',  'sanitize_callback' => 'sanitize_key' ),
                'audit_note'   => array( 'required' => false, 'type' => 'string',  'sanitize_callback' => 'sanitize_text_field' ),
                'quarantine'   => array( 'required' => false, 'type' => 'boolean', 'default' => false ),
            ),
        ) );

        // Toggle Post Interactions (Like/Bookmark) for articles and quotes.
        register_rest_route( 'culture/v1', '/user/toggle-interaction', array(
            'methods'             => 'POST',
            'callback'            => array( __CLASS__, 'handle_toggle_interaction' ),
            'permission_callback' => array( __CLASS__, 'api_key_permission' ),
            'args'                => array(
                'user_id' => array( 'required' => true, 'type' => 'integer', 'sanitize_callback' => 'absint' ),
                'post_id' => array( 'required' => true, 'type' => 'integer', 'sanitize_callback' => 'absint' ),
                'type'    => array( 'required' => true, 'type' => 'string' ), // 'like' or 'bookmark'
                'kind'    => array( 'required' => true, 'type' => 'string' ), // 'article' or 'quote'
            ),
        ) );

        // Get all interactions for a user.
        register_rest_route( 'culture/v1', '/user/interactions', array(
            'methods'             => 'GET',
            'callback'            => array( __CLASS__, 'handle_get_interactions' ),
            'permission_callback' => array( __CLASS__, 'api_key_permission' ),
            'args'                => array(
                'user_id' => array( 'required' => true, 'type' => 'integer', 'sanitize_callback' => 'absint' ),
            ),
        ) );

        // Per-user, per-post reaction lookup — lets web's ReactionBar hydrate
        // its initial state from the real server record instead of guessing
        // "not reacted" or relying solely on localStorage. If post_id is
        // omitted, returns the user's whole reaction map.
        register_rest_route( 'culture/v1', '/user/reaction', array(
            'methods'             => 'GET',
            'callback'            => array( __CLASS__, 'handle_get_user_reaction' ),
            'permission_callback' => array( __CLASS__, 'api_key_permission' ),
            'args'                => array(
                'user_id' => array( 'required' => true, 'type' => 'integer', 'sanitize_callback' => 'absint' ),
                'post_id' => array( 'required' => false, 'type' => 'integer', 'sanitize_callback' => 'absint' ),
            ),
        ) );

        register_rest_route( 'culture/v1', '/user/referrals', array(
            'methods'             => 'GET',
            'callback'            => array( __CLASS__, 'handle_get_referrals' ),
            'permission_callback' => array( __CLASS__, 'api_key_permission' ),
            'args'                => array(
                'user_id' => array(
                    'required'          => true,
                    'sanitize_callback' => 'absint',
                ),
            ),
        ) );

        // Registration endpoint for the Next.js frontend.
        register_rest_route( 'culture/v1', '/register', array(
            'methods'             => 'POST',
            'callback'            => array( __CLASS__, 'handle_register' ),
            'permission_callback' => array( __CLASS__, 'api_key_permission' ),
            'args'                => array(
                'username' => array(
                    'required'          => true,
                    'type'              => 'string',
                    'sanitize_callback' => 'sanitize_user',
                ),
                'email' => array(
                    'required'          => true,
                    'type'              => 'string',
                    'sanitize_callback' => 'sanitize_email',
                    'validate_callback' => function( $v ) { return is_email( $v ); },
                ),
                'password' => array(
                    'required' => true,
                    'type'     => 'string',
                ),
                'display_name' => array(
                    'required'          => false,
                    'type'              => 'string',
                    'sanitize_callback' => 'sanitize_text_field',
                ),
                'phone' => array(
                    'required'          => false,
                    'type'              => 'string',
                    'sanitize_callback' => 'sanitize_text_field',
                ),
                'whatsapp' => array(
                    'required'          => false,
                    'type'              => 'string',
                    'sanitize_callback' => 'sanitize_text_field',
                ),
                'tier' => array(
                    'required'          => false,
                    'type'              => 'string',
                    'sanitize_callback' => 'sanitize_key',
                    'default'           => 'citizen',
                ),
                'referral_code' => array(
                    'required'          => false,
                    'type'              => 'string',
                    'sanitize_callback' => 'sanitize_key',
                ),
                'gender' => array(
                    'required'          => false,
                    'type'              => 'string',
                    'sanitize_callback' => 'sanitize_text_field',
                ),
                'date_of_birth' => array(
                    'required'          => false,
                    'type'              => 'string',
                    'sanitize_callback' => 'sanitize_text_field',
                ),
                'nationality' => array(
                    'required'          => false,
                    'type'              => 'string',
                    'sanitize_callback' => 'sanitize_text_field',
                ),
                'country_of_residence' => array(
                    'required'          => false,
                    'type'              => 'string',
                    'sanitize_callback' => 'sanitize_text_field',
                ),
                'city' => array(
                    'required'          => false,
                    'type'              => 'string',
                    'sanitize_callback' => 'sanitize_text_field',
                ),
                'occupation' => array(
                    'required'          => false,
                    'type'              => 'string',
                    'sanitize_callback' => 'sanitize_text_field',
                ),
            ),
        ) );

        // Nominate a member for Culture Icon (Culture Authority tier required).
        register_rest_route( 'culture/v1', '/nominate-icon', array(
            'methods'             => 'POST',
            'callback'            => array( __CLASS__, 'handle_nominate_icon' ),
            'permission_callback' => array( __CLASS__, 'api_key_permission' ),
            'args'                => array(
                'nominator_id' => array( 'required' => true, 'type' => 'integer', 'sanitize_callback' => 'absint' ),
                'nominee_id'   => array( 'required' => true, 'type' => 'integer', 'sanitize_callback' => 'absint' ),
            ),
        ) );

        // Community blocklist — returns admin-configured blocked phrases for the Next.js layer.
        register_rest_route( 'culture/v1', '/community-blocklist', array(
            'methods'             => 'GET',
            'callback'            => array( __CLASS__, 'handle_get_community_blocklist' ),
            'permission_callback' => array( __CLASS__, 'api_key_permission' ),
        ) );

        // Verify email — validates the one-time token sent after registration.
        register_rest_route( 'culture/v1', '/verify-email', array(
            'methods'             => 'POST',
            'callback'            => array( __CLASS__, 'handle_verify_email' ),
            'permission_callback' => array( __CLASS__, 'api_key_permission' ),
            'args'                => array(
                'uid' => array(
                    'required'          => true,
                    'type'              => 'integer',
                    'sanitize_callback' => 'absint',
                ),
                'token' => array(
                    'required'          => true,
                    'type'              => 'string',
                    'sanitize_callback' => 'sanitize_text_field',
                ),
            ),
        ) );

        // Complete profile — saves KYC fields + tier after email verification.
        register_rest_route( 'culture/v1', '/complete-profile', array(
            'methods'             => 'POST',
            'callback'            => array( __CLASS__, 'handle_complete_profile' ),
            'permission_callback' => array( __CLASS__, 'api_key_permission' ),
            'args'                => array(
                'uid' => array(
                    'required'          => true,
                    'type'              => 'integer',
                    'sanitize_callback' => 'absint',
                ),
                'token' => array(
                    'required'          => true,
                    'type'              => 'string',
                    'sanitize_callback' => 'sanitize_text_field',
                ),
                'date_of_birth' => array(
                    'required'          => false,
                    'type'              => 'string',
                    'sanitize_callback' => 'sanitize_text_field',
                ),
                'country_of_residence' => array(
                    'required'          => false,
                    'type'              => 'string',
                    'sanitize_callback' => 'sanitize_text_field',
                ),
                'city' => array(
                    'required'          => false,
                    'type'              => 'string',
                    'sanitize_callback' => 'sanitize_text_field',
                ),
                'occupation' => array(
                    'required'          => false,
                    'type'              => 'string',
                    'sanitize_callback' => 'sanitize_text_field',
                ),
                'tier' => array(
                    'required'          => false,
                    'type'              => 'string',
                    'sanitize_callback' => 'sanitize_key',
                    'default'           => 'citizen',
                ),
                'plan_key' => array(
                    'required'          => false,
                    'type'              => 'string',
                    'sanitize_callback' => 'sanitize_text_field',
                    'default'           => 'monthly_ngn',
                ),
            ),
        ) );

        // Account deletion (web) — request step, called by the Next.js proxy on
        // behalf of a logged-in NextAuth session (explicit user_id, same pattern
        // as every other web-surface endpoint in this file).
        register_rest_route( 'culture/v1', '/account/delete-request', array(
            'methods'             => 'POST',
            'callback'            => array( __CLASS__, 'handle_account_delete_request' ),
            'permission_callback' => array( __CLASS__, 'api_key_permission' ),
            'args'                => array(
                'user_id' => array(
                    'required'          => true,
                    'type'              => 'integer',
                    'sanitize_callback' => 'absint',
                ),
            ),
        ) );

        // Account deletion — confirm step. Reachable from the public
        // /account/delete/confirm page (no login required) since the token
        // itself is the credential — same trust model as verify-email/
        // complete-profile above. The Next.js route that calls this holds the
        // api_key_permission secret server-side; the page itself is public.
        register_rest_route( 'culture/v1', '/account/delete-confirm', array(
            'methods'             => 'POST',
            'callback'            => array( __CLASS__, 'handle_account_delete_confirm' ),
            'permission_callback' => array( __CLASS__, 'api_key_permission' ),
            'args'                => array(
                'uid' => array(
                    'required'          => true,
                    'type'              => 'integer',
                    'sanitize_callback' => 'absint',
                ),
                'token' => array(
                    'required'          => true,
                    'type'              => 'string',
                    'sanitize_callback' => 'sanitize_text_field',
                ),
            ),
        ) );

        // Forgot-password — generates a reset key and emails it.
        register_rest_route( 'culture/v1', '/forgot-password', array(
            'methods'             => 'POST',
            'callback'            => array( __CLASS__, 'handle_forgot_password' ),
            'permission_callback' => '__return_true',
            'args'                => array(
                'email' => array(
                    'required'          => true,
                    'type'              => 'string',
                    'sanitize_callback' => 'sanitize_email',
                    'validate_callback' => function( $v ) { return is_email( $v ); },
                ),
            ),
        ) );

        // Reset-password — validates the key and sets the new password.
        register_rest_route( 'culture/v1', '/reset-password', array(
            'methods'             => 'POST',
            'callback'            => array( __CLASS__, 'handle_reset_password' ),
            'permission_callback' => '__return_true',
            'args'                => array(
                'login' => array(
                    'required'          => true,
                    'type'              => 'string',
                    'sanitize_callback' => 'sanitize_user',
                ),
                'key' => array(
                    'required'          => true,
                    'type'              => 'string',
                    'sanitize_callback' => 'sanitize_text_field',
                ),
                'password' => array(
                    'required' => true,
                    'type'     => 'string',
                ),
            ),
        ) );

        // Update user profile — requires API key auth.
        register_rest_route( 'culture/v1', '/user/update', array(
            'methods'             => 'POST',
            'callback'            => array( __CLASS__, 'handle_update_user_profile' ),
            'permission_callback' => array( __CLASS__, 'api_key_permission' ),
        ) );

        // Get user profile (live data) — requires API key auth.
        register_rest_route( 'culture/v1', '/user/profile', array(
            'methods'             => 'GET',
            'callback'            => array( __CLASS__, 'handle_get_user_profile' ),
            'permission_callback' => array( __CLASS__, 'api_key_permission' ),
            'args'                => array(
                'user_id' => array( 'required' => true, 'type' => 'integer', 'sanitize_callback' => 'absint' ),
            ),
        ) );

        // GET/POST culture/v1/user/directory — read or write Connect directory settings
        register_rest_route( 'culture/v1', '/user/directory', array(
            array(
                'methods'             => 'GET',
                'callback'            => array( __CLASS__, 'handle_get_directory_profile' ),
                'permission_callback' => array( __CLASS__, 'api_key_permission' ),
                'args'                => array(
                    'user_id' => array( 'required' => true, 'sanitize_callback' => 'absint' ),
                ),
            ),
            array(
                'methods'             => 'POST',
                'callback'            => array( __CLASS__, 'handle_save_directory_profile' ),
                'permission_callback' => array( __CLASS__, 'api_key_permission' ),
            ),
        ) );

        // GET culture/v1/members — returns opted-in directory members
        register_rest_route( 'culture/v1', '/members', array(
            'methods'             => 'GET',
            'callback'            => array( __CLASS__, 'handle_get_members_directory' ),
            'permission_callback' => array( __CLASS__, 'api_key_permission' ),
            'args'                => array(
                'directory'  => array( 'default' => '0' ),
                'search'     => array( 'default' => '', 'sanitize_callback' => 'sanitize_text_field' ),
                'discipline' => array( 'default' => '', 'sanitize_callback' => 'sanitize_text_field' ),
                'location'   => array( 'default' => '', 'sanitize_callback' => 'sanitize_text_field' ),
                // region: one of nigeria|ghana|uk|usa|pan-african — a structured
                // alternative to 'location' (which is a raw LIKE match) for the
                // People Near Me page's Location chips. Mirrors the region slugs
                // Culture_Directory::REGION_CITY_KEYWORDS already uses for
                // Discover, though the underlying field/matching differs (see
                // handle_get_members_directory).
                'region'     => array( 'default' => '', 'sanitize_callback' => 'sanitize_text_field' ),
                // sort: name (default, alphabetical) | recent (newest members first)
                'sort'       => array( 'default' => 'name', 'sanitize_callback' => 'sanitize_text_field' ),
                'per_page'   => array( 'default' => 50, 'sanitize_callback' => 'absint' ),
                'offset'     => array( 'default' => 0, 'sanitize_callback' => 'absint' ),
            ),
        ) );

        // Newsletter preferences — GET returns state, POST updates it. Requires API key.
        register_rest_route( 'culture/v1', '/newsletter-preferences', array(
            array(
                'methods'             => 'GET',
                'callback'            => array( __CLASS__, 'handle_get_newsletter_preferences' ),
                'permission_callback' => array( __CLASS__, 'api_key_permission' ),
            ),
            array(
                'methods'             => 'POST',
                'callback'            => array( __CLASS__, 'handle_update_newsletter_preferences' ),
                'permission_callback' => array( __CLASS__, 'api_key_permission' ),
            ),
        ) );

        // Phase 3 — lightweight directory search (public, used by post composer).
        register_rest_route( 'culture/v1', '/directory/search', array(
            'methods'             => 'GET',
            'callback'            => array( 'Culture_Directory', 'handle_search' ),
            'permission_callback' => '__return_true',
            'args'                => array(
                'q'    => array( 'type' => 'string', 'default' => '' ),
                'type' => array( 'type' => 'string', 'default' => '' ),
            ),
        ) );

        // Discover — paginated browse with type/region/sort filters (public, used by Discover screen + filter sheet count).
        register_rest_route( 'culture/v1', '/directory/browse', array(
            'methods'             => 'GET',
            'callback'            => array( 'Culture_Directory', 'handle_browse' ),
            'permission_callback' => '__return_true',
            'args'                => array(
                'q'        => array( 'type' => 'string', 'default' => '' ),
                'type'     => array( 'type' => 'string', 'default' => '' ),
                'region'   => array( 'type' => 'string', 'default' => '' ),
                'sort'     => array( 'type' => 'string', 'default' => 'relevant' ),
                'page'     => array( 'type' => 'integer', 'default' => 1 ),
                'per_page' => array( 'type' => 'integer', 'default' => 20 ),
                'seed'     => array( 'type' => 'integer', 'default' => 0 ),
            ),
        ) );

        // Phase 3 — inline directory stub creation from post composer.
        register_rest_route( 'culture/v1', '/directory/quick-create', array(
            'methods'             => 'POST',
            'callback'            => array( 'Culture_Directory', 'handle_quick_create' ),
            'permission_callback' => array( 'Culture_Directory', 'verify_secret' ),
        ) );

        // Stub enrichment — AI content + image update for inline quick-create stubs.
        register_rest_route( 'culture/v1', '/directory/(?P<id>\d+)/enrich', array(
            'methods'             => 'POST',
            'callback'            => array( 'Culture_Directory', 'handle_enrich_stub' ),
            'permission_callback' => array( 'Culture_Directory', 'verify_secret' ),
            'args'                => array(
                'id' => array( 'type' => 'integer', 'required' => true ),
            ),
        ) );

        // Events organised by a directory entry.
        register_rest_route( 'culture/v1', '/directory/(?P<id>\d+)/events', array(
            'methods'             => 'GET',
            'callback'            => array( 'Culture_Directory', 'handle_directory_events' ),
            'permission_callback' => '__return_true',
            'args'                => array(
                'id' => array( 'required' => true, 'validate_callback' => function( $v ) { return is_numeric( $v ); } ),
            ),
        ) );

        // Phase 3 — community posts linked to a directory entry.
        register_rest_route( 'culture/v1', '/directory/(?P<id>\d+)/posts', array(
            'methods'             => 'GET',
            'callback'            => array( 'Culture_Directory', 'handle_directory_posts' ),
            'permission_callback' => '__return_true',
            'args'                => array(
                'id' => array( 'type' => 'integer', 'required' => true ),
            ),
        ) );

        // Directory Entry submission — requires API key auth.
        register_rest_route( 'culture/v1', '/directory/submit', array(
            'methods'             => 'POST',
            'callback'            => array( 'Culture_Directory', 'handle_submit' ),
            'permission_callback' => array( 'Culture_Directory', 'verify_secret' ),
        ) );

        // Attach a generated image to a directory entry as its featured image.
        register_rest_route( 'culture/v1', '/directory/attach-image', array(
            'methods'             => 'POST',
            'callback'            => array( 'Culture_Directory', 'handle_attach_image' ),
            'permission_callback' => array( 'Culture_Directory', 'verify_secret' ),
        ) );

        // Culture Directory visuals — public, returns media items tagged as directory illustrations.
        register_rest_route( 'culture/v1', '/visuals', array(
            'methods'             => 'GET',
            'callback'            => array( 'Culture_Directory', 'handle_get_visuals' ),
            'permission_callback' => '__return_true',
        ) );

        // Processed seed topics — tracks original topic strings to prevent re-seeding
        // even when Gemini generates the entry with a different title.
        register_rest_route( 'culture/v1', '/directory/processed-topics', array(
            array(
                'methods'             => 'GET',
                'callback'            => array( 'Culture_Directory', 'handle_get_processed_topics' ),
                'permission_callback' => array( 'Culture_Directory', 'verify_secret' ),
            ),
            array(
                'methods'             => 'POST',
                'callback'            => array( 'Culture_Directory', 'handle_post_processed_topics' ),
                'permission_callback' => array( 'Culture_Directory', 'verify_secret' ),
                'args'                => array(
                    'topics' => array(
                        'required' => true,
                        'type'     => 'array',
                        'items'    => array( 'type' => 'string' ),
                    ),
                ),
            ),
        ) );

        // Extra / AI-generated seed topics store.
        register_rest_route( 'culture/v1', '/directory/extra-topics', array(
            array(
                'methods'             => 'GET',
                'callback'            => array( 'Culture_Directory', 'handle_get_extra_topics' ),
                'permission_callback' => array( 'Culture_Directory', 'verify_secret' ),
            ),
            array(
                'methods'             => 'POST',
                'callback'            => array( 'Culture_Directory', 'handle_post_extra_topics' ),
                'permission_callback' => array( 'Culture_Directory', 'verify_secret' ),
                'args'                => array(
                    'topics' => array(
                        'required' => true,
                        'type'     => 'array',
                        'items'    => array( 'type' => 'string' ),
                    ),
                ),
            ),
        ) );

        // Real-data bulk importer's progress state (apps/site/app/api/
        // directory/bulk-seed-real/route.ts) — arbitrary JSON blob, shape
        // owned entirely by the importer.
        register_rest_route( 'culture/v1', '/directory/bulk-seed-state', array(
            array(
                'methods'             => 'GET',
                'callback'            => array( 'Culture_Directory', 'handle_get_bulk_seed_state' ),
                'permission_callback' => array( 'Culture_Directory', 'verify_secret' ),
            ),
            array(
                'methods'             => 'POST',
                'callback'            => array( 'Culture_Directory', 'handle_post_bulk_seed_state' ),
                'permission_callback' => array( 'Culture_Directory', 'verify_secret' ),
            ),
        ) );

        // AI events seeder — create a culture_event post.
        register_rest_route( 'culture/v1', '/events/submit', array(
            'methods'             => 'POST',
            'callback'            => array( __CLASS__, 'handle_create_event' ),
            'permission_callback' => array( __CLASS__, 'api_key_permission' ),
        ) );

        // Backfill image URL on an existing event.
        register_rest_route( 'culture/v1', '/events/update-image', array(
            'methods'             => 'POST',
            'callback'            => array( __CLASS__, 'handle_update_event_image' ),
            'permission_callback' => array( __CLASS__, 'api_key_permission' ),
        ) );

        // List events missing an image (for the backfill tool).
        register_rest_route( 'culture/v1', '/events/missing-images', array(
            'methods'             => 'GET',
            'callback'            => array( __CLASS__, 'handle_list_events_missing_images' ),
            'permission_callback' => array( __CLASS__, 'api_key_permission' ),
        ) );

        // List events whose image is an external URL not hosted on this WP install.
        register_rest_route( 'culture/v1', '/events/external-images', array(
            'methods'             => 'GET',
            'callback'            => array( __CLASS__, 'handle_list_events_external_images' ),
            'permission_callback' => array( __CLASS__, 'api_key_permission' ),
        ) );

        // Article comments — GET (public) and POST (auth/shared secret).
        register_rest_route( 'culture/v1', '/comments', array(
            array(
                'methods'             => 'GET',
                'callback'            => array( __CLASS__, 'handle_get_comments' ),
                'permission_callback' => '__return_true',
                'args'                => array(
                    'post_id' => array( 'required' => true, 'type' => 'integer', 'sanitize_callback' => 'absint' ),
                ),
            ),
            array(
                'methods'             => 'POST',
                'callback'            => array( __CLASS__, 'handle_post_comment' ),
                'permission_callback' => array( __CLASS__, 'api_key_permission' ),
                'args'                => array(
                    'post_id' => array( 'required' => true, 'type' => 'integer', 'sanitize_callback' => 'absint' ),
                    'user_id' => array( 'required' => true, 'type' => 'integer', 'sanitize_callback' => 'absint' ),
                    'content' => array( 'required' => true, 'type' => 'string', 'sanitize_callback' => 'wp_kses_post' ),
                ),
            ),
        ) );

        // Award points — requires API key auth.
        register_rest_route( 'culture/v1', '/points/award', array(
            'methods'             => 'POST',
            'callback'            => array( __CLASS__, 'handle_award_points' ),
            'permission_callback' => array( __CLASS__, 'api_key_permission' ),
            'args'                => array(
                'user_id' => array( 'required' => true, 'type' => 'integer', 'sanitize_callback' => 'absint' ),
                'action'  => array( 'required' => true, 'type' => 'string', 'sanitize_callback' => 'sanitize_key' ),
                'post_id' => array( 'required' => false, 'type' => 'integer', 'sanitize_callback' => 'absint' ),
            ),
        ) );

        // Like toggle — any post type (quotes, magazine articles).
        register_rest_route( 'culture/v1', '/content/like', array(
            'methods'             => 'POST',
            'callback'            => array( __CLASS__, 'handle_toggle_like' ),
            'permission_callback' => array( __CLASS__, 'api_key_permission' ),
            'args'                => array(
                'user_id' => array( 'required' => true, 'type' => 'integer', 'sanitize_callback' => 'absint' ),
                'post_id' => array( 'required' => true, 'type' => 'integer', 'sanitize_callback' => 'absint' ),
            ),
        ) );

        // Multi-type reaction toggle (love/fire/clap) — mirrors mobile's
        // /mobile/community/react, same per-user/per-post/per-type semantics
        // via Culture_Mobile_API::toggle_reaction(). Supersedes /content/like
        // for surfaces that need to know/switch the specific reaction type.
        register_rest_route( 'culture/v1', '/community/react', array(
            'methods'             => 'POST',
            'callback'            => array( __CLASS__, 'handle_react' ),
            'permission_callback' => array( __CLASS__, 'api_key_permission' ),
            'args'                => array(
                'user_id' => array( 'required' => true, 'type' => 'integer', 'sanitize_callback' => 'absint' ),
                'post_id' => array( 'required' => true, 'type' => 'integer', 'sanitize_callback' => 'absint' ),
                'type'    => array( 'default' => 'love', 'type' => 'string', 'sanitize_callback' => 'sanitize_key' ),
            ),
        ) );

        // Article read-complete — awards magazine_read credits once ever per article per user.
        register_rest_route( 'culture/v1', '/articles/read-complete', array(
            'methods'             => 'POST',
            'callback'            => array( __CLASS__, 'handle_article_read_complete' ),
            'permission_callback' => array( __CLASS__, 'api_key_permission' ),
            'args'                => array(
                'user_id' => array( 'required' => true, 'type' => 'integer', 'sanitize_callback' => 'absint' ),
                'post_id' => array( 'required' => true, 'type' => 'integer', 'sanitize_callback' => 'absint' ),
            ),
        ) );

        // Bookmark toggle — any post type.
        register_rest_route( 'culture/v1', '/content/bookmark', array(
            'methods'             => 'POST',
            'callback'            => array( __CLASS__, 'handle_toggle_bookmark' ),
            'permission_callback' => array( __CLASS__, 'api_key_permission' ),
            'args'                => array(
                'user_id' => array( 'required' => true, 'type' => 'integer', 'sanitize_callback' => 'absint' ),
                'post_id' => array( 'required' => true, 'type' => 'integer', 'sanitize_callback' => 'absint' ),
            ),
        ) );

        // User saved content — liked and bookmarked posts.
        register_rest_route( 'culture/v1', '/user/saved', array(
            'methods'             => 'GET',
            'callback'            => array( __CLASS__, 'handle_get_user_saved' ),
            'permission_callback' => array( __CLASS__, 'api_key_permission' ),
            'args'                => array(
                'user_id' => array( 'required' => true, 'type' => 'integer', 'sanitize_callback' => 'absint' ),
            ),
        ) );

        // Track visual download usage (daily limit).
        register_rest_route( 'culture/v1', '/visuals/track-download', array(
            'methods'             => 'POST',
            'callback'            => array( __CLASS__, 'handle_track_visual_download' ),
            'permission_callback' => array( __CLASS__, 'api_key_permission' ),
            'args'                => array(
                'user_id' => array( 'required' => true, 'type' => 'integer', 'sanitize_callback' => 'absint' ),
            ),
        ) );

        // One-time migration: re-type "community" category posts → culture_post CPT.
        register_rest_route( 'culture/v1', '/admin/migrate-community-posts', array(
            'methods'             => 'POST',
            'callback'            => array( __CLASS__, 'handle_migrate_community_posts' ),
            'permission_callback' => array( __CLASS__, 'api_key_permission' ),
        ) );

        // Vendor application — authenticated member applies to become a vendor.
        register_rest_route( 'culture/v1', '/vendor/apply', array(
            'methods'             => 'POST',
            'callback'            => array( __CLASS__, 'handle_vendor_apply' ),
            'permission_callback' => array( __CLASS__, 'api_key_permission' ),
            'args'                => array(
                'user_id'     => array( 'required' => true,  'type' => 'integer', 'sanitize_callback' => 'absint' ),
                'store_name'  => array( 'required' => true,  'type' => 'string',  'sanitize_callback' => 'sanitize_text_field' ),
                'store_url'   => array( 'required' => true,  'type' => 'string',  'sanitize_callback' => 'sanitize_key' ),
                'bio'         => array( 'required' => false, 'type' => 'string',  'sanitize_callback' => 'sanitize_textarea_field', 'default' => '' ),
                'country'     => array( 'required' => false, 'type' => 'string',  'sanitize_callback' => 'sanitize_text_field', 'default' => '' ),
                'category'    => array( 'required' => false, 'type' => 'string',  'sanitize_callback' => 'sanitize_text_field', 'default' => '' ),
                'instagram'   => array( 'required' => false, 'type' => 'string',  'sanitize_callback' => 'sanitize_text_field', 'default' => '' ),
                'website'     => array( 'required' => false, 'type' => 'string',  'sanitize_callback' => 'esc_url_raw', 'default' => '' ),
            ),
        ) );

        // Vendor profile photo — set the store avatar or banner by WP attachment
        // ID (uploaded separately via /api/vendor/upload on the Next.js side,
        // which proxies to the WP media library and returns the attachment ID).
        // Writes into the same _wcfm_vendor_data array WCFM's own dashboard and
        // moveee_vendor_profile_by_id() (moveee-graphql-bridge.php) use, rather
        // than guessing at WCFM's own REST payload shape for image fields.
        register_rest_route( 'culture/v1', '/vendor/profile-image', array(
            'methods'             => 'POST',
            'callback'            => array( __CLASS__, 'handle_set_vendor_profile_image' ),
            'permission_callback' => array( __CLASS__, 'api_key_permission' ),
            'args'                => array(
                'vendor_id'     => array( 'required' => true, 'type' => 'integer', 'sanitize_callback' => 'absint' ),
                'type'          => array( 'required' => true, 'type' => 'string', 'enum' => array( 'avatar', 'banner' ) ),
                'attachment_id' => array( 'required' => true, 'type' => 'integer', 'sanitize_callback' => 'absint' ),
            ),
        ) );

        // Vendor shipping-zone ownership — assign a vendor as the owner of a
        // newly created WooCommerce shipping zone.
        register_rest_route( 'culture/v1', '/vendor/shipping-zone-owner', array(
            'methods'             => 'POST',
            'callback'            => array( __CLASS__, 'handle_assign_shipping_zone_owner' ),
            'permission_callback' => array( __CLASS__, 'api_key_permission' ),
            'args'                => array(
                'zone_id'   => array( 'required' => true, 'type' => 'integer', 'sanitize_callback' => 'absint' ),
                'vendor_id' => array( 'required' => true, 'type' => 'integer', 'sanitize_callback' => 'absint' ),
            ),
        ) );

        // Vendor shipping-zone ownership — look up the owner of a zone, or
        // list all zone IDs owned by a vendor.
        register_rest_route( 'culture/v1', '/vendor/shipping-zone-owner', array(
            'methods'             => 'GET',
            'callback'            => array( __CLASS__, 'handle_get_shipping_zone_owner' ),
            'permission_callback' => array( __CLASS__, 'api_key_permission' ),
            'args'                => array(
                'zone_id'   => array( 'required' => false, 'type' => 'integer', 'sanitize_callback' => 'absint' ),
                'vendor_id' => array( 'required' => false, 'type' => 'integer', 'sanitize_callback' => 'absint' ),
            ),
        ) );

        // Initiate membership upgrade for an existing user.
        register_rest_route( 'culture/v1', '/user/upgrade-init', array(
            'methods'             => 'POST',
            'callback'            => array( __CLASS__, 'handle_upgrade_init' ),
            'permission_callback' => array( __CLASS__, 'api_key_permission' ),
            'args'                => array(
                'user_id' => array( 'required' => true, 'type' => 'integer', 'sanitize_callback' => 'absint' ),
            ),
        ) );

        // Phase 4 — poll voting.
        register_rest_route( 'culture/v1', '/community/poll-vote', array(
            'methods'             => 'POST',
            'callback'            => array( __CLASS__, 'handle_poll_vote' ),
            'permission_callback' => array( __CLASS__, 'api_key_permission' ),
        ) );

        // Track an external link click on a pulse story.
        register_rest_route( 'culture/v1', '/pulse-click', array(
            'methods'             => 'POST',
            'callback'            => array( __CLASS__, 'handle_pulse_click' ),
            'permission_callback' => '__return_true',
            'args'                => array(
                'post_id' => array( 'required' => true, 'type' => 'integer', 'sanitize_callback' => 'absint' ),
            ),
        ) );

        // Phase 5 — public member profile by username.
        register_rest_route( 'culture/v1', '/member/(?P<username>[a-zA-Z0-9_\-]+)', array(
            'methods'             => 'GET',
            'callback'            => array( __CLASS__, 'handle_get_public_profile' ),
            'permission_callback' => '__return_true',
            'args'                => array(
                'username' => array( 'type' => 'string', 'required' => true ),
            ),
        ) );

        // Phase 5 — community posts (filterable by author_id and template_type).
        register_rest_route( 'culture/v1', '/community/posts', array(
            'methods'             => 'GET',
            'callback'            => array( __CLASS__, 'handle_get_community_posts' ),
            'permission_callback' => '__return_true',
            'args'                => array(
                'author_id'     => array( 'type' => 'integer', 'default' => 0 ),
                'template_type' => array( 'type' => 'string',  'default' => '' ),
                'per_page'      => array( 'type' => 'integer', 'default' => 20 ),
                'page'          => array( 'type' => 'integer', 'default' => 1 ),
            ),
        ) );

        // Phase 5 — portfolio (GET + POST). Requires Bearer auth.
        register_rest_route( 'culture/v1', '/user/portfolio', array(
            array(
                'methods'             => 'GET',
                'callback'            => array( __CLASS__, 'handle_get_portfolio' ),
                'permission_callback' => array( __CLASS__, 'api_key_permission' ),
            ),
            array(
                'methods'             => 'POST',
                'callback'            => array( __CLASS__, 'handle_save_portfolio' ),
                'permission_callback' => array( __CLASS__, 'api_key_permission' ),
            ),
        ) );

        register_rest_route( 'culture/v1', '/user/portfolio/pin', array(
            'methods'             => 'POST',
            'callback'            => array( __CLASS__, 'handle_pin_portfolio_post' ),
            'permission_callback' => array( __CLASS__, 'api_key_permission' ),
            'args'                => array(
                'user_id' => array( 'required' => true, 'sanitize_callback' => 'absint' ),
                'post_id' => array( 'required' => true, 'sanitize_callback' => 'absint' ),
                'pinned'  => array( 'default'  => true ),
            ),
        ) );

        // ── Phase 6: Partner Perks & Wallet ──────────────────────────────────

        register_rest_route( 'culture/v1', '/perks', array(
            'methods'             => 'GET',
            'callback'            => array( __CLASS__, 'handle_list_perks' ),
            'permission_callback' => '__return_true',
        ) );

        register_rest_route( 'culture/v1', '/perks/redeem', array(
            'methods'             => 'POST',
            'callback'            => array( __CLASS__, 'handle_redeem_perk' ),
            'permission_callback' => array( __CLASS__, 'api_key_permission' ),
            'args'                => array(
                'user_id'       => array( 'required' => true,  'type' => 'integer', 'sanitize_callback' => 'absint' ),
                'perk_id'       => array( 'required' => true,  'type' => 'integer', 'sanitize_callback' => 'absint' ),
                'step_up_token' => array( 'required' => false, 'type' => 'string',  'sanitize_callback' => 'sanitize_text_field' ),
                'phone'         => array( 'required' => false, 'type' => 'string',  'sanitize_callback' => 'sanitize_text_field' ),
            ),
        ) );

        register_rest_route( 'culture/v1', '/perks/verify', array(
            'methods'             => 'GET',
            'callback'            => array( __CLASS__, 'handle_verify_qr' ),
            'permission_callback' => '__return_true',
            'args'                => array(
                'token' => array( 'required' => true, 'type' => 'string', 'sanitize_callback' => 'sanitize_text_field' ),
            ),
        ) );

        register_rest_route( 'culture/v1', '/wallet/balance', array(
            'methods'             => 'GET',
            'callback'            => array( __CLASS__, 'handle_wallet_balance' ),
            'permission_callback' => array( __CLASS__, 'api_key_permission' ),
            'args'                => array(
                'user_id' => array( 'required' => true, 'type' => 'integer', 'sanitize_callback' => 'absint' ),
            ),
        ) );

        register_rest_route( 'culture/v1', '/wallet/history', array(
            'methods'             => 'GET',
            'callback'            => array( __CLASS__, 'handle_wallet_history' ),
            'permission_callback' => array( __CLASS__, 'api_key_permission' ),
            'args'                => array(
                'user_id'  => array( 'required' => true,  'type' => 'integer', 'sanitize_callback' => 'absint' ),
                'per_page' => array( 'required' => false, 'type' => 'integer', 'default' => 20,  'sanitize_callback' => 'absint' ),
                'page'     => array( 'required' => false, 'type' => 'integer', 'default' => 1,   'sanitize_callback' => 'absint' ),
            ),
        ) );

        register_rest_route( 'culture/v1', '/wallet/cashout', array(
            'methods'             => 'POST',
            'callback'            => array( __CLASS__, 'handle_wallet_cashout' ),
            'permission_callback' => array( __CLASS__, 'api_key_permission' ),
            'args'                => array(
                'user_id'       => array( 'required' => true,  'type' => 'integer', 'sanitize_callback' => 'absint' ),
                'credits'       => array( 'required' => true,  'type' => 'integer', 'sanitize_callback' => 'absint' ),
                'method'        => array( 'required' => true,  'type' => 'string',  'sanitize_callback' => 'sanitize_text_field' ),
                'account_name'  => array( 'required' => true,  'type' => 'string',  'sanitize_callback' => 'sanitize_text_field' ),
                'account_ref'   => array( 'required' => true,  'type' => 'string',  'sanitize_callback' => 'sanitize_text_field' ),
                'currency'      => array( 'required' => false, 'type' => 'string',  'default' => 'GBP', 'sanitize_callback' => 'sanitize_text_field' ),
                'step_up_token' => array( 'required' => false, 'type' => 'string',  'sanitize_callback' => 'sanitize_text_field' ),
            ),
        ) );

        register_rest_route( 'culture/v1', '/admin/cashout-queue', array(
            'methods'             => 'GET',
            'callback'            => array( __CLASS__, 'handle_cashout_queue' ),
            'permission_callback' => array( __CLASS__, 'api_key_permission' ),
            'args'                => array(
                'status' => array( 'required' => false, 'type' => 'string', 'default' => 'pending', 'sanitize_callback' => 'sanitize_key' ),
            ),
        ) );

        register_rest_route( 'culture/v1', '/admin/cashout-approve', array(
            'methods'             => 'POST',
            'callback'            => array( __CLASS__, 'handle_cashout_approve' ),
            'permission_callback' => array( __CLASS__, 'api_key_permission' ),
            'args'                => array(
                'redemption_id' => array( 'required' => true, 'type' => 'integer', 'sanitize_callback' => 'absint' ),
                'admin_id'      => array( 'required' => true, 'type' => 'integer', 'sanitize_callback' => 'absint' ),
            ),
        ) );

        register_rest_route( 'culture/v1', '/admin/cashout-reject', array(
            'methods'             => 'POST',
            'callback'            => array( __CLASS__, 'handle_cashout_reject' ),
            'permission_callback' => array( __CLASS__, 'api_key_permission' ),
            'args'                => array(
                'redemption_id' => array( 'required' => true, 'type' => 'integer', 'sanitize_callback' => 'absint' ),
                'admin_id'      => array( 'required' => true, 'type' => 'integer', 'sanitize_callback' => 'absint' ),
                'reason'        => array( 'required' => false, 'type' => 'string', 'default' => '', 'sanitize_callback' => 'sanitize_text_field' ),
            ),
        ) );

        register_rest_route( 'culture/v1', '/admin/perks', array(
            array(
                'methods'             => 'GET',
                'callback'            => array( __CLASS__, 'handle_admin_list_perks' ),
                'permission_callback' => array( __CLASS__, 'api_key_permission' ),
            ),
            array(
                'methods'             => 'POST',
                'callback'            => array( __CLASS__, 'handle_admin_create_perk' ),
                'permission_callback' => array( __CLASS__, 'api_key_permission' ),
            ),
        ) );

        register_rest_route( 'culture/v1', '/admin/perks/(?P<id>\d+)', array(
            array(
                'methods'             => 'PUT',
                'callback'            => array( __CLASS__, 'handle_admin_update_perk' ),
                'permission_callback' => array( __CLASS__, 'api_key_permission' ),
            ),
            array(
                'methods'             => 'DELETE',
                'callback'            => array( __CLASS__, 'handle_admin_delete_perk' ),
                'permission_callback' => array( __CLASS__, 'api_key_permission' ),
            ),
        ) );

        register_rest_route( 'culture/v1', '/user/redemptions', array(
            'methods'             => 'GET',
            'callback'            => array( __CLASS__, 'handle_user_redemptions' ),
            'permission_callback' => array( __CLASS__, 'api_key_permission' ),
            'args'                => array(
                'user_id' => array( 'required' => true,  'type' => 'integer', 'sanitize_callback' => 'absint' ),
                'status'  => array( 'required' => false, 'type' => 'string', 'sanitize_callback' => 'sanitize_key' ),
            ),
        ) );

        // Passkey endpoints.
        register_rest_route( 'culture/v1', '/passkey/register-options', array(
            'methods'             => 'POST',
            'callback'            => array( __CLASS__, 'handle_passkey_register_options' ),
            'permission_callback' => array( __CLASS__, 'api_key_permission' ),
        ) );
        register_rest_route( 'culture/v1', '/passkey/register-verify', array(
            'methods'             => 'POST',
            'callback'            => array( __CLASS__, 'handle_passkey_register_verify' ),
            'permission_callback' => array( __CLASS__, 'api_key_permission' ),
        ) );
        register_rest_route( 'culture/v1', '/passkey/login-options', array(
            'methods'             => 'POST',
            'callback'            => array( __CLASS__, 'handle_passkey_login_options' ),
            'permission_callback' => '__return_true',
        ) );
        register_rest_route( 'culture/v1', '/passkey/login-verify', array(
            'methods'             => 'POST',
            'callback'            => array( __CLASS__, 'handle_passkey_login_verify' ),
            'permission_callback' => '__return_true',
        ) );
        register_rest_route( 'culture/v1', '/passkey/exchange-token', array(
            'methods'             => 'POST',
            'callback'            => array( __CLASS__, 'handle_passkey_exchange_token' ),
            'permission_callback' => '__return_true',
        ) );
        register_rest_route( 'culture/v1', '/passkey/step-up', array(
            'methods'             => 'POST',
            'callback'            => array( __CLASS__, 'handle_passkey_step_up' ),
            'permission_callback' => array( __CLASS__, 'api_key_permission' ),
        ) );
        register_rest_route( 'culture/v1', '/passkey/step-up-verify', array(
            'methods'             => 'POST',
            'callback'            => array( __CLASS__, 'handle_passkey_step_up_verify' ),
            'permission_callback' => array( __CLASS__, 'api_key_permission' ),
        ) );
        register_rest_route( 'culture/v1', '/passkey/list', array(
            'methods'             => 'GET',
            'callback'            => array( __CLASS__, 'handle_passkey_list' ),
            'permission_callback' => array( __CLASS__, 'api_key_permission' ),
        ) );
        register_rest_route( 'culture/v1', '/passkey/delete', array(
            'methods'             => 'DELETE',
            'callback'            => array( __CLASS__, 'handle_passkey_delete' ),
            'permission_callback' => array( __CLASS__, 'api_key_permission' ),
        ) );

        // Notification endpoints.
        register_rest_route( 'culture/v1', '/notifications', array(
            'methods'             => 'GET',
            'callback'            => array( __CLASS__, 'handle_get_notifications' ),
            'permission_callback' => array( __CLASS__, 'api_key_permission' ),
            'args'                => array(
                'user_id' => array( 'required' => true, 'type' => 'integer', 'sanitize_callback' => 'absint' ),
                'limit'   => array( 'required' => false, 'type' => 'integer', 'default' => 30 ),
                'offset'  => array( 'required' => false, 'type' => 'integer', 'default' => 0 ),
            ),
        ) );
        register_rest_route( 'culture/v1', '/notifications/count', array(
            'methods'             => 'GET',
            'callback'            => array( __CLASS__, 'handle_notification_count' ),
            'permission_callback' => array( __CLASS__, 'api_key_permission' ),
            'args'                => array(
                'user_id' => array( 'required' => true, 'type' => 'integer', 'sanitize_callback' => 'absint' ),
            ),
        ) );
        register_rest_route( 'culture/v1', '/notifications/read', array(
            'methods'             => 'POST',
            'callback'            => array( __CLASS__, 'handle_mark_notifications_read' ),
            'permission_callback' => array( __CLASS__, 'api_key_permission' ),
        ) );
        register_rest_route( 'culture/v1', '/notifications/preferences', array(
            array(
                'methods'             => 'GET',
                'callback'            => array( __CLASS__, 'handle_get_notification_prefs' ),
                'permission_callback' => array( __CLASS__, 'api_key_permission' ),
                'args'                => array(
                    'user_id' => array( 'required' => true, 'type' => 'integer', 'sanitize_callback' => 'absint' ),
                ),
            ),
            array(
                'methods'             => 'POST',
                'callback'            => array( __CLASS__, 'handle_set_notification_prefs' ),
                'permission_callback' => array( __CLASS__, 'api_key_permission' ),
                'args'                => array(
                    'user_id' => array( 'required' => true, 'type' => 'integer', 'sanitize_callback' => 'absint' ),
                ),
            ),
        ) );

        // Follow system (web — API key, explicit user_id).
        register_rest_route( 'culture/v1', '/follow', array(
            'methods'             => 'POST',
            'callback'            => array( __CLASS__, 'handle_follow_member' ),
            'permission_callback' => array( __CLASS__, 'api_key_permission' ),
            'args'                => array(
                'user_id'      => array( 'required' => true, 'type' => 'integer', 'sanitize_callback' => 'absint' ),
                'target_id'    => array( 'required' => true, 'type' => 'integer', 'sanitize_callback' => 'absint' ),
                'notify_posts' => array( 'default' => false ),
            ),
        ) );
        register_rest_route( 'culture/v1', '/unfollow', array(
            'methods'             => 'POST',
            'callback'            => array( __CLASS__, 'handle_unfollow_member' ),
            'permission_callback' => array( __CLASS__, 'api_key_permission' ),
            'args'                => array(
                'user_id'   => array( 'required' => true, 'type' => 'integer', 'sanitize_callback' => 'absint' ),
                'target_id' => array( 'required' => true, 'type' => 'integer', 'sanitize_callback' => 'absint' ),
            ),
        ) );
        register_rest_route( 'culture/v1', '/follow/notify', array(
            'methods'             => 'POST',
            'callback'            => array( __CLASS__, 'handle_set_follow_notify' ),
            'permission_callback' => array( __CLASS__, 'api_key_permission' ),
            'args'                => array(
                'user_id'      => array( 'required' => true, 'type' => 'integer', 'sanitize_callback' => 'absint' ),
                'target_id'    => array( 'required' => true, 'type' => 'integer', 'sanitize_callback' => 'absint' ),
                'notify_posts' => array( 'default' => false ),
            ),
        ) );
        register_rest_route( 'culture/v1', '/follow/status', array(
            'methods'             => 'GET',
            'callback'            => array( __CLASS__, 'handle_follow_status' ),
            'permission_callback' => array( __CLASS__, 'api_key_permission' ),
            'args'                => array(
                'user_id'   => array( 'required' => true, 'type' => 'integer', 'sanitize_callback' => 'absint' ),
                'target_id' => array( 'required' => true, 'type' => 'integer', 'sanitize_callback' => 'absint' ),
            ),
        ) );
        register_rest_route( 'culture/v1', '/follow/following', array(
            'methods'             => 'GET',
            'callback'            => array( __CLASS__, 'handle_get_following_usernames' ),
            'permission_callback' => array( __CLASS__, 'api_key_permission' ),
            'args'                => array(
                'user_id' => array( 'required' => true, 'type' => 'integer', 'sanitize_callback' => 'absint' ),
            ),
        ) );

        // Community event RSVPs (web — API key, explicit user_id param).
        // Mirrors /mobile/community/event/* in class-culture-mobile-api.php.
        register_rest_route( 'culture/v1', '/community/event/rsvp', array(
            'methods'             => 'POST',
            'callback'            => array( __CLASS__, 'handle_community_event_rsvp' ),
            'permission_callback' => array( __CLASS__, 'api_key_permission' ),
            'args'                => array(
                'user_id' => array( 'required' => true, 'type' => 'integer', 'sanitize_callback' => 'absint' ),
                'post_id' => array( 'required' => true, 'type' => 'integer', 'sanitize_callback' => 'absint' ),
            ),
        ) );
        register_rest_route( 'culture/v1', '/community/event/rsvp-cancel', array(
            'methods'             => 'POST',
            'callback'            => array( __CLASS__, 'handle_community_event_rsvp_cancel' ),
            'permission_callback' => array( __CLASS__, 'api_key_permission' ),
            'args'                => array(
                'user_id' => array( 'required' => true, 'type' => 'integer', 'sanitize_callback' => 'absint' ),
                'post_id' => array( 'required' => true, 'type' => 'integer', 'sanitize_callback' => 'absint' ),
            ),
        ) );
        register_rest_route( 'culture/v1', '/community/event/rsvp-status', array(
            'methods'             => 'GET',
            'callback'            => array( __CLASS__, 'handle_community_event_rsvp_status' ),
            'permission_callback' => array( __CLASS__, 'api_key_permission' ),
            'args'                => array(
                'user_id' => array( 'required' => true, 'type' => 'integer', 'sanitize_callback' => 'absint' ),
                'post_id' => array( 'required' => true, 'type' => 'integer', 'sanitize_callback' => 'absint' ),
            ),
        ) );
        register_rest_route( 'culture/v1', '/community/event/attendees', array(
            'methods'             => 'GET',
            'callback'            => array( __CLASS__, 'handle_community_event_attendees' ),
            'permission_callback' => array( __CLASS__, 'api_key_permission' ),
            'args'                => array(
                'user_id' => array( 'required' => true, 'type' => 'integer', 'sanitize_callback' => 'absint' ),
                'post_id' => array( 'required' => true, 'type' => 'integer', 'sanitize_callback' => 'absint' ),
            ),
        ) );
        register_rest_route( 'culture/v1', '/community/my-events', array(
            'methods'             => 'GET',
            'callback'            => array( __CLASS__, 'handle_community_my_events' ),
            'permission_callback' => array( __CLASS__, 'api_key_permission' ),
            'args'                => array(
                'user_id' => array( 'required' => true, 'type' => 'integer', 'sanitize_callback' => 'absint' ),
            ),
        ) );

        // Creator earnings ledger — event creators viewing their balance + history.
        register_rest_route( 'culture/v1', '/creator/earnings', array(
            'methods'             => 'GET',
            'callback'            => array( __CLASS__, 'handle_creator_earnings' ),
            'permission_callback' => array( __CLASS__, 'api_key_permission' ),
            'args'                => array(
                'user_id' => array( 'required' => true, 'type' => 'integer', 'sanitize_callback' => 'absint' ),
                'page'    => array( 'required' => false, 'type' => 'integer', 'sanitize_callback' => 'absint', 'default' => 1 ),
            ),
        ) );

        register_rest_route( 'culture/v1', '/creator/payout-request', array(
            'methods'             => 'POST',
            'callback'            => array( __CLASS__, 'handle_creator_payout_request' ),
            'permission_callback' => array( __CLASS__, 'api_key_permission' ),
            'args'                => array(
                'user_id'        => array( 'required' => true, 'type' => 'integer', 'sanitize_callback' => 'absint' ),
                'amount'         => array( 'required' => true, 'type' => 'number' ),
                'currency'       => array( 'required' => true, 'type' => 'string', 'sanitize_callback' => 'sanitize_text_field' ),
                'bank_code'      => array( 'required' => true, 'type' => 'string', 'sanitize_callback' => 'sanitize_text_field' ),
                'account_number' => array( 'required' => true, 'type' => 'string', 'sanitize_callback' => 'sanitize_text_field' ),
                'account_name'   => array( 'required' => true, 'type' => 'string', 'sanitize_callback' => 'sanitize_text_field' ),
            ),
        ) );

        // Admin: list and process creator payout requests.
        register_rest_route( 'culture/v1', '/admin/creator-payouts', array(
            'methods'             => 'GET',
            'callback'            => array( __CLASS__, 'handle_admin_creator_payouts' ),
            'permission_callback' => array( __CLASS__, 'api_key_permission' ),
            'args'                => array(
                'status'  => array( 'required' => false, 'type' => 'string', 'default' => '' ),
                'page'    => array( 'required' => false, 'type' => 'integer', 'sanitize_callback' => 'absint', 'default' => 1 ),
            ),
        ) );

        register_rest_route( 'culture/v1', '/admin/creator-payouts/(?P<id>\d+)/process', array(
            'methods'             => 'POST',
            'callback'            => array( __CLASS__, 'handle_admin_process_payout' ),
            'permission_callback' => array( __CLASS__, 'api_key_permission' ),
        ) );

        // Reading Tracker shelves (web — API key, explicit user_id param).
        // Mirrors /mobile/reading/* in class-culture-mobile-api.php.
        register_rest_route( 'culture/v1', '/reading/shelf', array(
            'methods'             => 'POST',
            'callback'            => array( __CLASS__, 'handle_reading_shelf_set' ),
            'permission_callback' => array( __CLASS__, 'api_key_permission' ),
            'args'                => array(
                'user_id'      => array( 'required' => true, 'type' => 'integer', 'sanitize_callback' => 'absint' ),
                'directory_id' => array( 'required' => true, 'type' => 'integer', 'sanitize_callback' => 'absint' ),
                'status'       => array( 'required' => true, 'type' => 'string' ),
                // Optional: set a rating in the same write. Deliberately not
                // absint'd — the handler needs to tell "absent" from "0"
                // (clear the rating), and absint would collapse both to 0.
                'rating'       => array( 'required' => false, 'type' => 'integer' ),
            ),
        ) );
        // Rate without authoring a review. Mirrors /mobile/reading/rating.
        register_rest_route( 'culture/v1', '/reading/rating', array(
            'methods'             => 'POST',
            'callback'            => array( __CLASS__, 'handle_reading_rating_set' ),
            'permission_callback' => array( __CLASS__, 'api_key_permission' ),
            'args'                => array(
                'user_id'      => array( 'required' => true, 'type' => 'integer', 'sanitize_callback' => 'absint' ),
                'directory_id' => array( 'required' => true, 'type' => 'integer', 'sanitize_callback' => 'absint' ),
                'rating'       => array( 'required' => true, 'type' => 'integer' ),
            ),
        ) );
        register_rest_route( 'culture/v1', '/reading/shelf', array(
            'methods'             => 'DELETE',
            'callback'            => array( __CLASS__, 'handle_reading_shelf_remove' ),
            'permission_callback' => array( __CLASS__, 'api_key_permission' ),
            'args'                => array(
                'user_id'      => array( 'required' => true, 'type' => 'integer', 'sanitize_callback' => 'absint' ),
                'directory_id' => array( 'required' => true, 'type' => 'integer', 'sanitize_callback' => 'absint' ),
            ),
        ) );
        register_rest_route( 'culture/v1', '/reading/shelf', array(
            'methods'             => 'GET',
            'callback'            => array( __CLASS__, 'handle_reading_shelf_get' ),
            'permission_callback' => array( __CLASS__, 'api_key_permission' ),
            'args'                => array(
                'user_id'  => array( 'required' => true, 'type' => 'integer', 'sanitize_callback' => 'absint' ),
                'status'   => array( 'required' => true, 'type' => 'string' ),
                'page'     => array( 'type' => 'integer', 'sanitize_callback' => 'absint' ),
                'per_page' => array( 'type' => 'integer', 'sanitize_callback' => 'absint' ),
                'medium'   => array( 'type' => 'string', 'sanitize_callback' => 'sanitize_key' ),
            ),
        ) );
        // One entry's own log state, for a directory entry page's shelf
        // control. user_id is optional here, unlike every other reading/*
        // read: a logged-out visitor still needs the medium back so the page
        // can label the buttons before there is anything to label from.
        register_rest_route( 'culture/v1', '/reading/entry', array(
            'methods'             => 'GET',
            'callback'            => array( __CLASS__, 'handle_reading_entry_get' ),
            'permission_callback' => array( __CLASS__, 'api_key_permission' ),
            'args'                => array(
                'user_id'      => array( 'type' => 'integer', 'sanitize_callback' => 'absint' ),
                'directory_id' => array( 'required' => true, 'type' => 'integer', 'sanitize_callback' => 'absint' ),
            ),
        ) );
        register_rest_route( 'culture/v1', '/reading/shelf/counts', array(
            'methods'             => 'GET',
            'callback'            => array( __CLASS__, 'handle_reading_shelf_counts' ),
            'permission_callback' => array( __CLASS__, 'api_key_permission' ),
            'args'                => array(
                'user_id' => array( 'required' => true, 'type' => 'integer', 'sanitize_callback' => 'absint' ),
            ),
        ) );

        // Reading goal (web — API key, explicit user_id param). Mirrors
        // /mobile/reading/goal in class-culture-mobile-api.php.
        register_rest_route( 'culture/v1', '/reading/goal', array(
            'methods'             => 'GET',
            'callback'            => array( __CLASS__, 'handle_reading_goal_get' ),
            'permission_callback' => array( __CLASS__, 'api_key_permission' ),
            'args'                => array(
                'user_id' => array( 'required' => true, 'type' => 'integer', 'sanitize_callback' => 'absint' ),
                'year'    => array( 'type' => 'integer', 'sanitize_callback' => 'absint' ),
            ),
        ) );
        register_rest_route( 'culture/v1', '/reading/goal', array(
            'methods'             => 'POST',
            'callback'            => array( __CLASS__, 'handle_reading_goal_set' ),
            'permission_callback' => array( __CLASS__, 'api_key_permission' ),
            'args'                => array(
                'user_id'      => array( 'required' => true, 'type' => 'integer', 'sanitize_callback' => 'absint' ),
                'year'         => array( 'type' => 'integer', 'sanitize_callback' => 'absint' ),
                'target_books' => array( 'required' => true, 'type' => 'integer', 'sanitize_callback' => 'absint' ),
            ),
        ) );

        // Reading Tracker mood/pace (web — API key, explicit user_id param).
        // Mirrors /mobile/reading/mood-vote in class-culture-mobile-api.php.
        register_rest_route( 'culture/v1', '/reading/mood-vote', array(
            'methods'             => 'POST',
            'callback'            => array( __CLASS__, 'handle_reading_mood_vote' ),
            'permission_callback' => array( __CLASS__, 'api_key_permission' ),
            'args'                => array(
                'user_id'      => array( 'required' => true, 'type' => 'integer', 'sanitize_callback' => 'absint' ),
                'directory_id' => array( 'required' => true, 'type' => 'integer', 'sanitize_callback' => 'absint' ),
                'moods'        => array( 'type' => 'array' ),
                'pace'         => array( 'required' => true, 'type' => 'string' ),
            ),
        ) );
        register_rest_route( 'culture/v1', '/reading/mood-pace', array(
            'methods'             => 'GET',
            'callback'            => array( __CLASS__, 'handle_reading_mood_pace_get' ),
            'permission_callback' => '__return_true',
            'args'                => array(
                'directory_id' => array( 'required' => true, 'type' => 'integer', 'sanitize_callback' => 'absint' ),
                'user_id'      => array( 'type' => 'integer', 'sanitize_callback' => 'absint' ),
            ),
        ) );

        // Reading Tracker stats dashboard (web — API key, explicit user_id
        // param). Mirrors /mobile/reading/stats in class-culture-mobile-api.php.
        register_rest_route( 'culture/v1', '/reading/stats', array(
            'methods'             => 'GET',
            'callback'            => array( __CLASS__, 'handle_reading_stats_get' ),
            'permission_callback' => array( __CLASS__, 'api_key_permission' ),
            'args'                => array(
                'user_id' => array( 'required' => true, 'type' => 'integer', 'sanitize_callback' => 'absint' ),
                'year'    => array( 'type' => 'integer', 'sanitize_callback' => 'absint' ),
            ),
        ) );

        // Saved lines + social proof / also-logged (web — API key, explicit
        // user_id param). Mirrors /mobile/reading/saved-lines etc. in
        // class-culture-mobile-api.php.
        register_rest_route( 'culture/v1', '/reading/saved-lines', array(
            'methods'             => 'POST',
            'callback'            => array( __CLASS__, 'handle_reading_save_line' ),
            'permission_callback' => array( __CLASS__, 'api_key_permission' ),
            'args'                => array(
                'user_id'         => array( 'required' => true, 'type' => 'integer', 'sanitize_callback' => 'absint' ),
                'directory_id'    => array( 'required' => true, 'type' => 'integer', 'sanitize_callback' => 'absint' ),
                'line_text'       => array( 'required' => true, 'type' => 'string' ),
                'source_context'  => array( 'type' => 'string' ),
            ),
        ) );
        register_rest_route( 'culture/v1', '/reading/saved-lines', array(
            'methods'             => 'GET',
            'callback'            => array( __CLASS__, 'handle_reading_get_saved_lines' ),
            'permission_callback' => array( __CLASS__, 'api_key_permission' ),
            'args'                => array(
                'directory_id' => array( 'required' => true, 'type' => 'integer', 'sanitize_callback' => 'absint' ),
                'user_id'      => array( 'type' => 'integer', 'sanitize_callback' => 'absint' ),
            ),
        ) );
        register_rest_route( 'culture/v1', '/reading/saved-lines/(?P<id>\d+)', array(
            'methods'             => 'DELETE',
            'callback'            => array( __CLASS__, 'handle_reading_delete_saved_line' ),
            'permission_callback' => array( __CLASS__, 'api_key_permission' ),
            'args'                => array(
                'user_id' => array( 'required' => true, 'type' => 'integer', 'sanitize_callback' => 'absint' ),
            ),
        ) );
        register_rest_route( 'culture/v1', '/reading/social-proof', array(
            'methods'             => 'GET',
            'callback'            => array( __CLASS__, 'handle_reading_social_proof' ),
            'permission_callback' => array( __CLASS__, 'api_key_permission' ),
            'args'                => array(
                'user_id'      => array( 'required' => true, 'type' => 'integer', 'sanitize_callback' => 'absint' ),
                'directory_id' => array( 'required' => true, 'type' => 'integer', 'sanitize_callback' => 'absint' ),
            ),
        ) );
        register_rest_route( 'culture/v1', '/reading/also-logged', array(
            'methods'             => 'GET',
            'callback'            => array( __CLASS__, 'handle_reading_also_logged' ),
            'permission_callback' => '__return_true',
            'args'                => array(
                'directory_id' => array( 'required' => true, 'type' => 'integer', 'sanitize_callback' => 'absint' ),
            ),
        ) );
        register_rest_route( 'culture/v1', '/reading/following-activity', array(
            'methods'             => 'GET',
            'callback'            => array( __CLASS__, 'handle_reading_following_activity' ),
            'permission_callback' => array( __CLASS__, 'api_key_permission' ),
            'args'                => array(
                'user_id' => array( 'required' => true, 'type' => 'integer', 'sanitize_callback' => 'absint' ),
                'limit'   => array( 'type' => 'integer', 'sanitize_callback' => 'absint' ),
            ),
        ) );

        // Stoop proximity banner (web — API key, explicit user_id param).
        // Mirrors /mobile/reading/place-proximity — see
        // Culture_Reading_Tracker::get_place_proximity(). No web capture UI
        // exists yet (location is only ever set from mobile GPS), but the
        // read side is mirrored per this file's usual convention.
        register_rest_route( 'culture/v1', '/reading/place-proximity', array(
            'methods'             => 'GET',
            'callback'            => array( __CLASS__, 'handle_reading_place_proximity' ),
            'permission_callback' => array( __CLASS__, 'api_key_permission' ),
            'args'                => array(
                'user_id'      => array( 'required' => true, 'type' => 'integer', 'sanitize_callback' => 'absint' ),
                'directory_id' => array( 'required' => true, 'type' => 'integer', 'sanitize_callback' => 'absint' ),
            ),
        ) );

        // Member geolocation (web — API key, explicit user_id param).
        // Mirrors /mobile/me/location — see class-culture-geolocation.php.
        register_rest_route( 'culture/v1', '/me/location', array(
            'methods'             => 'POST',
            'callback'            => array( __CLASS__, 'handle_set_location' ),
            'permission_callback' => array( __CLASS__, 'api_key_permission' ),
            'args'                => array(
                'user_id' => array( 'required' => true, 'type' => 'integer', 'sanitize_callback' => 'absint' ),
                'lat'     => array( 'required' => true, 'type' => 'number' ),
                'lng'     => array( 'required' => true, 'type' => 'number' ),
            ),
        ) );
        register_rest_route( 'culture/v1', '/me/location', array(
            'methods'             => 'GET',
            'callback'            => array( __CLASS__, 'handle_get_location' ),
            'permission_callback' => array( __CLASS__, 'api_key_permission' ),
            'args'                => array(
                'user_id' => array( 'required' => true, 'type' => 'integer', 'sanitize_callback' => 'absint' ),
            ),
        ) );
        register_rest_route( 'culture/v1', '/me/location', array(
            'methods'             => 'DELETE',
            'callback'            => array( __CLASS__, 'handle_clear_location' ),
            'permission_callback' => array( __CLASS__, 'api_key_permission' ),
            'args'                => array(
                'user_id' => array( 'required' => true, 'type' => 'integer', 'sanitize_callback' => 'absint' ),
            ),
        ) );

        // Directory-entry follows (web — API key, explicit user_id param).
        // Mirrors /mobile/directory/{id}/follow* — see class-culture-directory-follows.php.
        register_rest_route( 'culture/v1', '/directory/(?P<id>\d+)/follow', array(
            'methods'             => 'POST',
            'callback'            => array( __CLASS__, 'handle_directory_follow' ),
            'permission_callback' => array( __CLASS__, 'api_key_permission' ),
            'args'                => array(
                'user_id' => array( 'required' => true, 'type' => 'integer', 'sanitize_callback' => 'absint' ),
            ),
        ) );
        register_rest_route( 'culture/v1', '/directory/(?P<id>\d+)/unfollow', array(
            'methods'             => 'POST',
            'callback'            => array( __CLASS__, 'handle_directory_unfollow' ),
            'permission_callback' => array( __CLASS__, 'api_key_permission' ),
            'args'                => array(
                'user_id' => array( 'required' => true, 'type' => 'integer', 'sanitize_callback' => 'absint' ),
            ),
        ) );
        register_rest_route( 'culture/v1', '/directory/(?P<id>\d+)/follow-status', array(
            'methods'             => 'GET',
            'callback'            => array( __CLASS__, 'handle_directory_follow_status' ),
            'permission_callback' => array( __CLASS__, 'api_key_permission' ),
            'args'                => array(
                'user_id' => array( 'required' => true, 'type' => 'integer', 'sanitize_callback' => 'absint' ),
            ),
        ) );

        // Stoop clusters (web — API key, explicit user_id param).
        // Mirrors /mobile/cluster/* in class-culture-mobile-api.php.
        register_rest_route( 'culture/v1', '/cluster/create', array(
            'methods'             => 'POST',
            'callback'            => array( __CLASS__, 'handle_cluster_create' ),
            'permission_callback' => array( __CLASS__, 'api_key_permission' ),
            'args'                => array(
                'user_id' => array( 'required' => true, 'type' => 'integer', 'sanitize_callback' => 'absint' ),
                'name'    => array( 'required' => true, 'type' => 'string' ),
            ),
        ) );

        register_rest_route( 'culture/v1', '/cluster/discover', array(
            'methods'             => 'GET',
            'callback'            => array( __CLASS__, 'handle_cluster_discover' ),
            'permission_callback' => array( __CLASS__, 'api_key_permission' ),
        ) );

        register_rest_route( 'culture/v1', '/cluster/my-clusters', array(
            'methods'             => 'GET',
            'callback'            => array( __CLASS__, 'handle_cluster_my_clusters' ),
            'permission_callback' => array( __CLASS__, 'api_key_permission' ),
            'args'                => array(
                'user_id' => array( 'required' => true, 'type' => 'integer', 'sanitize_callback' => 'absint' ),
            ),
        ) );

        register_rest_route( 'culture/v1', '/cluster/(?P<id>\d+)', array(
            'methods'             => 'GET',
            'callback'            => array( __CLASS__, 'handle_cluster_get' ),
            'permission_callback' => array( __CLASS__, 'api_key_permission' ),
        ) );

        register_rest_route( 'culture/v1', '/cluster/(?P<id>\d+)/status', array(
            'methods'             => 'GET',
            'callback'            => array( __CLASS__, 'handle_cluster_status' ),
            'permission_callback' => array( __CLASS__, 'api_key_permission' ),
            'args'                => array(
                'user_id' => array( 'required' => true, 'type' => 'integer', 'sanitize_callback' => 'absint' ),
            ),
        ) );

        register_rest_route( 'culture/v1', '/cluster/(?P<id>\d+)/join', array(
            'methods'             => 'POST',
            'callback'            => array( __CLASS__, 'handle_cluster_join' ),
            'permission_callback' => array( __CLASS__, 'api_key_permission' ),
            'args'                => array(
                'user_id' => array( 'required' => true, 'type' => 'integer', 'sanitize_callback' => 'absint' ),
            ),
        ) );

        register_rest_route( 'culture/v1', '/cluster/(?P<id>\d+)/leave', array(
            'methods'             => 'POST',
            'callback'            => array( __CLASS__, 'handle_cluster_leave' ),
            'permission_callback' => array( __CLASS__, 'api_key_permission' ),
            'args'                => array(
                'user_id' => array( 'required' => true, 'type' => 'integer', 'sanitize_callback' => 'absint' ),
            ),
        ) );

        // Phase 2 — host mechanisms (election only; appointment is admin-only,
        // no member-facing endpoint).
        register_rest_route( 'culture/v1', '/cluster/(?P<id>\d+)/election/start', array(
            'methods'             => 'POST',
            'callback'            => array( __CLASS__, 'handle_cluster_election_start' ),
            'permission_callback' => array( __CLASS__, 'api_key_permission' ),
            'args'                => array(
                'user_id' => array( 'required' => true, 'type' => 'integer', 'sanitize_callback' => 'absint' ),
            ),
        ) );

        register_rest_route( 'culture/v1', '/cluster/(?P<id>\d+)/election/vote', array(
            'methods'             => 'POST',
            'callback'            => array( __CLASS__, 'handle_cluster_election_vote' ),
            'permission_callback' => array( __CLASS__, 'api_key_permission' ),
            'args'                => array(
                'user_id'      => array( 'required' => true, 'type' => 'integer', 'sanitize_callback' => 'absint' ),
                'candidate_id' => array( 'required' => true, 'type' => 'integer', 'sanitize_callback' => 'absint' ),
            ),
        ) );

        register_rest_route( 'culture/v1', '/cluster/(?P<id>\d+)/election', array(
            'methods'             => 'GET',
            'callback'            => array( __CLASS__, 'handle_cluster_election_status' ),
            'permission_callback' => array( __CLASS__, 'api_key_permission' ),
            'args'                => array(
                'user_id' => array( 'type' => 'integer', 'sanitize_callback' => 'absint' ),
            ),
        ) );

        // Phase 3 — check-in & attendance (QR + manual host fallback). Mirrors
        // /mobile/cluster/{id}/... in class-culture-mobile-api.php.
        register_rest_route( 'culture/v1', '/cluster/(?P<id>\d+)/members', array(
            'methods'             => 'GET',
            'callback'            => array( __CLASS__, 'handle_cluster_members' ),
            'permission_callback' => array( __CLASS__, 'api_key_permission' ),
        ) );

        register_rest_route( 'culture/v1', '/cluster/(?P<id>\d+)/host-qr', array(
            'methods'             => 'GET',
            'callback'            => array( __CLASS__, 'handle_cluster_host_qr' ),
            'permission_callback' => array( __CLASS__, 'api_key_permission' ),
            'args'                => array(
                'user_id' => array( 'required' => true, 'type' => 'integer', 'sanitize_callback' => 'absint' ),
            ),
        ) );

        register_rest_route( 'culture/v1', '/cluster/(?P<id>\d+)/checkin', array(
            'methods'             => 'POST',
            'callback'            => array( __CLASS__, 'handle_cluster_checkin' ),
            'permission_callback' => array( __CLASS__, 'api_key_permission' ),
            'args'                => array(
                'user_id'      => array( 'required' => true, 'type' => 'integer', 'sanitize_callback' => 'absint' ),
                'meeting_date' => array( 'required' => true, 'type' => 'string' ),
                'expires_at'   => array( 'required' => true, 'type' => 'integer', 'sanitize_callback' => 'absint' ),
                'token'        => array( 'required' => true, 'type' => 'string' ),
            ),
        ) );

        register_rest_route( 'culture/v1', '/cluster/(?P<id>\d+)/checkin-manual', array(
            'methods'             => 'POST',
            'callback'            => array( __CLASS__, 'handle_cluster_checkin_manual' ),
            'permission_callback' => array( __CLASS__, 'api_key_permission' ),
            'args'                => array(
                'user_id'        => array( 'required' => true, 'type' => 'integer', 'sanitize_callback' => 'absint' ),
                'member_user_id' => array( 'required' => true, 'type' => 'integer', 'sanitize_callback' => 'absint' ),
            ),
        ) );

        register_rest_route( 'culture/v1', '/cluster/(?P<id>\d+)/attendance', array(
            'methods'             => 'GET',
            'callback'            => array( __CLASS__, 'handle_cluster_attendance' ),
            'permission_callback' => array( __CLASS__, 'api_key_permission' ),
            'args'                => array(
                'user_id' => array( 'required' => true, 'type' => 'integer', 'sanitize_callback' => 'absint' ),
            ),
        ) );

        // Cluster agenda: upcoming gatherings + RSVPs (October 2026).
        register_rest_route( 'culture/v1', '/cluster/(?P<id>\d+)/agenda', array(
            'methods'             => 'GET',
            'callback'            => array( __CLASS__, 'handle_cluster_agenda_get' ),
            'permission_callback' => array( __CLASS__, 'api_key_permission' ),
            'args'                => array(
                'user_id' => array( 'required' => true, 'type' => 'integer', 'sanitize_callback' => 'absint' ),
            ),
        ) );
        register_rest_route( 'culture/v1', '/cluster/(?P<id>\d+)/agenda', array(
            'methods'             => 'POST',
            'callback'            => array( __CLASS__, 'handle_cluster_agenda_post' ),
            'permission_callback' => array( __CLASS__, 'api_key_permission' ),
            'args'                => array(
                'user_id' => array( 'required' => true, 'type' => 'integer', 'sanitize_callback' => 'absint' ),
            ),
        ) );

        // Cluster chatter (direct, replaces companion-Hub approach).
        register_rest_route( 'culture/v1', '/cluster/(?P<id>\d+)/chatter', array(
            'methods'             => 'GET',
            'callback'            => array( __CLASS__, 'handle_cluster_chatter_get' ),
            'permission_callback' => array( __CLASS__, 'api_key_permission' ),
            'args'                => array(
                'user_id' => array( 'required' => false, 'type' => 'integer', 'sanitize_callback' => 'absint' ),
                'since'   => array( 'required' => false, 'type' => 'integer', 'sanitize_callback' => 'absint' ),
            ),
        ) );
        register_rest_route( 'culture/v1', '/cluster/(?P<id>\d+)/chatter', array(
            'methods'             => 'POST',
            'callback'            => array( __CLASS__, 'handle_cluster_chatter_post' ),
            'permission_callback' => array( __CLASS__, 'api_key_permission' ),
            'args'                => array(
                'user_id' => array( 'required' => true, 'type' => 'integer', 'sanitize_callback' => 'absint' ),
            ),
        ) );

        // Cluster photo upload (cover + avatar/display photo, host only).
        register_rest_route( 'culture/v1', '/cluster/(?P<id>\d+)/photo', array(
            'methods'             => 'POST',
            'callback'            => array( __CLASS__, 'handle_cluster_photo_upload' ),
            'permission_callback' => array( __CLASS__, 'api_key_permission' ),
            'args'                => array(
                'user_id' => array( 'required' => true, 'type' => 'integer', 'sanitize_callback' => 'absint' ),
            ),
        ) );

        // Hubs (web — API key, explicit user_id param).
        // Mirrors /mobile/hub/* in class-culture-mobile-api.php.
        register_rest_route( 'culture/v1', '/hub/create', array(
            'methods'             => 'POST',
            'callback'            => array( __CLASS__, 'handle_hub_create' ),
            'permission_callback' => array( __CLASS__, 'api_key_permission' ),
            'args'                => array(
                'user_id'     => array( 'required' => true, 'type' => 'integer', 'sanitize_callback' => 'absint' ),
                'name'        => array( 'required' => true, 'type' => 'string' ),
                'description' => array( 'required' => true, 'type' => 'string' ),
            ),
        ) );

        register_rest_route( 'culture/v1', '/hub/discover', array(
            'methods'             => 'GET',
            'callback'            => array( __CLASS__, 'handle_hub_discover' ),
            'permission_callback' => '__return_true',
        ) );

        register_rest_route( 'culture/v1', '/hub/my-hubs', array(
            'methods'             => 'GET',
            'callback'            => array( __CLASS__, 'handle_hub_my_hubs' ),
            'permission_callback' => array( __CLASS__, 'api_key_permission' ),
            'args'                => array(
                'user_id' => array( 'required' => true, 'type' => 'integer', 'sanitize_callback' => 'absint' ),
            ),
        ) );

        register_rest_route( 'culture/v1', '/hub/slug/(?P<slug>[a-zA-Z0-9-]+)', array(
            'methods'             => 'GET',
            'callback'            => array( __CLASS__, 'handle_hub_get_by_slug' ),
            'permission_callback' => '__return_true',
        ) );

        register_rest_route( 'culture/v1', '/hub/(?P<id>\d+)', array(
            'methods'             => 'GET',
            'callback'            => array( __CLASS__, 'handle_hub_get' ),
            'permission_callback' => '__return_true',
        ) );

        // Owner-only update (name/description/cover/allowed-templates).
        register_rest_route( 'culture/v1', '/hub/(?P<id>\d+)', array(
            'methods'             => 'PATCH',
            'callback'            => array( __CLASS__, 'handle_hub_update' ),
            'permission_callback' => array( __CLASS__, 'api_key_permission' ),
            'args'                => array(
                'user_id' => array( 'required' => true, 'type' => 'integer', 'sanitize_callback' => 'absint' ),
            ),
        ) );

        // Owner-only archive.
        register_rest_route( 'culture/v1', '/hub/(?P<id>\d+)', array(
            'methods'             => 'DELETE',
            'callback'            => array( __CLASS__, 'handle_hub_archive' ),
            'permission_callback' => array( __CLASS__, 'api_key_permission' ),
            'args'                => array(
                'user_id' => array( 'required' => true, 'type' => 'integer', 'sanitize_callback' => 'absint' ),
            ),
        ) );

        register_rest_route( 'culture/v1', '/hub/(?P<id>\d+)/status', array(
            'methods'             => 'GET',
            'callback'            => array( __CLASS__, 'handle_hub_status' ),
            'permission_callback' => array( __CLASS__, 'api_key_permission' ),
            'args'                => array(
                'user_id' => array( 'required' => true, 'type' => 'integer', 'sanitize_callback' => 'absint' ),
            ),
        ) );

        register_rest_route( 'culture/v1', '/hub/(?P<id>\d+)/join', array(
            'methods'             => 'POST',
            'callback'            => array( __CLASS__, 'handle_hub_join' ),
            'permission_callback' => array( __CLASS__, 'api_key_permission' ),
            'args'                => array(
                'user_id' => array( 'required' => true, 'type' => 'integer', 'sanitize_callback' => 'absint' ),
            ),
        ) );

        register_rest_route( 'culture/v1', '/hub/(?P<id>\d+)/leave', array(
            'methods'             => 'POST',
            'callback'            => array( __CLASS__, 'handle_hub_leave' ),
            'permission_callback' => array( __CLASS__, 'api_key_permission' ),
            'args'                => array(
                'user_id' => array( 'required' => true, 'type' => 'integer', 'sanitize_callback' => 'absint' ),
            ),
        ) );

        register_rest_route( 'culture/v1', '/hub/(?P<id>\d+)/follow', array(
            'methods'             => 'POST',
            'callback'            => array( __CLASS__, 'handle_hub_follow' ),
            'permission_callback' => array( __CLASS__, 'api_key_permission' ),
            'args'                => array(
                'user_id'      => array( 'required' => true, 'type' => 'integer', 'sanitize_callback' => 'absint' ),
                'notify_posts' => array( 'type' => 'boolean' ),
            ),
        ) );

        register_rest_route( 'culture/v1', '/hub/(?P<id>\d+)/unfollow', array(
            'methods'             => 'POST',
            'callback'            => array( __CLASS__, 'handle_hub_unfollow' ),
            'permission_callback' => array( __CLASS__, 'api_key_permission' ),
            'args'                => array(
                'user_id' => array( 'required' => true, 'type' => 'integer', 'sanitize_callback' => 'absint' ),
            ),
        ) );

        // Paginated Hub-scoped post feed (Phase 2, docs/hubs-plan.md §4.4).
        // Public — viewer_id is optional, only used to personalise liked/reaction state.
        register_rest_route( 'culture/v1', '/hub/(?P<id>\d+)/feed', array(
            'methods'             => 'GET',
            'callback'            => array( __CLASS__, 'handle_hub_feed' ),
            'permission_callback' => '__return_true',
        ) );

        // Literati Connect events near this Hub's topic (Stoop/Literati
        // Connect surfacing — see Culture_Hubs::get_related_events()).
        register_rest_route( 'culture/v1', '/hub/(?P<id>\d+)/related-events', array(
            'methods'             => 'GET',
            'callback'            => array( __CLASS__, 'handle_hub_related_events' ),
            'permission_callback' => '__return_true',
        ) );

        // For You Hub candidate pool (docs/hubs-plan.md §4.5). Public —
        // user_id is optional, only used to personalise liked/reaction state.
        register_rest_route( 'culture/v1', '/hub/for-you-candidates', array(
            'methods'             => 'GET',
            'callback'            => array( __CLASS__, 'handle_hub_for_you_candidates' ),
            'permission_callback' => '__return_true',
        ) );

        // Moderation (Phase 3, docs/hubs-plan.md §7.1).
        register_rest_route( 'culture/v1', '/hub/(?P<id>\d+)/members', array(
            'methods'             => 'GET',
            'callback'            => array( __CLASS__, 'handle_hub_members' ),
            'permission_callback' => '__return_true',
        ) );

        register_rest_route( 'culture/v1', '/hub/(?P<id>\d+)/mods', array(
            'methods'             => 'POST',
            'callback'            => array( __CLASS__, 'handle_hub_appoint_mod' ),
            'permission_callback' => array( __CLASS__, 'api_key_permission' ),
            'args'                => array(
                'user_id'        => array( 'required' => true, 'type' => 'integer', 'sanitize_callback' => 'absint' ),
                'target_user_id' => array( 'required' => true, 'type' => 'integer', 'sanitize_callback' => 'absint' ),
            ),
        ) );

        register_rest_route( 'culture/v1', '/hub/(?P<id>\d+)/mods/(?P<userId>\d+)', array(
            'methods'             => 'DELETE',
            'callback'            => array( __CLASS__, 'handle_hub_remove_mod' ),
            'permission_callback' => array( __CLASS__, 'api_key_permission' ),
            'args'                => array(
                'user_id' => array( 'required' => true, 'type' => 'integer', 'sanitize_callback' => 'absint' ),
            ),
        ) );

        register_rest_route( 'culture/v1', '/hub/(?P<id>\d+)/members/(?P<userId>\d+)', array(
            'methods'             => 'DELETE',
            'callback'            => array( __CLASS__, 'handle_hub_remove_member' ),
            'permission_callback' => array( __CLASS__, 'api_key_permission' ),
            'args'                => array(
                'user_id' => array( 'required' => true, 'type' => 'integer', 'sanitize_callback' => 'absint' ),
            ),
        ) );

        register_rest_route( 'culture/v1', '/hub/(?P<id>\d+)/pin', array(
            'methods'             => 'POST',
            'callback'            => array( __CLASS__, 'handle_hub_pin_post' ),
            'permission_callback' => array( __CLASS__, 'api_key_permission' ),
            'args'                => array(
                'user_id' => array( 'required' => true, 'type' => 'integer', 'sanitize_callback' => 'absint' ),
                'post_id' => array( 'required' => true, 'type' => 'integer', 'sanitize_callback' => 'absint' ),
            ),
        ) );

        register_rest_route( 'culture/v1', '/hub/(?P<id>\d+)/pin', array(
            'methods'             => 'DELETE',
            'callback'            => array( __CLASS__, 'handle_hub_unpin_post' ),
            'permission_callback' => array( __CLASS__, 'api_key_permission' ),
            'args'                => array(
                'user_id' => array( 'required' => true, 'type' => 'integer', 'sanitize_callback' => 'absint' ),
            ),
        ) );

        register_rest_route( 'culture/v1', '/hub/(?P<id>\d+)/remove-post', array(
            'methods'             => 'POST',
            'callback'            => array( __CLASS__, 'handle_hub_remove_post' ),
            'permission_callback' => array( __CLASS__, 'api_key_permission' ),
            'args'                => array(
                'user_id' => array( 'required' => true, 'type' => 'integer', 'sanitize_callback' => 'absint' ),
                'post_id' => array( 'required' => true, 'type' => 'integer', 'sanitize_callback' => 'absint' ),
            ),
        ) );


        // Analytics
        register_rest_route( 'culture/v1', '/member/analytics', array(
            'methods'             => 'GET',
            'callback'            => array( __CLASS__, 'handle_member_analytics' ),
            'permission_callback' => array( __CLASS__, 'api_key_permission' ),
            'args'                => array(
                'user_id' => array( 'required' => true, 'type' => 'integer', 'sanitize_callback' => 'absint' ),
            ),
        ) );

        // Phase 9 — Event QR check-in.
        register_rest_route( 'culture/v1', '/events/(?P<id>\d+)/generate-checkin-token', array(
            'methods'             => 'POST',
            'callback'            => array( __CLASS__, 'handle_generate_checkin_token' ),
            'permission_callback' => array( __CLASS__, 'api_key_permission' ),
        ) );
        register_rest_route( 'culture/v1', '/events/self-checkin', array(
            'methods'             => 'POST',
            'callback'            => array( __CLASS__, 'handle_self_checkin' ),
            'permission_callback' => array( __CLASS__, 'api_key_permission' ),
        ) );

        // Reloadly — instant rewards (airtime + gift cards).
        register_rest_route( 'culture/v1', '/reloadly/operators', array(
            'methods'             => 'GET',
            'callback'            => array( __CLASS__, 'handle_reloadly_operators' ),
            'permission_callback' => array( __CLASS__, 'api_key_permission' ),
            'args'                => array(
                'country_iso' => array( 'required' => true, 'type' => 'string', 'sanitize_callback' => 'sanitize_text_field' ),
                'phone'       => array( 'required' => false, 'type' => 'string', 'sanitize_callback' => 'sanitize_text_field' ),
            ),
        ) );
        register_rest_route( 'culture/v1', '/reloadly/products', array(
            'methods'             => 'GET',
            'callback'            => array( __CLASS__, 'handle_reloadly_products' ),
            'permission_callback' => array( __CLASS__, 'api_key_permission' ),
            'args'                => array(
                'country_iso' => array( 'required' => true, 'type' => 'string', 'sanitize_callback' => 'sanitize_text_field' ),
            ),
        ) );
        register_rest_route( 'culture/v1', '/reloadly/topup', array(
            'methods'             => 'POST',
            'callback'            => array( __CLASS__, 'handle_reloadly_topup' ),
            'permission_callback' => array( __CLASS__, 'api_key_permission' ),
        ) );
        register_rest_route( 'culture/v1', '/reloadly/giftcard', array(
            'methods'             => 'POST',
            'callback'            => array( __CLASS__, 'handle_reloadly_giftcard' ),
            'permission_callback' => array( __CLASS__, 'api_key_permission' ),
        ) );
    }

    /* ——————————————————————————————————————
     *  Passkey handlers
     * —————————————————————————————————————— */

    public static function handle_passkey_register_options( $request ) {
        $user_id = (int) $request->get_param( 'user_id' );
        if ( ! $user_id || ! get_userdata( $user_id ) ) {
            return new WP_Error( 'invalid_user', 'Invalid user.', array( 'status' => 400 ) );
        }
        return rest_ensure_response( Culture_WebAuthn::get_register_options( $user_id ) );
    }

    public static function handle_passkey_register_verify( $request ) {
        $user_id = (int) $request->get_param( 'user_id' );
        $resp    = $request->get_param( 'response' );
        if ( ! $user_id || ! is_array( $resp ) ) {
            return new WP_Error( 'bad_request', 'Missing user_id or response.', array( 'status' => 400 ) );
        }
        $result = Culture_WebAuthn::verify_register( $user_id, $resp );
        if ( ! $result['success'] ) {
            return new WP_Error( 'passkey_error', $result['error'], array( 'status' => 400 ) );
        }
        return rest_ensure_response( $result );
    }

    public static function handle_passkey_login_options( $request ) {
        $user_id = $request->get_param( 'user_id' ) ? (int) $request->get_param( 'user_id' ) : null;
        return rest_ensure_response( Culture_WebAuthn::get_login_options( $user_id ) );
    }

    public static function handle_passkey_login_verify( $request ) {
        $resp = $request->get_json_params();
        if ( empty( $resp ) ) {
            return new WP_Error( 'bad_request', 'Missing response body.', array( 'status' => 400 ) );
        }
        $result = Culture_WebAuthn::verify_login( $resp );
        if ( ! $result['success'] ) {
            return new WP_Error( 'passkey_error', $result['error'], array( 'status' => 401 ) );
        }
        return rest_ensure_response( $result );
    }

    public static function handle_passkey_exchange_token( $request ) {
        $token   = sanitize_text_field( $request->get_param( 'passkey_token' ) ?? '' );
        $user_id = Culture_WebAuthn::exchange_passkey_token( $token );
        if ( ! $user_id ) {
            return new WP_Error( 'invalid_token', 'Invalid or expired token.', array( 'status' => 401 ) );
        }
        // Return same profile data as login endpoint.
        $user = get_userdata( $user_id );
        if ( ! $user ) {
            return new WP_Error( 'invalid_user', 'User not found.', array( 'status' => 404 ) );
        }
        return rest_ensure_response( self::user_profile( $user ) );
    }

    public static function handle_passkey_step_up( $request ) {
        $user_id = (int) $request->get_param( 'user_id' );
        if ( ! $user_id ) return new WP_Error( 'bad_request', 'Missing user_id.', array( 'status' => 400 ) );
        $creds = Culture_WebAuthn::get_credentials( $user_id );
        if ( empty( $creds ) ) {
            return new WP_Error( 'no_passkey', 'No passkey registered.', array( 'status' => 403 ) );
        }
        return rest_ensure_response( Culture_WebAuthn::get_step_up_options( $user_id ) );
    }

    public static function handle_passkey_step_up_verify( $request ) {
        $user_id = (int) $request->get_param( 'user_id' );
        $resp    = $request->get_param( 'response' );
        if ( ! $user_id || ! is_array( $resp ) ) {
            return new WP_Error( 'bad_request', 'Missing user_id or response.', array( 'status' => 400 ) );
        }
        $result = Culture_WebAuthn::verify_step_up( $user_id, $resp );
        if ( ! $result['success'] ) {
            return new WP_Error( 'passkey_error', $result['error'], array( 'status' => 401 ) );
        }
        return rest_ensure_response( $result );
    }

    public static function handle_passkey_list( $request ) {
        $user_id = (int) $request->get_param( 'user_id' );
        $creds   = Culture_WebAuthn::get_credentials( $user_id );
        $out     = array_map( fn($c) => [
            'id'           => $c['credential_id'],
            'device_name'  => $c['device_name'],
            'created_at'   => $c['created_at'],
            'last_used_at' => $c['last_used_at'],
            'aaguid'       => $c['aaguid'],
        ], $creds );
        return rest_ensure_response( $out );
    }

    public static function handle_passkey_delete( $request ) {
        $user_id = (int) $request->get_param( 'user_id' );
        $cred_id = sanitize_text_field( $request->get_param( 'credential_id' ) ?? '' );
        if ( ! $user_id || ! $cred_id ) {
            return new WP_Error( 'bad_request', 'Missing user_id or credential_id.', array( 'status' => 400 ) );
        }
        $deleted = Culture_WebAuthn::delete_credential( $user_id, $cred_id );
        if ( ! $deleted ) {
            return new WP_Error( 'not_found', 'Credential not found.', array( 'status' => 404 ) );
        }
        return rest_ensure_response( array( 'success' => true ) );
    }

    /* ——————————————————————————————————————
     *  Notification handlers
     * —————————————————————————————————————— */

    public static function handle_get_notifications( $request ) {
        $user_id = (int) $request->get_param( 'user_id' );
        $limit   = min( 50, max( 1, (int) $request->get_param( 'limit' ) ) );
        $offset  = max( 0, (int) $request->get_param( 'offset' ) );
        $rows    = Culture_Notifications::get_for_user( $user_id, $limit, $offset );
        foreach ( $rows as &$row ) {
            $row['meta'] = json_decode( $row['meta'] ?? '{}', true ) ?: array();
        }
        return rest_ensure_response( $rows );
    }

    public static function handle_notification_count( $request ) {
        $user_id = (int) $request->get_param( 'user_id' );
        return rest_ensure_response( array( 'unread' => Culture_Notifications::count_unread( $user_id ) ) );
    }

    public static function handle_mark_notifications_read( $request ) {
        $user_id         = (int) $request->get_param( 'user_id' );
        $notification_id = $request->get_param( 'notification_id' );
        if ( $notification_id ) {
            Culture_Notifications::mark_read( $user_id, (int) $notification_id );
        } else {
            Culture_Notifications::mark_all_read( $user_id );
        }
        return rest_ensure_response( array( 'success' => true ) );
    }

    public static function handle_get_notification_prefs( $request ) {
        $user_id = (int) $request->get_param( 'user_id' );
        return rest_ensure_response( Culture_Notifications::get_prefs( $user_id ) );
    }

    public static function handle_set_notification_prefs( $request ) {
        $user_id = (int) $request->get_param( 'user_id' );
        $prefs   = $request->get_param( 'prefs' );
        if ( ! is_array( $prefs ) ) {
            $prefs = array();
        }
        return rest_ensure_response( Culture_Notifications::set_prefs( $user_id, $prefs ) );
    }

    /* ——————————————————————————————————————
     *  Follow handlers
     * —————————————————————————————————————— */

    public static function handle_follow_member( $request ) {
        $user_id   = (int) $request->get_param( 'user_id' );
        $target_id = (int) $request->get_param( 'target_id' );
        $notify    = (bool) $request->get_param( 'notify_posts' );

        if ( $target_id === $user_id ) {
            return new WP_Error( 'invalid_target', 'You cannot follow yourself.', array( 'status' => 400 ) );
        }
        if ( ! get_userdata( $target_id ) ) {
            return new WP_Error( 'not_found', 'Member not found.', array( 'status' => 404 ) );
        }

        Culture_Follows::follow( $user_id, $target_id, $notify );

        return rest_ensure_response( array(
            'success'        => true,
            'isFollowing'    => true,
            'followersCount' => Culture_Follows::followers_count( $target_id ),
        ) );
    }

    public static function handle_unfollow_member( $request ) {
        $user_id   = (int) $request->get_param( 'user_id' );
        $target_id = (int) $request->get_param( 'target_id' );

        Culture_Follows::unfollow( $user_id, $target_id );

        return rest_ensure_response( array(
            'success'        => true,
            'isFollowing'    => false,
            'followersCount' => Culture_Follows::followers_count( $target_id ),
        ) );
    }

    public static function handle_set_follow_notify( $request ) {
        $user_id   = (int) $request->get_param( 'user_id' );
        $target_id = (int) $request->get_param( 'target_id' );
        $notify    = (bool) $request->get_param( 'notify_posts' );

        if ( ! Culture_Follows::is_following( $user_id, $target_id ) ) {
            return new WP_Error( 'not_following', 'You are not following this member.', array( 'status' => 400 ) );
        }

        Culture_Follows::set_notify( $user_id, $target_id, $notify );

        return rest_ensure_response( array( 'success' => true, 'notifyPosts' => $notify ) );
    }

    public static function handle_follow_status( $request ) {
        $user_id   = (int) $request->get_param( 'user_id' );
        $target_id = (int) $request->get_param( 'target_id' );

        return rest_ensure_response( array(
            'isFollowing'    => Culture_Follows::is_following( $user_id, $target_id ),
            'followersCount' => Culture_Follows::followers_count( $target_id ),
            'followingCount' => Culture_Follows::following_count( $target_id ),
        ) );
    }

    public static function handle_get_following_usernames( $request ) {
        $user_id = (int) $request->get_param( 'user_id' );
        return rest_ensure_response( array(
            'usernames' => Culture_Follows::get_following_usernames( $user_id ),
        ) );
    }

    /* ——————————————————————————————————————
     *  Community event RSVPs (web — API key, explicit user_id)
     * —————————————————————————————————————— */

    public static function handle_reading_shelf_set( $request ) {
        $user_id      = (int) $request->get_param( 'user_id' );
        $directory_id = (int) $request->get_param( 'directory_id' );
        $status       = sanitize_key( $request->get_param( 'status' ) );
        $rating       = $request->has_param( 'rating' ) ? $request->get_param( 'rating' ) : null;
        $result       = Culture_Reading_Tracker::set_shelf_status( $user_id, $directory_id, $status, $rating );
        if ( is_wp_error( $result ) ) {
            return $result;
        }
        return rest_ensure_response( $result );
    }

    public static function handle_reading_rating_set( $request ) {
        $result = Culture_Reading_Tracker::set_shelf_rating(
            (int) $request->get_param( 'user_id' ),
            (int) $request->get_param( 'directory_id' ),
            $request->get_param( 'rating' )
        );
        if ( is_wp_error( $result ) ) {
            return $result;
        }
        return rest_ensure_response( $result );
    }

    public static function handle_reading_shelf_remove( $request ) {
        $user_id      = (int) $request->get_param( 'user_id' );
        $directory_id = (int) $request->get_param( 'directory_id' );
        Culture_Reading_Tracker::remove_from_shelf( $user_id, $directory_id );
        return rest_ensure_response( array( 'removed' => true ) );
    }

    public static function handle_reading_shelf_get( $request ) {
        $user_id  = (int) $request->get_param( 'user_id' );
        $status   = sanitize_key( $request->get_param( 'status' ) );
        $page     = (int) $request->get_param( 'page' ) ?: 1;
        $per_page = (int) $request->get_param( 'per_page' ) ?: 20;
        $medium   = sanitize_key( (string) $request->get_param( 'medium' ) );
        return rest_ensure_response( Culture_Reading_Tracker::get_user_shelf( $user_id, $status, $page, $per_page, $medium ) );
    }

    public static function handle_reading_entry_get( $request ) {
        return rest_ensure_response( Culture_Reading_Tracker::get_entry_state(
            (int) $request->get_param( 'user_id' ),
            (int) $request->get_param( 'directory_id' )
        ) );
    }

    public static function handle_reading_shelf_counts( $request ) {
        $user_id = (int) $request->get_param( 'user_id' );
        return rest_ensure_response( Culture_Reading_Tracker::get_shelf_counts( $user_id ) );
    }

    public static function handle_reading_goal_get( $request ) {
        $user_id = (int) $request->get_param( 'user_id' );
        $year    = (int) $request->get_param( 'year' ) ?: (int) current_time( 'Y' );
        return rest_ensure_response( Culture_Reading_Tracker::get_goal( $user_id, $year ) );
    }

    public static function handle_reading_goal_set( $request ) {
        $user_id      = (int) $request->get_param( 'user_id' );
        $year         = (int) $request->get_param( 'year' ) ?: (int) current_time( 'Y' );
        $target_books = (int) $request->get_param( 'target_books' );
        $result       = Culture_Reading_Tracker::set_goal( $user_id, $year, $target_books );
        if ( is_wp_error( $result ) ) {
            return $result;
        }
        return rest_ensure_response( $result );
    }

    public static function handle_reading_mood_vote( $request ) {
        $user_id      = (int) $request->get_param( 'user_id' );
        $directory_id = (int) $request->get_param( 'directory_id' );
        $moods        = (array) $request->get_param( 'moods' );
        $pace         = (string) $request->get_param( 'pace' );
        $result       = Culture_Reading_Tracker::vote_mood_pace( $user_id, $directory_id, $moods, $pace );
        if ( is_wp_error( $result ) ) {
            return $result;
        }
        return rest_ensure_response( $result );
    }

    public static function handle_reading_mood_pace_get( $request ) {
        $directory_id = (int) $request->get_param( 'directory_id' );
        $user_id      = (int) $request->get_param( 'user_id' );
        return rest_ensure_response( Culture_Reading_Tracker::get_book_mood_pace( $directory_id, $user_id ) );
    }

    public static function handle_reading_stats_get( $request ) {
        $user_id = (int) $request->get_param( 'user_id' );
        $year    = (int) $request->get_param( 'year' ) ?: (int) current_time( 'Y' );
        return rest_ensure_response( Culture_Reading_Tracker::get_reading_stats( $user_id, $year ) );
    }

    public static function handle_reading_save_line( $request ) {
        $user_id        = (int) $request->get_param( 'user_id' );
        $directory_id   = (int) $request->get_param( 'directory_id' );
        $line_text      = (string) $request->get_param( 'line_text' );
        $source_context = (string) $request->get_param( 'source_context' );
        $result         = Culture_Reading_Tracker::save_line( $user_id, $directory_id, $line_text, $source_context );
        if ( is_wp_error( $result ) ) {
            return $result;
        }
        return rest_ensure_response( $result );
    }

    public static function handle_reading_get_saved_lines( $request ) {
        $directory_id = (int) $request->get_param( 'directory_id' );
        $user_id      = (int) $request->get_param( 'user_id' );
        return rest_ensure_response( array( 'lines' => Culture_Reading_Tracker::get_saved_lines( $directory_id, $user_id ) ) );
    }

    public static function handle_reading_delete_saved_line( $request ) {
        $user_id = (int) $request->get_param( 'user_id' );
        $line_id = (int) $request->get_param( 'id' );
        Culture_Reading_Tracker::delete_saved_line( $user_id, $line_id );
        return rest_ensure_response( array( 'removed' => true ) );
    }

    public static function handle_reading_social_proof( $request ) {
        $viewer_user_id = (int) $request->get_param( 'user_id' );
        $directory_id   = (int) $request->get_param( 'directory_id' );
        return rest_ensure_response( Culture_Reading_Tracker::get_social_proof( $viewer_user_id, $directory_id ) );
    }

    public static function handle_reading_also_logged( $request ) {
        $directory_id = (int) $request->get_param( 'directory_id' );
        return rest_ensure_response( array( 'entries' => Culture_Reading_Tracker::get_also_logged( $directory_id ) ) );
    }

    public static function handle_reading_following_activity( $request ) {
        $user_id = (int) $request->get_param( 'user_id' );
        $limit   = (int) $request->get_param( 'limit' ) ?: 10;
        return rest_ensure_response( array( 'activity' => Culture_Reading_Tracker::get_following_activity( $user_id, $limit ) ) );
    }

    public static function handle_reading_place_proximity( $request ) {
        $user_id      = (int) $request->get_param( 'user_id' );
        $directory_id = (int) $request->get_param( 'directory_id' );
        $result       = Culture_Reading_Tracker::get_place_proximity( $user_id, $directory_id );
        if ( is_wp_error( $result ) ) {
            return $result;
        }
        return rest_ensure_response( $result );
    }

    public static function handle_set_location( $request ) {
        $user_id = (int) $request->get_param( 'user_id' );
        $lat     = (float) $request->get_param( 'lat' );
        $lng     = (float) $request->get_param( 'lng' );
        $result  = Culture_Geolocation::set_location( $user_id, $lat, $lng );
        if ( is_wp_error( $result ) ) {
            return $result;
        }
        return rest_ensure_response( $result );
    }

    public static function handle_get_location( $request ) {
        $user_id = (int) $request->get_param( 'user_id' );
        $loc     = Culture_Geolocation::get_location( $user_id );
        return rest_ensure_response( array(
            'hasLocation' => null !== $loc['lat'] && null !== $loc['lng'],
            'updatedAt'   => $loc['updatedAt'],
        ) );
    }

    public static function handle_clear_location( $request ) {
        $user_id = (int) $request->get_param( 'user_id' );
        Culture_Geolocation::clear_location( $user_id );
        return rest_ensure_response( array( 'hasLocation' => false ) );
    }

    public static function handle_directory_follow( $request ) {
        $user_id      = (int) $request->get_param( 'user_id' );
        $directory_id = (int) $request->get_param( 'id' );
        $result       = Culture_Directory_Follows::follow( $user_id, $directory_id );
        if ( is_wp_error( $result ) ) {
            return $result;
        }
        return rest_ensure_response( Culture_Directory_Follows::get_status( $user_id, $directory_id ) );
    }

    public static function handle_directory_unfollow( $request ) {
        $user_id      = (int) $request->get_param( 'user_id' );
        $directory_id = (int) $request->get_param( 'id' );
        Culture_Directory_Follows::unfollow( $user_id, $directory_id );
        return rest_ensure_response( Culture_Directory_Follows::get_status( $user_id, $directory_id ) );
    }

    public static function handle_directory_follow_status( $request ) {
        $user_id      = (int) $request->get_param( 'user_id' );
        $directory_id = (int) $request->get_param( 'id' );
        return rest_ensure_response( Culture_Directory_Follows::get_status( $user_id, $directory_id ) );
    }

    public static function handle_community_event_rsvp( $request ) {
        $user_id = (int) $request->get_param( 'user_id' );
        $post_id = (int) $request->get_param( 'post_id' );
        $result  = Culture_Community_RSVP::rsvp( $post_id, $user_id );
        if ( is_wp_error( $result ) ) {
            return $result;
        }
        return rest_ensure_response( Culture_Community_RSVP::get_status( $post_id, $user_id ) );
    }

    public static function handle_community_event_rsvp_cancel( $request ) {
        $user_id = (int) $request->get_param( 'user_id' );
        $post_id = (int) $request->get_param( 'post_id' );
        Culture_Community_RSVP::cancel( $post_id, $user_id );
        return rest_ensure_response( Culture_Community_RSVP::get_status( $post_id, $user_id ) );
    }

    public static function handle_community_event_rsvp_status( $request ) {
        $user_id = (int) $request->get_param( 'user_id' );
        $post_id = (int) $request->get_param( 'post_id' );
        return rest_ensure_response( Culture_Community_RSVP::get_status( $post_id, $user_id ) );
    }

    public static function handle_community_event_attendees( $request ) {
        $user_id = (int) $request->get_param( 'user_id' );
        $post_id = (int) $request->get_param( 'post_id' );

        if ( ! Culture_Community_RSVP::is_pro( $user_id ) ) {
            return new WP_Error( 'patron_required', 'Moveee Pro membership required to manage event RSVPs.', array( 'status' => 403 ) );
        }
        if ( ! Culture_Community_RSVP::is_organiser( $post_id, $user_id ) ) {
            return new WP_Error( 'forbidden', 'Only the event organiser can view attendees.', array( 'status' => 403 ) );
        }

        $attendees = array_map( function( $row ) {
            return array(
                'userId'      => (int) $row['user_id'],
                'displayName' => $row['display_name'],
                'email'       => $row['user_email'],
                'rsvpAt'      => $row['created_at'],
            );
        }, Culture_Community_RSVP::get_attendees( $post_id ) );

        return rest_ensure_response( array( 'attendees' => $attendees ) );
    }

    public static function handle_community_my_events( $request ) {
        $user_id = (int) $request->get_param( 'user_id' );

        if ( ! Culture_Community_RSVP::is_pro( $user_id ) ) {
            return new WP_Error( 'patron_required', 'Moveee Pro membership required to manage event RSVPs.', array( 'status' => 403 ) );
        }

        return rest_ensure_response( array( 'events' => Culture_Community_RSVP::get_organiser_events( $user_id ) ) );
    }

    /* ——————————————————————————————————————
     *  Stoop clusters (web — API key, explicit user_id)
     * —————————————————————————————————————— */

    public static function handle_cluster_create( $request ) {
        $user_id = (int) $request->get_param( 'user_id' );
        $data    = array(
            'name'              => (string) $request->get_param( 'name' ),
            'city'              => (string) $request->get_param( 'city' ),
            'street'            => (string) $request->get_param( 'street' ),
            'country'           => (string) $request->get_param( 'country' ),
            'capacity'          => $request->get_param( 'capacity' ),
            'meetingDay'        => (string) $request->get_param( 'meeting_day' ),
            'meetingTime'       => (string) $request->get_param( 'meeting_time' ),
            'locationNote'      => (string) $request->get_param( 'location_note' ),
            'venueType'         => (string) $request->get_param( 'venue_type' ),
            'hostNote'          => (string) $request->get_param( 'host_note' ),
            'realisticCapacity' => (int) ( $request->get_param( 'realistic_capacity' ) ?: 0 ),
            'accessible'        => (bool) $request->get_param( 'accessible' ),
            'addressVisible'    => (string) ( $request->get_param( 'address_visible' ) ?: 'members_only' ),
            'localityConfirmed' => (bool) $request->get_param( 'locality_confirmed' ),
            'category'          => (string) ( $request->get_param( 'category' ) ?: 'general' ),
        );
        $raw_lat = $request->get_param( 'lat' );
        $raw_lng = $request->get_param( 'lng' );
        if ( is_numeric( $raw_lat ) ) $data['lat'] = (float) $raw_lat;
        if ( is_numeric( $raw_lng ) ) $data['lng'] = (float) $raw_lng;

        $result = Culture_Clusters::create_cluster( $user_id, $data );
        if ( is_wp_error( $result ) ) {
            return $result;
        }

        return rest_ensure_response( Culture_Clusters::get_cluster( $result ) );
    }

    public static function handle_cluster_discover( $request ) {
        $params = array(
            'q'        => (string) $request->get_param( 'q' ),
            'city'     => (string) $request->get_param( 'city' ),
            'country'  => (string) $request->get_param( 'country' ),
            'status'   => (string) $request->get_param( 'status' ),
            'sort'     => (string) $request->get_param( 'sort' ),
            'page'     => (int) ( $request->get_param( 'page' ) ?: 1 ),
            'per_page' => (int) ( $request->get_param( 'per_page' ) ?: 20 ),
        );

        return rest_ensure_response( Culture_Clusters::discover( $params ) );
    }

    public static function handle_cluster_my_clusters( $request ) {
        $user_id = (int) $request->get_param( 'user_id' );
        return rest_ensure_response( array( 'clusters' => Culture_Clusters::list_for_user( $user_id ) ) );
    }

    public static function handle_cluster_get( $request ) {
        $cluster_id = (int) $request->get_param( 'id' );
        $cluster    = Culture_Clusters::get_cluster( $cluster_id );
        if ( ! $cluster ) {
            return new WP_Error( 'not_found', 'Cluster not found.', array( 'status' => 404 ) );
        }
        return rest_ensure_response( $cluster );
    }

    public static function handle_cluster_status( $request ) {
        $user_id    = (int) $request->get_param( 'user_id' );
        $cluster_id = (int) $request->get_param( 'id' );
        return rest_ensure_response( Culture_Clusters::get_member_status( $cluster_id, $user_id ) );
    }

    public static function handle_cluster_join( $request ) {
        $user_id    = (int) $request->get_param( 'user_id' );
        $cluster_id = (int) $request->get_param( 'id' );

        $result = Culture_Clusters::join( $cluster_id, $user_id );
        if ( is_wp_error( $result ) ) {
            return $result;
        }

        return rest_ensure_response( Culture_Clusters::get_member_status( $cluster_id, $user_id ) );
    }

    public static function handle_cluster_leave( $request ) {
        $user_id    = (int) $request->get_param( 'user_id' );
        $cluster_id = (int) $request->get_param( 'id' );

        Culture_Clusters::leave( $cluster_id, $user_id );

        return rest_ensure_response( Culture_Clusters::get_member_status( $cluster_id, $user_id ) );
    }

    public static function handle_cluster_election_start( $request ) {
        $user_id    = (int) $request->get_param( 'user_id' );
        $cluster_id = (int) $request->get_param( 'id' );

        $result = Culture_Clusters::start_election( $cluster_id, $user_id );
        if ( is_wp_error( $result ) ) {
            return $result;
        }

        return rest_ensure_response( Culture_Clusters::get_election_status( $cluster_id, $user_id ) );
    }

    public static function handle_cluster_election_vote( $request ) {
        $user_id      = (int) $request->get_param( 'user_id' );
        $cluster_id   = (int) $request->get_param( 'id' );
        $candidate_id = (int) $request->get_param( 'candidate_id' );

        $result = Culture_Clusters::cast_vote( $cluster_id, $user_id, $candidate_id );
        if ( is_wp_error( $result ) ) {
            return $result;
        }

        return rest_ensure_response( Culture_Clusters::get_election_status( $cluster_id, $user_id ) );
    }

    public static function handle_cluster_election_status( $request ) {
        $user_id    = (int) $request->get_param( 'user_id' );
        $cluster_id = (int) $request->get_param( 'id' );

        return rest_ensure_response( Culture_Clusters::get_election_status( $cluster_id, $user_id ) );
    }

    public static function handle_cluster_members( $request ) {
        $cluster_id = (int) $request->get_param( 'id' );

        return rest_ensure_response( array( 'members' => Culture_Clusters::get_members( $cluster_id ) ) );
    }

    public static function handle_cluster_host_qr( $request ) {
        $host_id    = (int) $request->get_param( 'user_id' );
        $cluster_id = (int) $request->get_param( 'id' );

        $result = Culture_Clusters::generate_host_qr( $cluster_id, $host_id );
        if ( is_wp_error( $result ) ) {
            return $result;
        }

        return rest_ensure_response( $result );
    }

    public static function handle_cluster_checkin( $request ) {
        $user_id      = (int) $request->get_param( 'user_id' );
        $cluster_id   = (int) $request->get_param( 'id' );
        $meeting_date = (string) $request->get_param( 'meeting_date' );
        $expires_at   = (int) $request->get_param( 'expires_at' );
        $token        = (string) $request->get_param( 'token' );

        $verified = Culture_Clusters::verify_checkin_qr( $cluster_id, $meeting_date, $expires_at, $token );
        if ( is_wp_error( $verified ) ) {
            return $verified;
        }

        $result = Culture_Clusters::check_in( $cluster_id, $user_id, 'qr', $meeting_date );
        if ( is_wp_error( $result ) ) {
            return $result;
        }

        return rest_ensure_response( $result );
    }

    public static function handle_cluster_checkin_manual( $request ) {
        $host_id        = (int) $request->get_param( 'user_id' );
        $cluster_id     = (int) $request->get_param( 'id' );
        $member_user_id = (int) $request->get_param( 'member_user_id' );

        $cluster = Culture_Clusters::get_cluster( $cluster_id );
        if ( ! $cluster ) {
            return new WP_Error( 'not_found', 'Stoop not found.', array( 'status' => 404 ) );
        }
        if ( (int) $cluster['hostId'] !== $host_id ) {
            return new WP_Error( 'forbidden', 'Only the current host can record manual check-ins.', array( 'status' => 403 ) );
        }

        $result = Culture_Clusters::check_in( $cluster_id, $member_user_id, 'host_manual' );
        if ( is_wp_error( $result ) ) {
            return $result;
        }

        return rest_ensure_response( $result );
    }

    public static function handle_cluster_attendance( $request ) {
        $user_id    = (int) $request->get_param( 'user_id' );
        $cluster_id = (int) $request->get_param( 'id' );

        return rest_ensure_response( Culture_Clusters::get_attendance_history( $cluster_id, $user_id ) );
    }

    public static function handle_cluster_agenda_get( $request ) {
        $user_id    = (int) $request->get_param( 'user_id' );
        $cluster_id = (int) $request->get_param( 'id' );

        $items = Culture_Clusters::get_agenda( $cluster_id, $user_id );
        return rest_ensure_response( array( 'gatherings' => $items ) );
    }

    public static function handle_cluster_agenda_post( $request ) {
        $user_id    = (int) $request->get_param( 'user_id' );
        $cluster_id = (int) $request->get_param( 'id' );

        $body = $request->get_json_params();
        if ( ! is_array( $body ) ) {
            $body = array();
        }

        // Branch 1: RSVP toggle — body has "rsvp" key.
        if ( isset( $body['rsvp'] ) || array_key_exists( 'rsvp', $body ) ) {
            $gathering_id   = sanitize_text_field( $body['gathering_id'] ?? '' );
            $rsvp           = isset( $body['rsvp'] ) && in_array( $body['rsvp'], array( 'attending', 'declined' ), true )
                                ? $body['rsvp']
                                : null;
            // gathering_id is the ISO date string used as the RSVP key.
            Culture_Clusters::set_rsvp( $cluster_id, $user_id, $gathering_id, $rsvp );
            return rest_ensure_response( array( 'ok' => true ) );
        }

        // Branch 2: Create custom gathering — body has "date" + "title" keys.
        // Only the cluster host may do this.
        $status = Culture_Clusters::get_member_status( $cluster_id, $user_id );
        if ( ( $status['role'] ?? '' ) !== 'host' ) {
            return new WP_Error( 'forbidden', 'Only the stoop host can create gatherings.', array( 'status' => 403 ) );
        }

        $result = Culture_Clusters::create_gathering( $cluster_id, $user_id, $body );
        if ( is_wp_error( $result ) ) {
            return $result;
        }

        // Return the refreshed agenda so the client can re-render.
        $items = Culture_Clusters::get_agenda( $cluster_id, $user_id );
        return rest_ensure_response( array( 'ok' => true, 'gathering_id' => $result, 'gatherings' => $items ) );
    }

    /* ——————————————————————————————————————
     *  Cluster chatter (direct, no Hub)
     * —————————————————————————————————————— */

    public static function handle_cluster_chatter_get( $request ) {
        $cluster_id = (int) $request->get_param( 'id' );
        $since_id   = (int) $request->get_param( 'since' );
        $messages   = Culture_Clusters::get_chatter( $cluster_id, $since_id );
        return rest_ensure_response( array( 'messages' => $messages ) );
    }

    public static function handle_cluster_chatter_post( $request ) {
        $cluster_id = (int) $request->get_param( 'id' );
        $user_id    = (int) $request->get_param( 'user_id' );

        $body    = $request->get_json_params();
        $message = isset( $body['message'] ) ? sanitize_textarea_field( $body['message'] ) : '';
        $images  = isset( $body['images'] ) && is_array( $body['images'] ) ? $body['images'] : array();

        if ( '' === $message && empty( $images ) ) {
            return new WP_Error( 'empty_message', 'Message cannot be empty.', array( 'status' => 400 ) );
        }

        $result = Culture_Clusters::post_chatter( $cluster_id, $user_id, $message, $images );
        if ( is_wp_error( $result ) ) {
            return $result;
        }

        $messages = Culture_Clusters::get_chatter( $cluster_id, $result - 1 );
        return rest_ensure_response( array( 'ok' => true, 'messages' => $messages ) );
    }

    /* ——————————————————————————————————————
     *  Cluster photo upload (cover / avatar)
     * —————————————————————————————————————— */

    public static function handle_cluster_photo_upload( $request ) {
        $cluster_id = (int) $request->get_param( 'id' );
        $user_id    = (int) $request->get_param( 'user_id' );
        $type       = sanitize_key( $request->get_param( 'type' ) ?? 'cover' );

        // Only the host may update photos.
        $status = Culture_Clusters::get_member_status( $cluster_id, $user_id );
        if ( ( $status['role'] ?? '' ) !== 'host' ) {
            return new WP_Error( 'forbidden', 'Only the stoop host can update photos.', array( 'status' => 403 ) );
        }

        if ( ! function_exists( 'wp_handle_upload' ) ) {
            require_once ABSPATH . 'wp-admin/includes/file.php';
        }
        if ( ! function_exists( 'wp_generate_attachment_metadata' ) ) {
            require_once ABSPATH . 'wp-admin/includes/image.php';
            require_once ABSPATH . 'wp-admin/includes/media.php';
        }

        $files = $request->get_file_params();
        if ( empty( $files['file'] ) ) {
            return new WP_Error( 'no_file', 'No file uploaded.', array( 'status' => 400 ) );
        }

        $upload = wp_handle_upload( $files['file'], array( 'test_form' => false ) );
        if ( isset( $upload['error'] ) ) {
            return new WP_Error( 'upload_failed', $upload['error'], array( 'status' => 500 ) );
        }

        $url = $upload['url'];

        // cluster_id IS the WP post id (culture_cluster post type).
        $meta_key = ( 'avatar' === $type ) ? '_cluster_avatar_url' : '_cluster_cover_url';
        update_post_meta( $cluster_id, $meta_key, $url );

        return rest_ensure_response( array( 'ok' => true, 'url' => $url ) );
    }

    /* ——————————————————————————————————————
     *  Hubs (web — API key, explicit user_id)
     * —————————————————————————————————————— */

    public static function handle_hub_create( $request ) {
        $user_id = (int) $request->get_param( 'user_id' );
        $data    = array(
            'name'              => (string) $request->get_param( 'name' ),
            'description'       => (string) $request->get_param( 'description' ),
            'coverImageUrl'     => (string) $request->get_param( 'cover_image_url' ),
            'allowedTemplates'  => $request->get_param( 'allowed_templates' ),
            'category'          => (string) $request->get_param( 'category' ),
        );

        $result = Culture_Hubs::create( $user_id, $data );
        if ( is_wp_error( $result ) ) {
            return $result;
        }

        return rest_ensure_response( Culture_Hubs::get_hub( $result ) );
    }

    public static function handle_hub_update( $request ) {
        $user_id = (int) $request->get_param( 'user_id' );
        $hub_id  = (int) $request->get_param( 'id' );
        $data    = array();
        if ( null !== $request->get_param( 'name' ) ) {
            $data['name'] = (string) $request->get_param( 'name' );
        }
        if ( null !== $request->get_param( 'description' ) ) {
            $data['description'] = (string) $request->get_param( 'description' );
        }
        if ( null !== $request->get_param( 'cover_image_url' ) ) {
            $data['coverImageUrl'] = (string) $request->get_param( 'cover_image_url' );
        }
        if ( null !== $request->get_param( 'allowed_templates' ) ) {
            $data['allowedTemplates'] = $request->get_param( 'allowed_templates' );
        }
        if ( null !== $request->get_param( 'category' ) ) {
            $data['category'] = (string) $request->get_param( 'category' );
        }

        $result = Culture_Hubs::update( $hub_id, $user_id, $data );
        if ( is_wp_error( $result ) ) {
            return $result;
        }

        return rest_ensure_response( $result );
    }

    public static function handle_hub_archive( $request ) {
        $user_id = (int) $request->get_param( 'user_id' );
        $hub_id  = (int) $request->get_param( 'id' );

        $result = Culture_Hubs::archive( $hub_id, $user_id );
        if ( is_wp_error( $result ) ) {
            return $result;
        }

        return rest_ensure_response( Culture_Hubs::get_hub( $hub_id ) );
    }

    public static function handle_hub_discover( $request ) {
        $params = array(
            'q'        => (string) $request->get_param( 'q' ),
            'sort'     => (string) $request->get_param( 'sort' ),
            'category' => (string) $request->get_param( 'category' ),
            'page'     => (int) ( $request->get_param( 'page' ) ?: 1 ),
            'per_page' => (int) ( $request->get_param( 'per_page' ) ?: 20 ),
        );

        return rest_ensure_response( Culture_Hubs::discover( $params ) );
    }

    public static function handle_hub_my_hubs( $request ) {
        $user_id = (int) $request->get_param( 'user_id' );
        return rest_ensure_response( Culture_Hubs::get_for_user( $user_id ) );
    }

    public static function handle_hub_related_events( $request ) {
        $hub_id = (int) $request->get_param( 'id' );
        return rest_ensure_response( array( 'events' => Culture_Hubs::get_related_events( $hub_id ) ) );
    }

    public static function handle_hub_get( $request ) {
        $hub_id = (int) $request->get_param( 'id' );
        $hub    = Culture_Hubs::get_hub( $hub_id );
        if ( ! $hub ) {
            return new WP_Error( 'not_found', 'Hub not found.', array( 'status' => 404 ) );
        }
        return rest_ensure_response( $hub );
    }

    public static function handle_hub_get_by_slug( $request ) {
        $slug = (string) $request->get_param( 'slug' );
        $hub  = Culture_Hubs::get_hub_by_slug( $slug );
        if ( ! $hub ) {
            return new WP_Error( 'not_found', 'Hub not found.', array( 'status' => 404 ) );
        }
        return rest_ensure_response( $hub );
    }

    public static function handle_hub_status( $request ) {
        $user_id = (int) $request->get_param( 'user_id' );
        $hub_id  = (int) $request->get_param( 'id' );
        return rest_ensure_response( Culture_Hubs::get_status( $hub_id, $user_id ) );
    }

    public static function handle_hub_join( $request ) {
        $user_id = (int) $request->get_param( 'user_id' );
        $hub_id  = (int) $request->get_param( 'id' );

        $result = Culture_Hubs::join( $hub_id, $user_id );
        if ( is_wp_error( $result ) ) {
            return $result;
        }

        return rest_ensure_response( Culture_Hubs::get_status( $hub_id, $user_id ) );
    }

    public static function handle_hub_leave( $request ) {
        $user_id = (int) $request->get_param( 'user_id' );
        $hub_id  = (int) $request->get_param( 'id' );

        $result = Culture_Hubs::leave( $hub_id, $user_id );
        if ( is_wp_error( $result ) ) {
            return $result;
        }

        return rest_ensure_response( Culture_Hubs::get_status( $hub_id, $user_id ) );
    }

    public static function handle_hub_follow( $request ) {
        $user_id      = (int) $request->get_param( 'user_id' );
        $hub_id       = (int) $request->get_param( 'id' );
        $notify_posts = (bool) $request->get_param( 'notify_posts' );

        $result = Culture_Hubs::follow( $hub_id, $user_id, $notify_posts );
        if ( is_wp_error( $result ) ) {
            return $result;
        }

        return rest_ensure_response( Culture_Hubs::get_status( $hub_id, $user_id ) );
    }

    public static function handle_hub_unfollow( $request ) {
        $user_id = (int) $request->get_param( 'user_id' );
        $hub_id  = (int) $request->get_param( 'id' );

        if ( ! Culture_Hubs::unfollow( $hub_id, $user_id ) ) {
            return new WP_Error( 'unfollow_failed', 'Could not unfollow this Hub right now. Please try again.', array( 'status' => 500 ) );
        }

        return rest_ensure_response( Culture_Hubs::get_status( $hub_id, $user_id ) );
    }

    public static function handle_hub_feed( $request ) {
        $hub_id    = (int) $request->get_param( 'id' );
        $page      = max( 1, (int) ( $request->get_param( 'page' ) ?: 1 ) );
        $per_page  = min( 50, max( 1, (int) ( $request->get_param( 'per_page' ) ?: 20 ) ) );
        $viewer_id = (int) ( $request->get_param( 'user_id' ) ?: 0 );

        return rest_ensure_response( Culture_Mobile_API::get_hub_feed_items( $hub_id, $page, $per_page, $viewer_id ) );
    }

    public static function handle_hub_for_you_candidates( $request ) {
        $hub_ids_raw = (string) $request->get_param( 'hub_ids' );
        $hub_ids     = array_filter( array_map( 'intval', explode( ',', $hub_ids_raw ) ) );
        $limit       = min( 50, max( 1, (int) ( $request->get_param( 'limit' ) ?: 30 ) ) );
        $viewer_id   = (int) ( $request->get_param( 'user_id' ) ?: 0 );

        return rest_ensure_response( array( 'items' => Culture_Mobile_API::get_hub_candidate_items( $hub_ids, $limit, $viewer_id ) ) );
    }

    public static function handle_hub_members( $request ) {
        $hub_id   = (int) $request->get_param( 'id' );
        $page     = max( 1, (int) ( $request->get_param( 'page' ) ?: 1 ) );
        $per_page = min( 100, max( 1, (int) ( $request->get_param( 'per_page' ) ?: 50 ) ) );

        return rest_ensure_response( Culture_Hubs::list_members( $hub_id, $page, $per_page ) );
    }

    public static function handle_hub_appoint_mod( $request ) {
        $requester_id = (int) $request->get_param( 'user_id' );
        $hub_id       = (int) $request->get_param( 'id' );
        $target_id    = (int) $request->get_param( 'target_user_id' );

        $result = Culture_Hubs::appoint_mod( $hub_id, $requester_id, $target_id );
        if ( is_wp_error( $result ) ) {
            return $result;
        }

        return rest_ensure_response( array( 'success' => true ) );
    }

    public static function handle_hub_remove_mod( $request ) {
        $requester_id = (int) $request->get_param( 'user_id' );
        $hub_id       = (int) $request->get_param( 'id' );
        $target_id    = (int) $request->get_param( 'userId' );

        $result = Culture_Hubs::remove_mod( $hub_id, $requester_id, $target_id );
        if ( is_wp_error( $result ) ) {
            return $result;
        }

        return rest_ensure_response( array( 'success' => true ) );
    }

    public static function handle_hub_remove_member( $request ) {
        $requester_id = (int) $request->get_param( 'user_id' );
        $hub_id       = (int) $request->get_param( 'id' );
        $target_id    = (int) $request->get_param( 'userId' );

        $result = Culture_Hubs::remove_member( $hub_id, $requester_id, $target_id );
        if ( is_wp_error( $result ) ) {
            return $result;
        }

        return rest_ensure_response( array( 'success' => true ) );
    }

    public static function handle_hub_pin_post( $request ) {
        $requester_id = (int) $request->get_param( 'user_id' );
        $hub_id       = (int) $request->get_param( 'id' );
        $post_id      = (int) $request->get_param( 'post_id' );

        $result = Culture_Hubs::pin_post( $hub_id, $requester_id, $post_id );
        if ( is_wp_error( $result ) ) {
            return $result;
        }

        return rest_ensure_response( Culture_Hubs::get_hub( $hub_id ) );
    }

    public static function handle_hub_unpin_post( $request ) {
        $requester_id = (int) $request->get_param( 'user_id' );
        $hub_id       = (int) $request->get_param( 'id' );

        $result = Culture_Hubs::unpin_post( $hub_id, $requester_id );
        if ( is_wp_error( $result ) ) {
            return $result;
        }

        return rest_ensure_response( Culture_Hubs::get_hub( $hub_id ) );
    }

    public static function handle_hub_remove_post( $request ) {
        $requester_id = (int) $request->get_param( 'user_id' );
        $hub_id       = (int) $request->get_param( 'id' );
        $post_id      = (int) $request->get_param( 'post_id' );

        $result = Culture_Hubs::remove_post( $hub_id, $requester_id, $post_id );
        if ( is_wp_error( $result ) ) {
            return $result;
        }

        return rest_ensure_response( array( 'success' => true ) );
    }


    /* ——————————————————————————————————————
     *  Analytics handler
     * —————————————————————————————————————— */

    public static function handle_member_analytics( $request ) {
        global $wpdb;
        $user_id = (int) $request->get_param( 'user_id' );
        if ( ! $user_id || ! get_userdata( $user_id ) ) {
            return new WP_Error( 'invalid_user', 'Invalid user.', array( 'status' => 400 ) );
        }

        $ledger_table = $wpdb->prefix . 'culture_credit_ledger';
        $notif_table  = $wpdb->prefix . 'culture_notifications';

        // Credits earned/spent per day — last 30 days.
        $credit_days = $wpdb->get_results( $wpdb->prepare(
            "SELECT DATE(created_at) AS day,
                    SUM(CASE WHEN amount > 0 THEN amount ELSE 0 END)  AS earned,
                    SUM(CASE WHEN amount < 0 THEN ABS(amount) ELSE 0 END) AS spent
             FROM {$ledger_table}
             WHERE user_id = %d AND created_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)
             GROUP BY DATE(created_at)
             ORDER BY day ASC",
            $user_id
        ), ARRAY_A );

        // Total credits balance.
        $balance = (int) get_user_meta( $user_id, 'culture_credits', true );

        // Total reputation.
        $reputation = (int) get_user_meta( $user_id, 'culture_reputation', true );

        // Post counts by status/type.
        $post_counts = $wpdb->get_results( $wpdb->prepare(
            "SELECT post_status, COUNT(*) AS cnt
             FROM {$wpdb->posts}
             WHERE post_author = %d AND post_type = 'culture_post'
               AND post_status IN ('publish','pending')
             GROUP BY post_status",
            $user_id
        ), ARRAY_A );
        $posts_published = 0;
        $posts_pending   = 0;
        foreach ( $post_counts as $row ) {
            if ( $row['post_status'] === 'publish' ) $posts_published = (int) $row['cnt'];
            if ( $row['post_status'] === 'pending' )  $posts_pending   = (int) $row['cnt'];
        }

        // Badge count.
        $badges = get_user_meta( $user_id, 'culture_badges', true );
        $badge_count = is_array( $badges ) ? count( $badges ) : 0;

        // Top posts by engagement (reactions + comments), last 90 days.
        $top_posts = $wpdb->get_results( $wpdb->prepare(
            "SELECT p.ID, p.post_title, p.post_date,
                    CAST(COALESCE(pm_r.meta_value,'0') AS UNSIGNED) AS reactions,
                    CAST(COALESCE(pm_c.meta_value,'0') AS UNSIGNED) AS comment_count
             FROM {$wpdb->posts} p
             LEFT JOIN {$wpdb->postmeta} pm_r ON pm_r.post_id = p.ID AND pm_r.meta_key = 'community_reactions_count'
             LEFT JOIN {$wpdb->postmeta} pm_c ON pm_c.post_id = p.ID AND pm_c.meta_key = 'community_comment_count'
             WHERE p.post_author = %d
               AND p.post_type = 'culture_post'
               AND p.post_status = 'publish'
               AND p.post_date >= DATE_SUB(NOW(), INTERVAL 90 DAY)
             ORDER BY (CAST(COALESCE(pm_r.meta_value,'0') AS UNSIGNED) + CAST(COALESCE(pm_c.meta_value,'0') AS UNSIGNED)) DESC
             LIMIT 5",
            $user_id
        ), ARRAY_A );

        // Reputation growth — monthly totals for last 6 months.
        $rep_months = $wpdb->get_results( $wpdb->prepare(
            "SELECT DATE_FORMAT(created_at, '%Y-%m') AS month, SUM(amount) AS rep_earned
             FROM {$ledger_table}
             WHERE user_id = %d AND type = 'reputation' AND amount > 0
               AND created_at >= DATE_SUB(NOW(), INTERVAL 6 MONTH)
             GROUP BY DATE_FORMAT(created_at, '%Y-%m')
             ORDER BY month ASC",
            $user_id
        ), ARRAY_A );

        // Notification count (total received).
        $notif_count = (int) $wpdb->get_var( $wpdb->prepare(
            "SELECT COUNT(*) FROM {$notif_table} WHERE user_id = %d",
            $user_id
        ) );

        return rest_ensure_response( array(
            'balance'          => $balance,
            'reputation'       => $reputation,
            'posts_published'  => $posts_published,
            'posts_pending'    => $posts_pending,
            'badge_count'      => $badge_count,
            'notification_count' => $notif_count,
            'credit_days'      => $credit_days,
            'rep_months'       => $rep_months,
            'top_posts'        => $top_posts,
        ) );
    }

    /**
     * Record an external click on a pulse story and return the destination URL.
     */
    public static function handle_pulse_click( $request ) {
        $post_id = (int) $request->get_param( 'post_id' );
        $post    = get_post( $post_id );

        if ( ! $post || 'pulse_story' !== $post->post_type ) {
            return new WP_Error( 'not_found', 'Pulse story not found.', array( 'status' => 404 ) );
        }

        $url = get_post_meta( $post_id, 'pulse_external_url', true );
        if ( empty( $url ) ) {
            return new WP_Error( 'no_url', 'No external URL for this story.', array( 'status' => 404 ) );
        }

        $current = (int) get_post_meta( $post_id, 'pulse_click_count', true );
        update_post_meta( $post_id, 'pulse_click_count', $current + 1 );

        return rest_ensure_response( array( 'url' => $url ) );
    }

    /**
     * Verify the shared API key sent by the Next.js server.
     * Key is stored in WP option 'culture_api_secret'.
     * Next.js sends:  Authorization: Bearer {CULTURE_API_SECRET}
     */
    public static function api_key_permission( $request ) {
        return self::verify_bearer_token( $request->get_header( 'Authorization' ) );
    }

    /**
     * Raw verification of a Bearer token string.
     * Only accepts the standard 'Authorization: Bearer <token>' header.
     *
     * @param string $header The Authorization header string.
     * @return bool
     */
    public static function verify_bearer_token( $header ) {
        global $wpdb;
        $stored = $wpdb->get_var(
            "SELECT option_value FROM {$wpdb->options} WHERE option_name = 'culture_api_secret'"
        );
        if ( empty( $stored ) ) {
            return false;
        }

        if ( ! empty( $header ) ) {
            $expected = 'Bearer ' . $stored;
            if ( hash_equals( $expected, (string) $header ) ) {
                return true;
            }
        }

        return false;
    }

    /**
     * Resolve a Culture_Preview token into the actual draft post/product
     * payload — see class-culture-preview.php for the full trust model.
     *
     * @param WP_REST_Request $request
     * @return WP_REST_Response|WP_Error
     */
    public static function handle_literary_request_code( $request ) {
        $result = Culture_Literary_Access::request_code( $request->get_param( 'email' ) );
        if ( is_wp_error( $result ) ) {
            return $result;
        }
        return rest_ensure_response( array( 'success' => true ) );
    }

    public static function handle_literary_verify_code( $request ) {
        $context = $request->get_param( 'context' );
        $context = in_array( $context, array_keys( Culture_Literary_Access::NEWSLETTER_LIST_BY_CONTEXT ), true ) ? $context : 'literary';
        $result  = Culture_Literary_Access::verify_code( $request->get_param( 'email' ), $request->get_param( 'code' ), $context );
        if ( is_wp_error( $result ) ) {
            return $result;
        }
        return rest_ensure_response( array_merge( array( 'success' => true ), $result ) );
    }

    public static function handle_magic_otp_request( $request ) {
        $result = Culture_Magic_OTP::request_otp( $request->get_param( 'email' ) );
        if ( is_wp_error( $result ) ) {
            return $result;
        }
        return rest_ensure_response( array( 'success' => true ) );
    }

    public static function handle_magic_otp_verify( $request ) {
        // An explicitly-sent empty list means "this code is a credential, not a
        // subscription" — the /login and /register pages send that, so signing
        // in never silently joins anyone to a mailing list. Only a caller that
        // omits the param entirely (e.g. an older client) gets the GetMeLit
        // default the subscribe widgets were originally built around.
        $list = $request->has_param( 'list' ) ? (string) $request->get_param( 'list' ) : 'getmelit';
        try {
            $user = Culture_Magic_OTP::verify_otp(
                $request->get_param( 'email' ),
                $request->get_param( 'code' ),
                $list,
                (string) $request->get_param( 'referral' )
            );
            if ( is_wp_error( $user ) ) {
                return $user;
            }
            return rest_ensure_response( self::user_profile( $user ) );
        } catch ( \Throwable $e ) {
            error_log( 'OTP verify error: ' . $e->getMessage() . ' in ' . $e->getFile() . ':' . $e->getLine() );
            return new WP_Error( 'otp_verify_error', 'Verification failed — please try again.', array( 'status' => 500 ) );
        }
    }

    /**
     * Next.js OTP — step 1: just email the code.
     * Next.js generates the code and stores it in a signed HttpOnly cookie;
     * WordPress only needs to send the email.
     */
    public static function handle_otp_send_email( $request ) {
        $email = $request->get_param( 'email' );
        $code  = $request->get_param( 'code' );
        if ( ! is_email( $email ) ) {
            return new WP_Error( 'invalid_email', __( 'Enter a valid email address.', 'culture-community' ), array( 'status' => 400 ) );
        }
        if ( preg_match( '/^\d{6}$/', $code ) !== 1 ) {
            return new WP_Error( 'invalid_code_format', __( 'Invalid code format.', 'culture-community' ), array( 'status' => 400 ) );
        }
        if ( class_exists( 'Culture_Emails' ) ) {
            Culture_Emails::send_magic_otp_email( $email, $code );
        }
        return rest_ensure_response( array( 'success' => true ) );
    }

    /**
     * Next.js OTP — step 2: find or create the WP account.
     * Next.js has already verified the code; we just handle account
     * management and list subscription here.
     */
    public static function handle_otp_find_or_create( $request ) {
        // Params are pre-sanitized by the route's sanitize_callback definitions.
        // Guard with is_string() in case any sanitize_callback ever leaks a non-scalar.
        $email_raw = $request->get_param( 'email' );
        $email     = is_string( $email_raw ) ? $email_raw : '';
        $list_raw  = $request->get_param( 'list' );
        $list      = is_string( $list_raw ) ? $list_raw : '';
        $ref_raw   = $request->get_param( 'referral' );
        $referral  = is_string( $ref_raw ) ? sanitize_key( $ref_raw ) : '';

        if ( ! is_email( $email ) ) {
            return new WP_Error( 'invalid_email', __( 'Enter a valid email address.', 'culture-community' ), array( 'status' => 400 ) );
        }
        if ( ! class_exists( 'Culture_Magic_OTP' ) ) {
            return new WP_Error( 'server_error', __( 'OTP class unavailable.', 'culture-community' ), array( 'status' => 500 ) );
        }

        try {
            $user = Culture_Magic_OTP::find_or_create_user( $email, $referral );
        } catch ( \Throwable $e ) {
            error_log( 'OTP find-or-create user error: ' . $e->getMessage() . ' in ' . $e->getFile() . ':' . $e->getLine() );
            return new WP_Error( 'otp_user_error', 'Account lookup failed — please try again.', array( 'status' => 500 ) );
        }

        if ( is_wp_error( $user ) ) {
            return $user;
        }

        if ( '' !== $list && class_exists( 'Culture_Subscribers_DB' ) ) {
            try {
                Culture_Subscribers_DB::subscribe( $email, array( $list ), $user->display_name );
            } catch ( \Throwable $e ) {
                error_log( 'OTP subscribe error: ' . $e->getMessage() . ' in ' . $e->getFile() . ':' . $e->getLine() );
            }
        }

        try {
            return rest_ensure_response( self::user_profile( $user ) );
        } catch ( \Throwable $e ) {
            error_log( 'OTP user_profile error: ' . $e->getMessage() . ' in ' . $e->getFile() . ':' . $e->getLine() );
            return new WP_Error( 'otp_profile_error', 'Account found but profile could not be loaded — please try again.', array( 'status' => 500 ) );
        }
    }

    public static function handle_preview_resolve( $request ) {
        $verified = Culture_Preview::verify_token( $request->get_param( 'token' ) );
        if ( is_wp_error( $verified ) ) {
            return $verified;
        }

        $payload = Culture_Preview::resolve( $verified['id'], $verified['type'] );
        if ( is_wp_error( $payload ) ) {
            return $payload;
        }

        return rest_ensure_response( array(
            'type' => $verified['type'],
            'item' => $payload,
        ) );
    }

    /**
     * Handle newsletter unsubscribe request from the Next.js frontend.
     *
     * Validates the HMAC token (generated when the email was sent) then removes
     * the subscriber and records the event. Returns JSON — never redirects to a
     * WordPress page — so subscribers only ever see the Next.js UI.
     *
     * @param WP_REST_Request $request
     * @return WP_REST_Response|WP_Error
     */
    public static function handle_newsletter_unsubscribe( $request ) {
        $email       = $request->get_param( 'email' );
        $token       = $request->get_param( 'token' );
        $campaign_id = $request->get_param( 'campaign_id' ) ?: null;

        if ( ! $email ) {
            return new WP_Error( 'invalid_email', 'Invalid email address', array( 'status' => 400 ) );
        }

        if ( ! Culture_Newsletter_Queue::verify_unsub_token( $email, $token ) ) {
            return new WP_Error(
                'invalid_token',
                __( 'Invalid or expired unsubscribe link.', 'culture-community' ),
                array( 'status' => 403 )
            );
        }

        // A one-click "unsubscribe from everything" — the frontend's own
        // /newsletter/unsubscribe page (unlike the email footer link, which
        // is scoped to the one list that email came from, see
        // Culture_Newsletter_Queue::handle_unsubscribe()).
        Culture_Subscribers_DB::delete_subscriber_by_email( $email );

        // Log for analytics — this lets us attribute unsubs to the campaign that triggered them.
        if ( class_exists( 'Culture_NL_Analytics' ) ) {
            Culture_NL_Analytics::log_unsub( $email, $campaign_id );
        }

        return rest_ensure_response( array(
            'success' => true,
            'message' => __( 'You have been successfully unsubscribed.', 'culture-community' ),
        ) );
    }

    /**
     * Handle newsletter subscription.
     *
     * `list` is validated against the real list registry (Culture_Newsletter_Lists)
     * rather than a hardcoded array — this is what makes a new list (a
     * custom one an admin creates, or one auto-provisioned for a Hub) usable
     * from this endpoint with zero code changes. Only 'content'/'system'
     * type lists are accepted here; 'region' rows are what `segment` picks
     * from instead.
     */
    /**
     * Unified Flutterwave webhook dispatcher.
     *
     * Flutterwave supports only one webhook URL per account. This endpoint
     * verifies the hash once and routes each event to the correct payment class
     * based on the tx_ref prefix:
     *
     *   CRSVP* / CRSVPG*  → Culture_Community_RSVP_Payment
     *   flw-svc-*          → Culture_Services_Payment
     *   flw-sub-*          → Culture_Flutterwave_Subscriptions
     *   subscription.*     → Culture_Flutterwave_Subscriptions (no tx_ref to check)
     *
     * Set this URL in the Flutterwave dashboard:
     *   {cms}/wp-json/culture/v1/flutterwave-webhook
     */
    public static function handle_flutterwave_unified_webhook( WP_REST_Request $request ): WP_REST_Response|WP_Error {
        $hash_secret = get_option( 'culture_flutterwave_webhook_hash', '' );
        if ( $hash_secret ) {
            $verif_hash = $request->get_header( 'verif-hash' ) ?: '';
            if ( ! hash_equals( $hash_secret, $verif_hash ) ) {
                return new WP_Error( 'invalid_hash', 'Invalid webhook hash.', array( 'status' => 403 ) );
            }
        }

        $payload = json_decode( $request->get_body(), true ) ?? array();
        $event   = $payload['event'] ?? '';
        $data    = $payload['data'] ?? array();
        $tx_ref  = $data['tx_ref'] ?? '';

        if ( str_starts_with( $tx_ref, 'CRSVP' ) ) {
            if ( class_exists( 'Culture_Community_RSVP_Payment' ) ) {
                Culture_Community_RSVP_Payment::dispatch_flutterwave_event( $payload );
            }
        } elseif ( str_starts_with( $tx_ref, 'flw-svc-' ) ) {
            if ( class_exists( 'Culture_Services_Payment' ) ) {
                Culture_Services_Payment::dispatch_flutterwave_event( $payload );
            }
        } elseif ( str_starts_with( $tx_ref, 'flw-sub-' ) || str_starts_with( $event, 'subscription.' ) ) {
            if ( class_exists( 'Culture_Flutterwave_Subscriptions' ) ) {
                Culture_Flutterwave_Subscriptions::dispatch_flutterwave_event( $payload );
            }
        }

        return rest_ensure_response( array( 'status' => 'ok' ) );
    }

    /* ── Creator earnings ─────────────────────────────────────────────── */

    public static function handle_creator_earnings( WP_REST_Request $request ): WP_REST_Response|WP_Error {
        if ( ! class_exists( 'Culture_Creator_Earnings' ) ) {
            return new WP_Error( 'not_available', 'Creator earnings not available.', [ 'status' => 503 ] );
        }

        $user_id  = (int) $request->get_param( 'user_id' );
        $page     = max( 1, (int) $request->get_param( 'page' ) );
        $balance  = Culture_Creator_Earnings::get_balance( $user_id );
        $history  = Culture_Creator_Earnings::get_history( $user_id, $page );
        $fee_rate = Culture_Creator_Earnings::platform_fee_rate();

        return rest_ensure_response( [
            'balance'      => $balance,
            'fee_rate'     => $fee_rate,
            'history'      => $history,
        ] );
    }

    public static function handle_creator_payout_request( WP_REST_Request $request ): WP_REST_Response|WP_Error {
        if ( ! class_exists( 'Culture_Creator_Earnings' ) ) {
            return new WP_Error( 'not_available', 'Creator earnings not available.', [ 'status' => 503 ] );
        }

        $user_id        = (int) $request->get_param( 'user_id' );
        $amount         = (float) $request->get_param( 'amount' );
        $currency       = strtoupper( (string) $request->get_param( 'currency' ) );
        $bank_code      = (string) $request->get_param( 'bank_code' );
        $account_number = (string) $request->get_param( 'account_number' );
        $account_name   = (string) $request->get_param( 'account_name' );

        $result = Culture_Creator_Earnings::request_payout(
            $user_id, $amount, $currency, $bank_code, $account_number, $account_name
        );

        if ( is_wp_error( $result ) ) {
            return $result;
        }

        return rest_ensure_response( [
            'request_id' => $result,
            'message'    => 'Payout request submitted. You will be notified when it is processed.',
        ] );
    }

    public static function handle_admin_creator_payouts( WP_REST_Request $request ): WP_REST_Response|WP_Error {
        if ( ! class_exists( 'Culture_Creator_Earnings' ) ) {
            return new WP_Error( 'not_available', 'Creator earnings not available.', [ 'status' => 503 ] );
        }

        $status = sanitize_text_field( $request->get_param( 'status' ) ?: '' );
        $page   = max( 1, (int) $request->get_param( 'page' ) );

        return rest_ensure_response(
            Culture_Creator_Earnings::get_payout_requests( $status, $page )
        );
    }

    public static function handle_admin_process_payout( WP_REST_Request $request ): WP_REST_Response|WP_Error {
        if ( ! class_exists( 'Culture_Creator_Earnings' ) ) {
            return new WP_Error( 'not_available', 'Creator earnings not available.', [ 'status' => 503 ] );
        }

        $id     = (int) $request->get_param( 'id' );
        $result = Culture_Creator_Earnings::process_payout( $id );

        if ( is_wp_error( $result ) ) {
            return $result;
        }

        return rest_ensure_response( [
            'success'  => true,
            'transfer' => $result,
        ] );
    }

    /* ── Newsletters ──────────────────────────────────────────────────── */

    public static function handle_newsletter_subscribe( $request ) {
        $email   = $request->get_param( 'email' );
        $name    = $request->get_param( 'name' ) ?: '';
        $list    = $request->get_param( 'list' ) ?: 'culture-drop';
        $segment = $request->get_param( 'segment' ) ?: '';
        $tier    = $request->get_param( 'tier' ) ?: '';

        $list_row = Culture_Newsletter_Lists::get_by_slug( $list );
        if ( ! $list_row || Culture_Newsletter_Lists::TYPE_REGION === $list_row['type'] ) {
            $list = 'culture-drop';
        }

        $allowed_segments = array( 'us', 'uk', 'ng', 'gh', 'ke', 'za', 'ca', 'au', '' );
        if ( ! in_array( $segment, $allowed_segments, true ) ) {
            $segment = '';
        }

        // 'patron' (Moveee Pro) is not stored as list membership — Pro-only
        // sends are resolved live against _culture_membership_tier at send
        // time (see Culture_Subscribers_DB::resolve_send_emails()'s 'pro'
        // branch), so $tier itself needs no persistence here.
        unset( $tier );

        $was_existing = (bool) Culture_Subscribers_DB::find_by_email( $email );

        $list_slugs = array( $list );
        if ( $segment ) {
            $list_slugs[] = $segment;
        }
        Culture_Subscribers_DB::subscribe( $email, $list_slugs, $name );

        // Award reputation to the matching WP user on their first newsletter subscription.
        // Deferred to WP-Cron so the public subscribe endpoint doesn't block on
        // the full badge evaluation chain (up to 35 DB queries via award_points).
        if ( class_exists( 'Culture_Gamification' ) ) {
            $wp_user = get_user_by( 'email', $email );
            if ( $wp_user ) {
                $already = get_user_meta( $wp_user->ID, '_culture_newsletter_subscribed_badge', true );
                if ( ! $already ) {
                    update_user_meta( $wp_user->ID, '_culture_newsletter_subscribed_badge', '1' );
                    wp_schedule_single_event( time() + 5, 'culture_award_newsletter_points', array( $wp_user->ID ) );
                }
            }
        }

        return rest_ensure_response( array(
            'success' => true,
            'message' => $was_existing
                ? __( 'You are already subscribed.', 'culture-community' )
                : __( 'Subscribed successfully.', 'culture-community' ),
        ) );
    }

    /**
     * POST /culture/v1/games-subscribe
     * Adds an email to the Moveee Games subscriber list (culture_games_subscribers).
     */
    public static function handle_games_subscribe( $request ) {
        $email = $request->get_param( 'email' );

        $subscribers = get_option( 'culture_games_subscribers', array() );

        // Check for existing subscription (handle both plain strings and object records).
        foreach ( $subscribers as $sub ) {
            $existing = is_array( $sub ) ? ( $sub['email'] ?? '' ) : $sub;
            if ( strtolower( trim( $existing ) ) === strtolower( $email ) ) {
                return rest_ensure_response( array(
                    'success' => true,
                    'message' => __( 'You are already subscribed to Moveee Games.', 'culture-community' ),
                ) );
            }
        }

        $subscribers[] = array(
            'email' => $email,
            'date'  => current_time( 'mysql' ),
        );
        update_option( 'culture_games_subscribers', $subscribers );

        return rest_ensure_response( array(
            'success' => true,
            'message' => __( 'Subscribed to Moveee Games.', 'culture-community' ),
        ) );
    }

    /**
     * Authenticate a user via WordPress credentials.
     * Returns a minimal user profile — never the password hash.
     *
     * @param WP_REST_Request $request
     * @return WP_REST_Response|WP_Error
     */
    public static function handle_login( $request ) {
        $username = $request->get_param( 'username' );
        $password = $request->get_param( 'password' );

        // wp_authenticate accepts username or email.
        $user = wp_authenticate( $username, $password );

        if ( is_wp_error( $user ) ) {
            return new WP_Error(
                'invalid_credentials',
                __( 'Invalid username or password.', 'culture-community' ),
                array( 'status' => 401 )
            );
        }

        return rest_ensure_response( self::user_profile( $user ) );
    }

    /**
     * POST /culture/v1/login-google
     * Verifies a Google ID token (via Culture_Google_Auth), finds or creates the
     * matching WP user, and returns the same profile shape as handle_login().
     *
     * @param WP_REST_Request $request
     * @return WP_REST_Response|WP_Error
     */
    public static function handle_login_google( $request ) {
        $claims = Culture_Google_Auth::verify_id_token( $request->get_param( 'id_token' ) );
        if ( is_wp_error( $claims ) ) {
            return $claims;
        }

        $user = Culture_Google_Auth::find_or_create_user( $claims );
        if ( is_wp_error( $user ) ) {
            return $user;
        }

        return rest_ensure_response( self::user_profile( $user ) );
    }

    /**
     * Register a new user from the Next.js frontend.
     *
     * @param WP_REST_Request $request
     * @return WP_REST_Response|WP_Error
     */
    public static function handle_register( $request ) {
        $username  = $request->get_param( 'username' );
        $email     = $request->get_param( 'email' );
        $password  = $request->get_param( 'password' );
        $display   = $request->get_param( 'display_name' ) ?: $username;
        $phone      = $request->get_param( 'phone' ) ?: '';
        $whatsapp   = $request->get_param( 'whatsapp' ) ?: '';
        $gender     = $request->get_param( 'gender' ) ?: '';
        $dob        = $request->get_param( 'date_of_birth' ) ?: '';
        $nationality= $request->get_param( 'nationality' ) ?: '';
        $country    = $request->get_param( 'country_of_residence' ) ?: '';
        $city       = $request->get_param( 'city' ) ?: '';
        $occupation = $request->get_param( 'occupation' ) ?: '';
        $tier       = $request->get_param( 'tier' ) ?: 'citizen';
        $referral  = $request->get_param( 'referral_code' ) ?: '';
        $plan_key  = $request->get_param( 'plan_key' ) ?: 'monthly_ngn';

        if ( strlen( $password ) < 8 ) {
            return new WP_Error(
                'weak_password',
                __( 'Password must be at least 8 characters.', 'culture-community' ),
                array( 'status' => 422 )
            );
        }

        if ( ! in_array( $tier, array( 'citizen', 'patron' ), true ) ) {
            $tier = 'citizen';
        }

        $user_id = wp_create_user( $username, $password, $email );
        if ( is_wp_error( $user_id ) ) {
            return new WP_Error(
                'registration_failed',
                $user_id->get_error_message(),
                array( 'status' => 422 )
            );
        }

        wp_update_user( array( 'ID' => $user_id, 'display_name' => $display ) );
        update_user_meta( $user_id, '_culture_membership_tier', 'citizen' );

        if ( $phone ) {
            update_user_meta( $user_id, '_culture_phone', $phone );
        }
        if ( $whatsapp ) {
            update_user_meta( $user_id, '_culture_whatsapp', $whatsapp );
        }
        if ( $gender ) {
            update_user_meta( $user_id, '_culture_gender', sanitize_text_field( $gender ) );
        }
        if ( $dob ) {
            update_user_meta( $user_id, '_culture_dob', sanitize_text_field( $dob ) );
        }
        if ( $nationality ) {
            update_user_meta( $user_id, '_culture_nationality', sanitize_text_field( $nationality ) );
        }
        if ( $country ) {
            update_user_meta( $user_id, '_culture_country_of_residence', sanitize_text_field( $country ) );
        }
        if ( $city ) {
            update_user_meta( $user_id, '_culture_city', sanitize_text_field( $city ) );
        }
        if ( $occupation ) {
            update_user_meta( $user_id, '_culture_occupation', sanitize_text_field( $occupation ) );
        }
        // Connect Directory — opt-in by default on registration
        $dir_opt_in      = $request->get_param( 'directory_opt_in' ) ?: '1';
        $dir_disciplines = $request->get_param( 'directory_disciplines' ) ?: '';
        $dir_bio         = $request->get_param( 'directory_bio' ) ?: '';

        update_user_meta( $user_id, '_culture_directory_opt_in', $dir_opt_in === '1' ? '1' : '0' );
        if ( $dir_disciplines ) {
            update_user_meta( $user_id, '_culture_directory_disciplines', sanitize_text_field( $dir_disciplines ) );
        }
        if ( $dir_bio ) {
            update_user_meta( $user_id, '_culture_directory_bio', sanitize_textarea_field( $dir_bio ) );
        }

        update_user_meta( $user_id, '_culture_points', 0 );
        update_user_meta( $user_id, '_culture_badges', array() );

        // Process referral if present.
        if ( ! empty( $referral ) && class_exists( 'Culture_Referrals' ) ) {
            $_COOKIE['culture_ref'] = $referral;
            Culture_Referrals::process_referral( $user_id );
        }

        // Generate email verification token (valid for 24 hours).
        $verify_token = wp_generate_password( 32, false );
        update_user_meta( $user_id, '_culture_email_verify_token', wp_hash( $verify_token ) );
        update_user_meta( $user_id, '_culture_email_verify_expires', time() + DAY_IN_SECONDS );
        update_user_meta( $user_id, '_culture_email_verified', '0' );

        $next_url = sanitize_text_field( $request->get_param( 'next' ) ?: '' );

        if ( class_exists( 'Culture_Emails' ) ) {
            Culture_Emails::send_verification_email( $user_id, $verify_token, $next_url );
        }

        return rest_ensure_response( array(
            'success'               => true,
            'requires_verification' => true,
            'user_id'               => $user_id,
            'username'              => get_userdata( $user_id )->user_login,
        ) );
    }

    /**
     * POST /culture/v1/nominate-icon
     * Allows Culture Authority (or higher) members to nominate someone for Culture Icon.
     * Sets _culture_icon_nominated = 1 on the nominee. One nomination per nominator per day.
     */
    public static function handle_nominate_icon( $request ) {
        $nominator_id = (int) $request->get_param( 'nominator_id' );
        $nominee_id   = (int) $request->get_param( 'nominee_id' );

        if ( ! get_userdata( $nominator_id ) || ! get_userdata( $nominee_id ) ) {
            return new WP_Error( 'not_found', 'User not found.', array( 'status' => 404 ) );
        }
        if ( $nominator_id === $nominee_id ) {
            return new WP_Error( 'self_nominate', 'You cannot nominate yourself.', array( 'status' => 400 ) );
        }

        // Nominator must be Culture Authority or Culture Icon.
        $rep       = class_exists( 'Culture_Gamification' ) ? Culture_Gamification::get_reputation( $nominator_id ) : 0;
        $tier      = class_exists( 'Culture_Gamification' ) ? Culture_Gamification::get_reputation_tier( $rep, $nominator_id ) : 'member';
        $auth_tiers = array( 'culture-authority', 'culture-icon' );
        if ( ! in_array( $tier, $auth_tiers, true ) ) {
            return new WP_Error( 'tier_required', 'Only Culture Authority members can nominate for Culture Icon.', array( 'status' => 403 ) );
        }

        // Rate-limit: one nomination per nominator per day.
        $rate_key = 'culture_icon_nom_' . $nominator_id;
        if ( get_transient( $rate_key ) ) {
            return new WP_Error( 'rate_limited', 'You can only submit one nomination per day.', array( 'status' => 429 ) );
        }
        set_transient( $rate_key, 1, DAY_IN_SECONDS );

        update_user_meta( $nominee_id, '_culture_icon_nominated', 1 );
        update_user_meta( $nominee_id, '_culture_icon_nominated_by', $nominator_id );
        update_user_meta( $nominee_id, '_culture_icon_nominated_at', current_time( 'mysql' ) );

        return rest_ensure_response( array( 'success' => true, 'nominee_id' => $nominee_id ) );
    }

    /**
     * GET /culture/v1/community-blocklist
     * Returns admin-configured blocked phrases so the Next.js layer can enforce them.
     * The default hardcoded list lives in lib/spam-protection.ts; this endpoint
     * only returns custom additions made via WP Admin → Settings → Moderation.
     */
    public static function handle_get_community_blocklist() {
        global $wpdb;
        $rows = $wpdb->get_results(
            "SELECT option_name, option_value FROM {$wpdb->options}
             WHERE option_name IN ('culture_community_blocklist','culture_new_member_review_days')",
            ARRAY_A
        );
        $opts = array_column( $rows, 'option_value', 'option_name' );

        $raw     = $opts['culture_community_blocklist'] ?? '';
        $phrases = array_values( array_filter(
            array_map( 'trim', explode( "\n", $raw ) ),
            function ( $line ) { return strlen( $line ) > 1; }
        ) );
        $review_days = (int) ( $opts['culture_new_member_review_days'] ?? 7 );

        return rest_ensure_response( array(
            'phrases'     => $phrases,
            'review_days' => $review_days,
        ) );
    }

    /**
     * POST /culture/v1/verify-email
     * Validates the one-time token issued after registration.
     * Does not consume the token — the user can reload the complete-profile page.
     */
    public static function handle_verify_email( $request ) {
        $user_id = (int) $request->get_param( 'uid' );
        $token   = $request->get_param( 'token' );

        $user = get_userdata( $user_id );
        if ( ! $user ) {
            return new WP_Error( 'not_found', __( 'Invalid verification link.', 'culture-community' ), array( 'status' => 404 ) );
        }

        $stored_hash = get_user_meta( $user_id, '_culture_email_verify_token', true );
        $expires     = (int) get_user_meta( $user_id, '_culture_email_verify_expires', true );

        if ( ! $stored_hash || ! hash_equals( $stored_hash, wp_hash( $token ) ) ) {
            return new WP_Error( 'invalid_token', __( 'Verification link is invalid.', 'culture-community' ), array( 'status' => 400 ) );
        }

        if ( time() > $expires ) {
            return new WP_Error( 'token_expired', __( 'Verification link has expired. Please register again.', 'culture-community' ), array( 'status' => 410 ) );
        }

        return rest_ensure_response( array(
            'success'      => true,
            'user_id'      => $user_id,
            'username'     => $user->user_login,
            'display_name' => $user->display_name,
            'email'        => $user->user_email,
        ) );
    }

    /**
     * POST /culture/v1/complete-profile
     * Saves KYC fields and membership tier after email verification.
     * Consumes the verification token and sends the welcome email.
     */
    public static function handle_complete_profile( $request ) {
        $user_id  = (int) $request->get_param( 'uid' );
        $token    = $request->get_param( 'token' );
        $tier     = $request->get_param( 'tier' ) ?: 'citizen';
        $plan_key = $request->get_param( 'plan_key' ) ?: 'monthly_ngn';

        $user = get_userdata( $user_id );
        if ( ! $user ) {
            return new WP_Error( 'not_found', __( 'User not found.', 'culture-community' ), array( 'status' => 404 ) );
        }

        $stored_hash = get_user_meta( $user_id, '_culture_email_verify_token', true );
        $expires     = (int) get_user_meta( $user_id, '_culture_email_verify_expires', true );

        if ( ! $stored_hash || ! hash_equals( $stored_hash, wp_hash( $token ) ) ) {
            return new WP_Error( 'invalid_token', __( 'Verification link is invalid.', 'culture-community' ), array( 'status' => 400 ) );
        }

        if ( time() > $expires ) {
            return new WP_Error( 'token_expired', __( 'Verification link has expired.', 'culture-community' ), array( 'status' => 410 ) );
        }

        // Save KYC fields.
        $meta_map = array(
            'date_of_birth'        => '_culture_dob',
            'country_of_residence' => '_culture_country_of_residence',
            'city'                 => '_culture_city',
            'occupation'           => '_culture_occupation',
        );
        foreach ( $meta_map as $param => $meta_key ) {
            $val = $request->get_param( $param );
            if ( $val ) {
                update_user_meta( $user_id, $meta_key, sanitize_text_field( $val ) );
            }
        }

        // Save interests.
        $interests_raw = $request->get_param( 'interests' );
        if ( is_array( $interests_raw ) && count( $interests_raw ) >= 3 ) {
            $allowed_interests = array(
                'fashion-streetwear', 'food-drink', 'live-music', 'music-production',
                'independent-film', 'visual-art', 'architecture', 'photography',
                'literature', 'visual-design', 'tech-culture', 'sport-wellness',
                'travel', 'ideas', 'street-food', 'nightlife',
            );
            $valid_interests = array_values( array_filter( array_map( 'sanitize_key', $interests_raw ), function( $s ) use ( $allowed_interests ) {
                return in_array( $s, $allowed_interests, true );
            } ) );
            if ( ! empty( $valid_interests ) ) {
                update_user_meta( $user_id, '_culture_interests', wp_json_encode( $valid_interests ) );
            }
        }

        if ( ! in_array( $tier, array( 'citizen', 'lit', 'patron' ), true ) ) {
            $tier = 'citizen';
        }
        // Lit/Patron users start as citizen until payment completes — see
        // handle_upgrade_init()/the Paystack/Stripe webhooks, which grant
        // the real tier once the checkout below actually succeeds.
        update_user_meta( $user_id, '_culture_membership_tier', 'citizen' );

        // Mark email as verified and consume the token.
        $was_unverified = get_user_meta( $user_id, '_culture_email_verified', true ) !== '1';
        update_user_meta( $user_id, '_culture_email_verified', '1' );
        delete_user_meta( $user_id, '_culture_email_verify_token' );
        delete_user_meta( $user_id, '_culture_email_verify_expires' );

        // Award reputation for email verification (once only).
        if ( $was_unverified && class_exists( 'Culture_Gamification' ) ) {
            Culture_Gamification::award_points( $user_id, 'email_verified' );
        }

        // Award reputation for profile completion (once only).
        if ( class_exists( 'Culture_Gamification' ) ) {
            $already_completed = get_user_meta( $user_id, '_culture_profile_completed', true );
            if ( ! $already_completed ) {
                update_user_meta( $user_id, '_culture_profile_completed', '1' );
                Culture_Gamification::award_points( $user_id, 'profile_completed' );
            }
        }

        // Send welcome email now that all data is in place.
        if ( class_exists( 'Culture_Emails' ) ) {
            Culture_Emails::send_welcome_email( $user_id );
        }

        // Paid tier (Lit or Patron) — return payment checkout URL.
        if ( in_array( $tier, array( 'lit', 'patron' ), true ) ) {
            $checkout_url = '';
            if ( strpos( $plan_key, '_ngn' ) !== false && class_exists( 'Culture_Flutterwave_Subscriptions' ) ) {
                $checkout_url = Culture_Flutterwave_Subscriptions::get_checkout_url( $user_id, $plan_key, $tier );
            } elseif ( strpos( $plan_key, '_usd' ) !== false && class_exists( 'Culture_Stripe' ) ) {
                $checkout_url = Culture_Stripe::get_checkout_url( $user_id, $plan_key, $tier );
            }
            if ( $checkout_url ) {
                return rest_ensure_response( array(
                    'success'          => true,
                    'requires_payment' => true,
                    'checkout_url'     => $checkout_url,
                ) );
            }
        }

        return rest_ensure_response( array(
            'success'          => true,
            'requires_payment' => false,
            'username'         => $user->user_login,
        ) );
    }

    /**
     * POST /culture/v1/account/delete-request
     * Web-surface account deletion, step 1 — see class-culture-account-deletion.php.
     */
    public static function handle_account_delete_request( $request ) {
        $user_id = (int) $request->get_param( 'user_id' );
        $result  = Culture_Account_Deletion::request_deletion( $user_id );
        if ( is_wp_error( $result ) ) {
            return $result;
        }
        return rest_ensure_response( array( 'success' => true ) );
    }

    /**
     * POST /culture/v1/account/delete-confirm
     * Web-surface account deletion, step 2 — see class-culture-account-deletion.php.
     */
    public static function handle_account_delete_confirm( $request ) {
        $user_id = (int) $request->get_param( 'uid' );
        $token   = $request->get_param( 'token' );
        $result  = Culture_Account_Deletion::confirm_deletion( $user_id, $token );
        if ( is_wp_error( $result ) ) {
            return $result;
        }
        return rest_ensure_response( array( 'success' => true ) );
    }

    /**
     * Build a safe user profile array (no password hash, no secrets).
     * Includes all KYC fields and gamification data.
     *
     * @param WP_User $user
     * @return array
     */
    private static function user_profile( $user ) {
        $referral_code  = get_user_meta( $user->ID, '_culture_referral_code', true ) ?: '';
        $referral_count = 0;
        if ( $referral_code && class_exists( 'Culture_Referrals' ) ) {
            $referral_count = Culture_Referrals::get_referral_count( $user->ID );
        }

        // WP super-admins and admins always get patron access on the frontend
        // so they're never blocked by tier-gated features.
        $stored_tier = get_user_meta( $user->ID, '_culture_membership_tier', true ) ?: 'citizen';
        $tier = ( is_super_admin( $user->ID ) || user_can( $user, 'manage_options' ) )
            ? 'patron'
            : $stored_tier;

        // Vendor status — check WCFM vendor roles.
        $vendor_roles = array( 'wcfm_vendor', 'seller', 'vendor', 'wcfm_affiliate' );
        $is_vendor    = (bool) array_intersect( $vendor_roles, (array) $user->roles )
                        || (bool) get_user_meta( $user->ID, '_wcfm_vendor_data', true );
        $vendor_slug  = $is_vendor ? $user->user_nicename : '';

        return array(
            // Core identity
            'id'                  => $user->ID,
            'username'            => $user->user_login,
            'email'               => $user->user_email,
            'display_name'        => $user->display_name,
            'registered_at'       => strtotime( $user->user_registered ),
            // Contact
            'phone'               => get_user_meta( $user->ID, '_culture_phone', true ) ?: '',
            'whatsapp'            => get_user_meta( $user->ID, '_culture_whatsapp', true ) ?: '',
            // KYC
            'gender'              => get_user_meta( $user->ID, '_culture_gender', true ) ?: '',
            'date_of_birth'       => get_user_meta( $user->ID, '_culture_dob', true ) ?: '',
            'nationality'         => get_user_meta( $user->ID, '_culture_nationality', true ) ?: '',
            'country_of_residence'=> get_user_meta( $user->ID, '_culture_country_of_residence', true ) ?: '',
            'city'                => get_user_meta( $user->ID, '_culture_city', true ) ?: '',
            'occupation'          => get_user_meta( $user->ID, '_culture_occupation', true ) ?: '',
            // Membership
            'tier'                => $tier,
            // Gamification — credits & reputation (Phase 2)
            'credits'             => class_exists( 'Culture_Gamification' ) ? Culture_Gamification::get_credits( $user->ID ) : 0,
            'reputation'          => class_exists( 'Culture_Gamification' ) ? Culture_Gamification::get_reputation( $user->ID ) : (int) get_user_meta( $user->ID, '_culture_points', true ),
            'reputation_tier'     => class_exists( 'Culture_Gamification' ) ? Culture_Gamification::get_reputation_tier( Culture_Gamification::get_reputation( $user->ID ) ) : 'member',
            'daily_credits_remaining' => class_exists( 'Culture_Gamification' ) ? Culture_Gamification::get_daily_credits_remaining( $user->ID ) : 50,
            // Legacy field — points now mirrors reputation for backwards compat
            'points'              => class_exists( 'Culture_Gamification' ) ? Culture_Gamification::get_reputation( $user->ID ) : (int) get_user_meta( $user->ID, '_culture_points', true ),
            'badges'              => class_exists( 'Culture_Gamification' ) ? Culture_Gamification::get_badges( $user->ID ) : array(),
            'referral_code'       => $referral_code,
            'referral_count'      => $referral_count,
            'visual_downloads_today' => self::get_daily_visual_downloads( $user->ID ),
            // Interests (Phase 1)
            'interests'           => json_decode( get_user_meta( $user->ID, '_culture_interests', true ) ?: '[]', true ) ?: array(),
            // Vendor
            'is_vendor'           => $is_vendor,
            'vendor_slug'         => $vendor_slug,
            // Profile photo
            'avatar_url'          => get_user_meta( $user->ID, '_culture_avatar_url', true ) ?: '',
            // Passkeys (Phase 7)
            'has_passkey'         => (bool) get_user_meta( $user->ID, '_culture_has_passkey', true ),
            'passkey_count'       => (int) get_user_meta( $user->ID, '_culture_passkey_count', true ),
            'credits_escrowed'    => (int) get_user_meta( $user->ID, '_culture_credits_escrowed', true ),
        );
    }

    /**
     * Update writable profile fields for the authenticated user.
     * Accepts: display_name, phone, whatsapp, gender, date_of_birth,
     *          nationality, country_of_residence, city, occupation.
     * Email changes are intentionally excluded — they require a separate
     * confirmation flow to avoid account takeover.
     */
    public static function handle_update_user_profile( $request ) {
        $user_id = (int) $request->get_param( 'user_id' );
        if ( ! $user_id ) {
            return new WP_Error( 'missing_user_id', 'user_id is required.', array( 'status' => 400 ) );
        }

        $user = get_userdata( $user_id );
        if ( ! $user ) {
            return new WP_Error( 'not_found', 'User not found.', array( 'status' => 404 ) );
        }

        $wp_update = array( 'ID' => $user_id );

        if ( $request->has_param( 'display_name' ) ) {
            $name = sanitize_text_field( $request->get_param( 'display_name' ) );
            if ( $name ) $wp_update['display_name'] = $name;
        }

        if ( count( $wp_update ) > 1 ) {
            $result = wp_update_user( $wp_update );
            if ( is_wp_error( $result ) ) {
                return new WP_Error( 'update_failed', $result->get_error_message(), array( 'status' => 422 ) );
            }
        }

        // Meta fields
        $meta_map = array(
            'phone'                  => '_culture_phone',
            'whatsapp'               => '_culture_whatsapp',
            'gender'                 => '_culture_gender',
            'date_of_birth'          => '_culture_dob',
            'nationality'            => '_culture_nationality',
            'country_of_residence'   => '_culture_country_of_residence',
            'city'                   => '_culture_city',
            'occupation'             => '_culture_occupation',
            // Connect Directory
            'directory_disciplines'  => '_culture_directory_disciplines',
            'directory_instagram'    => '_culture_directory_instagram',
            'directory_twitter'      => '_culture_directory_twitter',
            'directory_linkedin'     => '_culture_directory_linkedin',
            'directory_website'      => '_culture_directory_website',
            'avatar_url'             => '_culture_avatar_url',
            'cover_photo_url'        => '_culture_cover_photo_url',
        );

        foreach ( $meta_map as $param => $meta_key ) {
            if ( $request->has_param( $param ) ) {
                update_user_meta( $user_id, $meta_key, sanitize_text_field( $request->get_param( $param ) ) );
            }
        }

        // Bio allows newlines — use textarea sanitization
        if ( $request->has_param( 'directory_bio' ) ) {
            update_user_meta( $user_id, '_culture_directory_bio', sanitize_textarea_field( $request->get_param( 'directory_bio' ) ) );
        }

        // directory_opt_in is boolean — store as '1' or '0'
        if ( $request->has_param( 'directory_opt_in' ) ) {
            $opt_in_val = $request->get_param( 'directory_opt_in' );
            update_user_meta( $user_id, '_culture_directory_opt_in', ( $opt_in_val === '1' || $opt_in_val === true ) ? '1' : '0' );
        }

        // Interests (Phase 1) — array of interest slugs.
        if ( $request->has_param( 'interests' ) ) {
            $interests_raw = $request->get_param( 'interests' );
            if ( is_array( $interests_raw ) ) {
                $allowed_interests = array(
                    'fashion-streetwear', 'food-drink', 'live-music', 'music-production',
                    'independent-film', 'visual-art', 'architecture', 'photography',
                    'literature', 'visual-design', 'tech-culture', 'sport-wellness',
                    'travel', 'ideas', 'street-food', 'nightlife',
                );
                $valid = array_values( array_filter( array_map( 'sanitize_key', $interests_raw ), function( $s ) use ( $allowed_interests ) {
                    return in_array( $s, $allowed_interests, true );
                } ) );
                update_user_meta( $user_id, '_culture_interests', wp_json_encode( $valid ) );
            }
        }

        $updated_user = get_userdata( $user_id );
        return rest_ensure_response( self::user_profile( $updated_user ) );
    }

    /**
     * GET /culture/v1/newsletter-preferences
     * Returns per-newsletter subscription state for the given email address.
     * State is stored in user meta '_culture_newsletter_prefs' as an assoc array.
     */
    public static function handle_get_newsletter_preferences( $request ) {
        $email = sanitize_email( $request->get_param( 'email' ) );
        if ( ! is_email( $email ) ) {
            return new WP_Error( 'invalid_email', 'A valid email is required.', array( 'status' => 400 ) );
        }

        $user  = get_user_by( 'email', $email );
        $prefs = array(
            'cultural-digest' => true,
            'getmelit'        => true,
            'culture-drop'    => true,
            'events'          => true,
            'announcements'   => true,
        );

        if ( $user ) {
            $stored = get_user_meta( $user->ID, '_culture_newsletter_prefs', true );
            if ( is_array( $stored ) ) {
                $prefs = array_merge( $prefs, $stored );
            }
        }

        return rest_ensure_response( array( 'subscriptions' => $prefs ) );
    }

    /**
     * POST /culture/v1/newsletter-preferences
     * Saves per-newsletter subscription state for a user.
     * Body: { email, subscriptions: { 'cultural-digest': bool, ... } }
     */
    public static function handle_update_newsletter_preferences( $request ) {
        $email = sanitize_email( $request->get_param( 'email' ) );
        if ( ! is_email( $email ) ) {
            return new WP_Error( 'invalid_email', 'A valid email is required.', array( 'status' => 400 ) );
        }

        $subs = $request->get_param( 'subscriptions' );
        if ( ! is_array( $subs ) ) {
            return new WP_Error( 'invalid_subs', 'subscriptions must be an object.', array( 'status' => 400 ) );
        }

        $allowed = array( 'cultural-digest', 'getmelit', 'culture-drop', 'events', 'announcements' );
        $clean   = array();
        foreach ( $allowed as $key ) {
            if ( isset( $subs[ $key ] ) ) {
                $clean[ $key ] = (bool) $subs[ $key ];
            }
        }

        $user = get_user_by( 'email', $email );
        if ( $user ) {
            update_user_meta( $user->ID, '_culture_newsletter_prefs', $clean );

            // Mirror to the subscriber table based on 'cultural-digest' state
            // — preserves this endpoint's existing (pre-list-model) behaviour
            // of creating/removing a bare subscriber record with no list
            // membership at all when toggled here.
            $wants_main = $clean['cultural-digest'] ?? true;
            $in_list    = (bool) Culture_Subscribers_DB::find_by_email( $email );

            if ( $wants_main && ! $in_list ) {
                Culture_Subscribers_DB::get_or_create( $email, $user->display_name, '', $user->ID );
            } elseif ( ! $wants_main && $in_list ) {
                Culture_Subscribers_DB::delete_subscriber_by_email( $email );
            }
        }

        return rest_ensure_response( array( 'success' => true, 'subscriptions' => $clean ) );
    }

    /**
     * Send a password-reset email.
     * Never reveals whether the email exists to avoid user enumeration.
     *
     * @param WP_REST_Request $request
     * @return WP_REST_Response
     */
    public static function handle_forgot_password( $request ) {
        $email = $request->get_param( 'email' );
        $user  = get_user_by( 'email', $email );

        // Always respond with success to prevent user-enumeration attacks.
        if ( ! $user ) {
            return rest_ensure_response( array( 'success' => true ) );
        }

        $key = get_password_reset_key( $user );
        if ( is_wp_error( $key ) ) {
            return rest_ensure_response( array( 'success' => true ) );
        }

        $frontend_url = rtrim( get_option( 'culture_frontend_url', home_url( '/' ) ), '/' );
        $reset_url    = $frontend_url
            . '/reset-password?key=' . rawurlencode( $key )
            . '&login='              . rawurlencode( $user->user_login );

        $site_name = get_bloginfo( 'name' );
        $subject   = sprintf( __( 'Reset your password — %s', 'culture-community' ), $site_name );
        $message   = sprintf(
            /* translators: 1: display name, 2: site name, 3: reset URL */
            __( "Hi %1\$s,\n\nSomeone requested a password reset for your account on %2\$s. If this was you, click the link below:\n\n%3\$s\n\nThis link expires in 24 hours. If you did not request a reset, you can safely ignore this email.\n\n— %2\$s", 'culture-community' ),
            $user->display_name,
            $site_name,
            $reset_url
        );

        wp_mail( $user->user_email, $subject, $message );

        return rest_ensure_response( array( 'success' => true ) );
    }

    /**
     * Validate a password-reset key and set a new password.
     *
     * @param WP_REST_Request $request
     * @return WP_REST_Response|WP_Error
     */
    public static function handle_reset_password( $request ) {
        $login    = $request->get_param( 'login' );
        $key      = $request->get_param( 'key' );
        $password = $request->get_param( 'password' );

        if ( strlen( $password ) < 8 ) {
            return new WP_Error(
                'weak_password',
                __( 'Password must be at least 8 characters.', 'culture-community' ),
                array( 'status' => 422 )
            );
        }

        $user = check_password_reset_key( $key, $login );
        if ( is_wp_error( $user ) ) {
            return new WP_Error(
                'invalid_key',
                __( 'This reset link has expired or is invalid. Please request a new one.', 'culture-community' ),
                array( 'status' => 400 )
            );
        }

        reset_password( $user, $password );

        return rest_ensure_response( array(
            'success' => true,
            'message' => __( 'Password updated. You can now sign in.', 'culture-community' ),
        ) );
    }

    /**
     * Permission check: user must be logged in.
     */
    public static function user_permission( $request ) {
        return is_user_logged_in();
    }

    /**
     * Handle creating a new quote. Backs both the web composer's Quote
     * template (via /api/quotes/create) and the mobile composer's Quote
     * template (via handle_submit_quote()'s delegate below) — this is real,
     * live infrastructure, not part of the retired standalone /quotes
     * browsing product.
     */
    /**
     * A directory link is only stored when it names a real, published
     * culture_directory entry — a stale or hostile id is dropped silently
     * rather than failing the whole submission, since the link is an
     * optional enrichment and the quote itself is still perfectly valid
     * without it.
     *
     * @return int 0 when there is nothing valid to link.
     */
    private static function resolve_directory_link( $raw_id ) : int {
        $id = absint( $raw_id );
        if ( ! $id ) {
            return 0;
        }
        $post = get_post( $id );
        if ( ! $post || 'culture_directory' !== $post->post_type || 'publish' !== $post->post_status ) {
            return 0;
        }
        return $id;
    }

    public static function handle_create_quote( $request ) {
        $text    = $request->get_param( 'text' );
        $author  = $request->get_param( 'author' );
        $source  = $request->get_param( 'source' );

        // If user_id is passed and we're authenticated via API key, use it.
        // Otherwise, fallback to the logged-in session user, and finally to
        // the synthetic "Moveee" system author (Culture_System_Author) for
        // quotes with no real submitter at all — e.g. an editorially-seeded
        // quote posted with user_id=0 from an unauthenticated API-key
        // request. Never leave post_author at 0: get_userdata(0) returns
        // false everywhere downstream (get_quote_feed_items()'s
        // communityAuthor fields in particular).
        $user_id = (int) $request->get_param( 'user_id' );
        if ( ! $user_id ) {
            $user_id = get_current_user_id();
        }
        if ( ! $user_id && class_exists( 'Culture_System_Author' ) ) {
            $user_id = (int) Culture_System_Author::get_id();
        }

        // Duplicate detection: compare normalised content hash.
        $hash = md5( strtolower( trim( wp_strip_all_tags( $text ) ) ) );
        $existing = get_posts( array(
            'post_type'      => 'culture_quote',
            'post_status'    => array( 'publish', 'pending' ),
            'posts_per_page' => 1,
            'meta_query'     => array(
                array(
                    'key'     => '_quote_content_hash',
                    'value'   => $hash,
                    'compare' => '=',
                ),
            ),
        ) );

        if ( ! empty( $existing ) ) {
            return new WP_Error(
                'duplicate_quote',
                'This quote already exists in the archive.',
                array( 'status' => 409 )
            );
        }

        // Create the post.
        $post_id = wp_insert_post( array(
            'post_title'   => wp_trim_words( $text, 10 ),
            'post_content' => $text,
            'post_status'  => 'publish',
            'post_type'    => 'culture_quote',
            'post_author'  => $user_id,
        ) );

        if ( is_wp_error( $post_id ) ) {
            return $post_id;
        }

        // Set author taxonomy.
        wp_set_object_terms( $post_id, $author, 'culture_quote_author' );

        // Set meta.
        update_post_meta( $post_id, '_quote_source', $source );
        update_post_meta( $post_id, '_quote_user_id', $user_id );
        update_post_meta( $post_id, '_quote_likes', 0 );
        update_post_meta( $post_id, '_quote_reports', 0 );
        update_post_meta( $post_id, '_quote_content_hash', $hash );
        update_post_meta( $post_id, '_culture_like_count', 0 );

        // New fields: sharing reason + quote type.
        $sharing_reason = $request->get_param( 'sharing_reason' );
        if ( $sharing_reason ) {
            update_post_meta( $post_id, '_quote_sharing_reason', sanitize_textarea_field( $sharing_reason ) );
        }
        $quote_type = $request->get_param( 'quote_type' );
        $allowed_types = array( 'Person', 'Book', 'Film', 'Speech', 'Song' );
        if ( $quote_type && in_array( $quote_type, $allowed_types, true ) ) {
            update_post_meta( $post_id, '_quote_type', sanitize_text_field( $quote_type ) );
        }

        // Directory links (September 2026). A quote points at up to two
        // things: the work it came from and the person who said it. Both are
        // optional — a proverb, an overheard line, or a Speech-type quote
        // (which has no culture_dir_type at all) legitimately has neither,
        // so this is never a requirement, only an upgrade.
        //
        // The work reuses `_linked_directory_id`, the same key community
        // posts use, so every reverse-lookup that already queries it keeps
        // working. Safe because the two readers that aggregate off it —
        // Culture_Directory::recompute_directory_aggregates() and
        // Culture_Reading_Tracker::get_reading_stats() — both scope their
        // query to post_type = 'culture_post', so a quote can never inflate
        // a review count, a star average, or a rating histogram.
        $work_id = self::resolve_directory_link( $request->get_param( 'linked_directory_id' ) );
        if ( $work_id ) {
            update_post_meta( $post_id, '_linked_directory_id', $work_id );
        }
        $author_dir_id = self::resolve_directory_link( $request->get_param( 'quote_author_directory_id' ) );
        if ( $author_dir_id ) {
            update_post_meta( $post_id, '_quote_author_directory_id', $author_dir_id );
        }

        // Award points.
        if ( class_exists( 'Culture_Gamification' ) ) {
            Culture_Gamification::award_points( $user_id, 'quote_submission' );
        }

        return rest_ensure_response( array(
            'success' => true,
            'id'      => $post_id,
            'message' => __( 'Quote published successfully.', 'culture-community' ),
        ) );
    }

    /**
     * GET /culture/v1/games/trivia-daily
     * Returns today's cached trivia questions for a given slot, or 404 if not generated yet.
     */
    public static function handle_get_trivia_daily( $request ) {
        $date = gmdate( 'Y-m-d' );
        $slot = max( 1, min( 5, (int) ( $request->get_param( 'slot' ) ?: 1 ) ) );
        $key  = 'culture_games_trivia_' . $date . '_slot_' . $slot;
        // Legacy fallback: slot 1 may have been cached without slot suffix
        if ( $slot === 1 ) {
            $cached = get_option( $key, get_option( 'culture_games_trivia_' . $date, null ) );
        } else {
            $cached = get_option( $key, null );
        }

        if ( null === $cached || ! is_array( $cached ) ) {
            return new WP_Error( 'not_found', 'No trivia cached for today/slot.', array( 'status' => 404 ) );
        }

        return rest_ensure_response( array( 'date' => $date, 'slot' => $slot, 'questions' => $cached ) );
    }

    /**
     * POST /culture/v1/games/trivia-daily
     * Stores today's trivia questions for a given slot. Cleans up yesterday's options.
     */
    public static function handle_set_trivia_daily( $request ) {
        $questions = $request->get_param( 'questions' );
        $slot      = max( 1, min( 5, (int) ( $request->get_param( 'slot' ) ?: 1 ) ) );

        if ( ! is_array( $questions ) || empty( $questions ) ) {
            return new WP_Error( 'invalid', 'questions must be a non-empty array.', array( 'status' => 400 ) );
        }

        $date      = gmdate( 'Y-m-d' );
        $yesterday = gmdate( 'Y-m-d', strtotime( '-1 day' ) );
        $key       = 'culture_games_trivia_' . $date . '_slot_' . $slot;

        update_option( $key, $questions, false );
        // Clean up all yesterday's slots
        for ( $s = 1; $s <= 5; $s++ ) {
            delete_option( 'culture_games_trivia_' . $yesterday . '_slot_' . $s );
        }
        delete_option( 'culture_games_trivia_' . $yesterday );

        return rest_ensure_response( array( 'success' => true, 'date' => $date, 'slot' => $slot ) );
    }

    /** Max credits awarded for a perfect score, per game type. */
    const GAME_MAX_CREDITS = array(
        'trivia'        => 50,
        'who-said-it'   => 30,
    );

    /**
     * POST /culture/v1/games/complete
     * Records a completed game play and awards credits proportional to score.
     * Expects user_id (set by caller from auth context), game_type, score, max_score.
     */
    public static function handle_games_complete( $request ) {
        global $wpdb;

        $user_id   = (int) $request->get_param( 'user_id' );
        $game_type = sanitize_key( (string) $request->get_param( 'game_type' ) );
        $score     = max( 0, (int) $request->get_param( 'score' ) );
        $max_score = max( 1, (int) $request->get_param( 'max_score' ) );

        if ( ! get_userdata( $user_id ) ) {
            return new WP_Error( 'not_found', 'User not found.', array( 'status' => 404 ) );
        }
        if ( ! isset( self::GAME_MAX_CREDITS[ $game_type ] ) ) {
            return new WP_Error( 'invalid', 'Unknown game_type.', array( 'status' => 400 ) );
        }

        $score          = min( $score, $max_score );
        $max_credits    = self::GAME_MAX_CREDITS[ $game_type ];
        $credits_amount = (int) round( ( $score / $max_score ) * $max_credits );

        $table = $wpdb->prefix . 'culture_game_history';
        $wpdb->insert( $table, array(
            'user_id'        => $user_id,
            'game_type'      => $game_type,
            'score'          => $score,
            'max_score'      => $max_score,
            'credits_earned' => 0, // filled in below once we know the actual awarded amount
            'played_date'    => gmdate( 'Y-m-d' ),
            'created_at'     => current_time( 'mysql' ),
        ) );
        $history_id = (int) $wpdb->insert_id;

        $awarded = Culture_Gamification::award_credits( $user_id, $credits_amount, 'game_completed', $history_id );
        $wpdb->update( $table, array( 'credits_earned' => $awarded ), array( 'id' => $history_id ) );
        if ( $awarded > 0 ) {
            Culture_Gamification::award_reputation( $user_id, Culture_Gamification::get_point_value( 'game_completed' ), 'game_completed', $history_id );
        }

        return rest_ensure_response( array(
            'success'        => true,
            'id'             => $history_id,
            'credits_earned' => $awarded,
        ) );
    }

    /**
     * GET /culture/v1/games/history
     * Paginated list of a user's past game plays, newest first.
     */
    public static function handle_games_history( $request ) {
        global $wpdb;

        $user_id  = (int) $request->get_param( 'user_id' );
        $per_page = min( max( 1, (int) ( $request->get_param( 'per_page' ) ?: 20 ) ), 100 );
        $page     = max( 1, (int) ( $request->get_param( 'page' ) ?: 1 ) );
        $offset   = ( $page - 1 ) * $per_page;

        if ( ! get_userdata( $user_id ) ) {
            return new WP_Error( 'not_found', 'User not found.', array( 'status' => 404 ) );
        }

        $table = $wpdb->prefix . 'culture_game_history';
        $total = (int) $wpdb->get_var( $wpdb->prepare(
            "SELECT COUNT(*) FROM {$table} WHERE user_id = %d", $user_id
        ) );
        $rows = $wpdb->get_results( $wpdb->prepare(
            "SELECT id, game_type, score, max_score, credits_earned, played_date, created_at
             FROM {$table} WHERE user_id = %d ORDER BY id DESC LIMIT %d OFFSET %d",
            $user_id, $per_page, $offset
        ), ARRAY_A ) ?: array();

        return rest_ensure_response( array(
            'entries'  => $rows,
            'total'    => $total,
            'page'     => $page,
            'per_page' => $per_page,
            'pages'    => (int) ceil( $total / max( 1, $per_page ) ),
        ) );
    }

    /**
     * GET /culture/v1/games/crossword-daily
     * Returns today's cached crossword puzzle, or 404 if not generated yet.
     */
    public static function handle_get_crossword_daily( $request ) {
        $date   = $request->get_param( 'date' ) ?: gmdate( 'Y-m-d' );
        $slot   = max( 1, min( 5, (int) ( $request->get_param( 'slot' ) ?: 1 ) ) );
        $key    = 'culture_games_crossword_' . $date . ( $slot > 1 ? '_slot_' . $slot : '' );
        $cached = get_option( $key, null );

        if ( null === $cached || ! is_array( $cached ) ) {
            return new WP_Error( 'not_found', 'No crossword cached for this date/slot.', array( 'status' => 404 ) );
        }

        return rest_ensure_response( array( 'date' => $date, 'slot' => $slot, 'puzzle' => $cached ) );
    }

    /**
     * POST /culture/v1/games/crossword-daily
     * Stores today's crossword puzzle (called by the Next.js API route after
     * Gemini generation). Cleans up the previous day's option automatically.
     */
    public static function handle_set_crossword_daily( $request ) {
        $date   = $request->get_param( 'date' );
        $puzzle = $request->get_param( 'puzzle' );
        $slot   = max( 1, min( 5, (int) ( $request->get_param( 'slot' ) ?: 1 ) ) );

        if ( ! is_array( $puzzle ) || empty( $puzzle ) ) {
            return new WP_Error( 'invalid', 'puzzle must be a non-empty object.', array( 'status' => 400 ) );
        }

        $yesterday = gmdate( 'Y-m-d', strtotime( $date . ' -1 day' ) );
        $key       = 'culture_games_crossword_' . $date . ( $slot > 1 ? '_slot_' . $slot : '' );

        update_option( $key, $puzzle, false );
        delete_option( 'culture_games_crossword_' . $yesterday );
        for ( $s = 2; $s <= 5; $s++ ) {
            delete_option( 'culture_games_crossword_' . $yesterday . '_slot_' . $s );
        }

        return rest_ensure_response( array( 'success' => true, 'date' => $date, 'slot' => $slot ) );
    }

    /**
     * GET /culture/v1/games/crossword-rotation
     * Returns the list of puzzle indices already used in the current rotation cycle.
     */
    public static function handle_get_crossword_rotation( $request ) {
        $used = get_option( 'culture_games_crossword_used', array() );
        return rest_ensure_response( array( 'used' => $used ) );
    }

    /**
     * POST /culture/v1/games/crossword-rotation
     * Marks a puzzle index as used. Resets the rotation when all puzzles have been shown.
     */
    public static function handle_set_crossword_rotation( $request ) {
        $index = (int) $request->get_param( 'index' );
        $total = (int) $request->get_param( 'total' );

        $used = get_option( 'culture_games_crossword_used', array() );
        if ( ! is_array( $used ) ) {
            $used = array();
        }

        if ( ! in_array( $index, $used, true ) ) {
            $used[] = $index;
        }

        // Reset rotation when all puzzles have been shown
        if ( count( $used ) >= $total ) {
            $used = array( $index );
        }

        update_option( 'culture_games_crossword_used', $used, false );

        return rest_ensure_response( array( 'success' => true, 'used_count' => count( $used ), 'total' => $total ) );
    }

    /**
     * GET /culture/v1/quotes/audit-batch?size=N
     * Returns up to N unaudited culture_quote posts for the audit bot.
     * A quote is "unaudited" when it has no _quote_audit_status meta at all.
     */
    public static function handle_get_audit_batch( $request ) {
        $size = min( absint( $request->get_param( 'size' ) ) ?: 20, 50 );

        $posts = get_posts( array(
            'post_type'      => 'culture_quote',
            'post_status'    => array( 'publish', 'pending' ),
            'posts_per_page' => $size,
            'meta_query'     => array(
                array(
                    'key'     => '_quote_audit_status',
                    'compare' => 'NOT EXISTS',
                ),
            ),
        ) );

        $quotes = array_map( function( $p ) {
            $terms  = wp_get_object_terms( $p->ID, 'culture_quote_author' );
            $author = ! empty( $terms ) ? $terms[0]->name : '';
            return array(
                'id'     => $p->ID,
                'text'   => $p->post_content ?: $p->post_title,
                'author' => $author,
                'source' => get_post_meta( $p->ID, '_quote_source', true ) ?: '',
            );
        }, $posts );

        return rest_ensure_response( array(
            'quotes' => $quotes,
            'total'  => count( $quotes ),
        ) );
    }

    /**
     * POST /culture/v1/quotes/audit-update
     * Writes audit verdict meta to a culture_quote post.
     * Optionally moves suspicious/fabricated quotes to draft (quarantine).
     */
    public static function handle_update_audit_status( $request ) {
        $post_id    = (int) $request->get_param( 'post_id' );
        $status     = $request->get_param( 'audit_status' );
        $note       = $request->get_param( 'audit_note' ) ?: '';
        $quarantine = (bool) $request->get_param( 'quarantine' );

        $allowed = array( 'verified', 'suspicious', 'likely-fabricated', 'unverifiable' );
        if ( ! in_array( $status, $allowed, true ) ) {
            return new WP_Error(
                'invalid_status',
                'audit_status must be one of: ' . implode( ', ', $allowed ),
                array( 'status' => 400 )
            );
        }

        $post = get_post( $post_id );
        if ( ! $post || 'culture_quote' !== $post->post_type ) {
            return new WP_Error( 'not_found', 'Quote not found.', array( 'status' => 404 ) );
        }

        update_post_meta( $post_id, '_quote_audit_status', $status );
        update_post_meta( $post_id, '_quote_audit_note',   $note );
        update_post_meta( $post_id, '_quote_audit_date',   gmdate( 'Y-m-d H:i:s' ) );

        $quarantined = false;
        if ( $quarantine && in_array( $status, array( 'likely-fabricated', 'suspicious' ), true ) ) {
            wp_update_post( array( 'ID' => $post_id, 'post_status' => 'draft' ) );
            $quarantined = true;
        }

        return rest_ensure_response( array(
            'success'     => true,
            'post_id'     => $post_id,
            'status'      => $status,
            'quarantined' => $quarantined,
        ) );
    }

    /**
     * POST /culture/v1/user/toggle-interaction
     */
    public static function handle_toggle_interaction( $request ) {
        $user_id = (int) $request->get_param( 'user_id' );
        $post_id = (int) $request->get_param( 'post_id' );
        $type    = $request->get_param( 'type' ); // 'like' or 'bookmark'
        $kind    = $request->get_param( 'kind' ); // 'article' or 'quote'

        // ── Per-kind user list (drives isLiked / isBookmarked state) ─────────
        $meta_key = "_culture_" . $type . "_" . $kind . "_ids";
        $ids = get_user_meta( $user_id, $meta_key, true );
        if ( ! is_array( $ids ) ) { $ids = array(); }

        $index  = array_search( $post_id, $ids );
        $active = false;

        if ( false !== $index ) {
            unset( $ids[ $index ] );
            $ids = array_values( $ids );
        } else {
            $ids[] = $post_id;
            $active = true;
        }

        update_user_meta( $user_id, $meta_key, $ids );

        // ── Sync unified "saved" lists (drives /member/collection page) ──────
        $unified_key  = ( 'like' === $type ) ? '_culture_liked_posts' : '_culture_bookmarked_posts';
        $unified_ids  = get_user_meta( $user_id, $unified_key, true );
        if ( ! is_array( $unified_ids ) ) { $unified_ids = array(); }
        $u_idx = array_search( $post_id, $unified_ids );
        if ( $active && false === $u_idx ) {
            $unified_ids[] = $post_id;
        } elseif ( ! $active && false !== $u_idx ) {
            unset( $unified_ids[ $u_idx ] );
            $unified_ids = array_values( $unified_ids );
        }
        update_user_meta( $user_id, $unified_key, $unified_ids );

        // ── Update post-level like count (drives public like display) ────────
        $post_like_count = 0;
        if ( 'like' === $type ) {
            $post_like_count = max( 0, (int) get_post_meta( $post_id, '_culture_like_count', true ) );
            $post_like_count = $active ? $post_like_count + 1 : max( 0, $post_like_count - 1 );
            update_post_meta( $post_id, '_culture_like_count', $post_like_count );

            // Quotes: keep _quote_likes in sync (read by WPGraphQL as quoteLikes)
            if ( 'quote' === $kind ) {
                update_post_meta( $post_id, '_quote_likes', $post_like_count );
                // Award points to the quote's original submitter
                if ( $active && class_exists( 'Culture_Gamification' ) ) {
                    $submitter_id = (int) get_post_meta( $post_id, '_quote_user_id', true );
                    if ( $submitter_id && $submitter_id !== $user_id ) {
                        Culture_Gamification::award_points( $submitter_id, 'quote_like' );
                    }
                }
            }

            // Award magazine-engagement points for liking an article
            if ( $active && 'article' === $kind && class_exists( 'Culture_Gamification' ) ) {
                Culture_Gamification::award_points( $user_id, 'magazine_like' );
            }
        }

        return rest_ensure_response( array(
            'success' => true,
            'active'  => $active,
            'count'   => $post_like_count, // post-level like count for display
        ) );
    }

    /**
     * GET /culture/v1/user/interactions
     */
    public static function handle_get_interactions( $request ) {
        global $wpdb;
        $user_id = (int) $request->get_param( 'user_id' );

        $keys = array(
            '_culture_like_article_ids',
            '_culture_bookmark_article_ids',
            '_culture_like_quote_ids',
            '_culture_bookmark_quote_ids',
        );
        $placeholders = implode( ',', array_fill( 0, count( $keys ), '%s' ) );
        $rows = $wpdb->get_results( $wpdb->prepare(
            "SELECT meta_key, meta_value FROM {$wpdb->usermeta}
             WHERE user_id = %d AND meta_key IN ({$placeholders})",
            array_merge( array( $user_id ), $keys )
        ), ARRAY_A );

        $map = array_column( $rows, 'meta_value', 'meta_key' );
        $unpack = function( $key ) use ( $map ) {
            $val = isset( $map[ $key ] ) ? maybe_unserialize( $map[ $key ] ) : array();
            return is_array( $val ) ? $val : array();
        };

        $liked_articles      = $unpack( '_culture_like_article_ids' );
        $bookmarked_articles = $unpack( '_culture_bookmark_article_ids' );
        $liked_quotes        = $unpack( '_culture_like_quote_ids' );
        $bookmarked_quotes   = $unpack( '_culture_bookmark_quote_ids' );

        $like_counts    = array();
        $liked_post_ids = array_unique( array_map( 'intval', array_merge( $liked_articles, $liked_quotes ) ) );
        if ( ! empty( $liked_post_ids ) ) {
            $id_placeholders = implode( ',', array_fill( 0, count( $liked_post_ids ), '%d' ) );
            $count_rows = $wpdb->get_results( $wpdb->prepare(
                "SELECT post_id, meta_value FROM {$wpdb->postmeta}
                 WHERE meta_key = '_culture_like_count' AND post_id IN ({$id_placeholders})",
                $liked_post_ids
            ), ARRAY_A );
            foreach ( $count_rows as $row ) {
                $like_counts[ (string) $row['post_id'] ] = (int) $row['meta_value'];
            }
        }

        return rest_ensure_response( array(
            'liked_articles'      => $liked_articles,
            'bookmarked_articles' => $bookmarked_articles,
            'liked_quotes'        => $liked_quotes,
            'bookmarked_quotes'   => $bookmarked_quotes,
            'like_counts'         => $like_counts,
        ) );
    }

    /**
     * GET /culture/v1/user/reaction
     * Reads from the same `_culture_post_reactions` usermeta map written by
     * Culture_Mobile_API::toggle_reaction() (mobile + web share one map) —
     * single source of truth for "did this user react, and with what emoji."
     */
    public static function handle_get_user_reaction( $request ) {
        $user_id = (int) $request->get_param( 'user_id' );
        $post_id = (int) $request->get_param( 'post_id' );

        $reactions_map = get_user_meta( $user_id, '_culture_post_reactions', true );
        $reactions_map = is_array( $reactions_map ) ? $reactions_map : array();

        if ( $post_id > 0 ) {
            return rest_ensure_response( array(
                'userReaction' => isset( $reactions_map[ $post_id ] ) ? $reactions_map[ $post_id ] : null,
            ) );
        }

        return rest_ensure_response( array( 'reactions' => $reactions_map ) );
    }

    public static function handle_get_referrals( $request ) {
        global $wpdb;
        $user_id = (int) $request->get_param( 'user_id' );

        if ( ! get_userdata( $user_id ) ) {
            return new WP_Error( 'not_found', 'User not found.', array( 'status' => 404 ) );
        }

        $code  = class_exists( 'Culture_Referrals' ) ? Culture_Referrals::get_referral_code( $user_id ) : '';
        $count = class_exists( 'Culture_Referrals' ) ? Culture_Referrals::get_referral_count( $user_id ) : 0;

        // Fetch referred users (those who have _culture_referred_by = this user_id).
        $referred_user_ids = $wpdb->get_col( $wpdb->prepare(
            "SELECT user_id FROM {$wpdb->usermeta} WHERE meta_key = '_culture_referred_by' AND meta_value = %d",
            $user_id
        ) );

        $referred = array();
        foreach ( $referred_user_ids as $rid ) {
            $u = get_userdata( (int) $rid );
            if ( ! $u ) continue;
            $referred[] = array(
                'username'    => $u->user_login,
                'displayName' => $u->display_name ?: $u->user_login,
                'joinedAt'    => strtotime( $u->user_registered ),
            );
        }

        // Sort newest first.
        usort( $referred, fn( $a, $b ) => $b['joinedAt'] - $a['joinedAt'] );

        $rep_per_referral    = class_exists( 'Culture_Gamification' ) ? ( Culture_Gamification::POINTS['referral'] ?? 30 ) : 30;
        $credits_per_referral = class_exists( 'Culture_Gamification' ) ? ( Culture_Gamification::CREDIT_BONUSES['referral'] ?? 5 ) : 5;

        return rest_ensure_response( array(
            'referralCode'            => $code,
            'referralUrl'             => 'https://themoveee.com/register?ref=' . $code,
            'referralCount'           => $count,
            'repPerReferral'          => $rep_per_referral,
            'creditsPerReferral'      => $credits_per_referral,
            'referredUsers'           => $referred,
            'connectorThreshold'      => 3,
            'superConnectorThreshold' => 10,
        ) );
    }

    /**
     * GET /culture/v1/comments?post_id=X
     * Returns all approved comments for a post, oldest first.
     */
    public static function handle_get_comments( $request ) {
        $post_id  = $request->get_param( 'post_id' );
        $raw      = get_comments( array(
            'post_id' => $post_id,
            'status'  => 'approve',
            'orderby' => 'comment_date',
            'order'   => 'ASC',
        ) );

        $comments = array_map( function( $c ) {
            return array(
                'id'      => (int) $c->comment_ID,
                'author'  => $c->comment_author,
                'content' => wpautop( $c->comment_content ),
                'date'    => $c->comment_date,
            );
        }, $raw );

        return rest_ensure_response( array( 'comments' => $comments ) );
    }

    /**
     * POST /culture/v1/comments
     * Insert a new end-of-article comment.
     */
    public static function handle_post_comment( $request ) {
        $post_id = (int) $request->get_param( 'post_id' );
        $user_id = (int) $request->get_param( 'user_id' );
        $content = $request->get_param( 'content' );

        $user = get_userdata( $user_id );
        if ( ! $user ) {
            return new WP_Error( 'invalid_user', 'User not found.', array( 'status' => 404 ) );
        }

        $comment_id = wp_insert_comment( array(
            'comment_post_ID'      => $post_id,
            'comment_author'       => $user->display_name,
            'comment_author_email' => $user->user_email,
            'comment_content'      => $content,
            'user_id'              => $user_id,
            'comment_approved'     => 1,
        ) );

        if ( ! $comment_id ) {
            return new WP_Error( 'save_failed', 'Could not save comment.', array( 'status' => 500 ) );
        }

        if ( class_exists( 'Culture_Gamification' ) ) {
            $post_type = get_post_type( $post_id );
            $action    = in_array( $post_type, array( 'culture_newsletter', 'getmelit', 'culture_drop' ), true ) ? 'newsletter_comment' : 'magazine_comment';
            Culture_Gamification::award_points( $user_id, $action );
        }

        return rest_ensure_response( array(
            'success' => true,
            'comment' => array(
                'id'      => $comment_id,
                'author'  => $user->display_name,
                'content' => wpautop( $content ),
                'date'    => current_time( 'mysql' ),
            ),
        ) );
    }

    /**
     * POST /culture/v1/points/award
     * Award points for a specific action (read, share, etc).
     */
    public static function handle_award_points( $request ) {
        $user_id = $request->get_param( 'user_id' );
        $action  = $request->get_param( 'action' );
        $post_id = $request->get_param( 'post_id' );

        if ( ! class_exists( 'Culture_Gamification' ) ) {
            return new WP_Error( 'internal_error', 'Gamification system missing.', array( 'status' => 500 ) );
        }

        // Prevent double-awarding for read/share actions on the same post.
        if ( $post_id && in_array( $action, array( 'magazine_read', 'magazine_share' ), true ) ) {
            $meta_key = "_culture_{$action}_{$post_id}";
            $awarded = get_user_meta( $user_id, $meta_key, true );
            if ( $awarded ) {
                return rest_ensure_response( array( 'success' => false, 'message' => 'Already awarded.' ) );
            }
            update_user_meta( $user_id, $meta_key, true );

            // Increment separate counters for badge tracking.
            if ( 'magazine_read' === $action ) {
                $count = (int) get_user_meta( $user_id, '_magazine_read_count', true ) + 1;
                update_user_meta( $user_id, '_magazine_read_count', $count );
            } elseif ( 'magazine_share' === $action ) {
                $count = (int) get_user_meta( $user_id, '_magazine_share_count', true ) + 1;
                update_user_meta( $user_id, '_magazine_share_count', $count );
            }
        }

        // Increment action-specific counters for badge tracking
        if ( 'community_comment' === $action ) {
            $count = (int) get_user_meta( $user_id, '_community_comment_count', true ) + 1;
            update_user_meta( $user_id, '_community_comment_count', $count );
        }

        $new_total = Culture_Gamification::award_points( $user_id, $action );

        return rest_ensure_response( array(
            'success'                 => true,
            'points'                  => $new_total,
            'reputation'              => $new_total,
            'credits'                 => Culture_Gamification::get_credits( $user_id ),
            'daily_credits_remaining' => Culture_Gamification::get_daily_credits_remaining( $user_id ),
            'awarded'                 => Culture_Gamification::get_point_value( $action ),
            'new_badges'              => array(),
        ) );
    }

    /**
     * POST /culture/v1/content/like
     * Toggles a like on any post for a user. Tracks user→post association so
     * a single user can only like once, and can un-like. Returns new like count
     * and whether the post is now liked.
     */
    public static function handle_toggle_like( $request ) {
        $user_id = (int) $request->get_param( 'user_id' );
        $post_id = (int) $request->get_param( 'post_id' );

        $post = get_post( $post_id );
        if ( ! $post || ! in_array( $post->post_status, array( 'publish' ), true ) ) {
            return new WP_Error( 'not_found', 'Post not found.', array( 'status' => 404 ) );
        }

        $liked_ids     = (array) get_user_meta( $user_id, '_culture_liked_posts', true );
        $already_liked = in_array( $post_id, $liked_ids, true );

        if ( $already_liked ) {
            // Unlike — remove from list, decrement count.
            $liked_ids = array_values( array_diff( $liked_ids, array( $post_id ) ) );
            $new_count = max( 0, (int) get_post_meta( $post_id, '_culture_like_count', true ) - 1 );
            if ( 'culture_quote' === $post->post_type ) {
                update_post_meta( $post_id, '_quote_likes', max( 0, (int) get_post_meta( $post_id, '_quote_likes', true ) - 1 ) );
            }
        } else {
            // Like — add to list, increment count, award points to creator.
            $liked_ids[] = $post_id;
            $new_count   = (int) get_post_meta( $post_id, '_culture_like_count', true ) + 1;
            if ( 'culture_quote' === $post->post_type ) {
                update_post_meta( $post_id, '_quote_likes', (int) get_post_meta( $post_id, '_quote_likes', true ) + 1 );
                $submitter_id = (int) get_post_meta( $post_id, '_quote_user_id', true );
                if ( $submitter_id && $submitter_id !== $user_id && class_exists( 'Culture_Gamification' ) ) {
                    Culture_Gamification::award_points( $submitter_id, 'quote_like' );
                }
            }
        }

        update_user_meta( $user_id, '_culture_liked_posts', $liked_ids );
        update_post_meta( $post_id, '_culture_like_count', $new_count );

        return rest_ensure_response( array(
            'success' => true,
            'liked'   => ! $already_liked,
            'count'   => $new_count,
        ) );
    }

    /**
     * POST /culture/v1/community/react
     * Web mirror of the mobile /mobile/community/react endpoint — same
     * per-user, per-post, per-type (love/fire/clap) toggle/switch semantics,
     * via the shared Culture_Mobile_API::toggle_reaction() implementation.
     * Unlike mobile's JWT auth (current user implicit), web is API-key
     * authenticated so user_id is an explicit param.
     */
    public static function handle_react( $request ) {
        $user_id = (int) $request->get_param( 'user_id' );
        $post_id = (int) $request->get_param( 'post_id' );
        $type    = $request->get_param( 'type' ) ?: 'love';

        $result = Culture_Mobile_API::toggle_reaction( $user_id, $post_id, $type );
        if ( is_wp_error( $result ) ) {
            return $result;
        }

        return rest_ensure_response( $result );
    }

    /**
     * POST /culture/v1/articles/read-complete
     * Awards magazine_read credits once ever per article per user.
     */
    public static function handle_article_read_complete( $request ) {
        $user_id = (int) $request->get_param( 'user_id' );
        $post_id = (int) $request->get_param( 'post_id' );

        if ( ! $user_id || ! $post_id ) {
            return new WP_Error( 'bad_request', 'user_id and post_id are required.', array( 'status' => 400 ) );
        }

        $meta_key = '_culture_article_read_' . $post_id;
        if ( get_user_meta( $user_id, $meta_key, true ) ) {
            return rest_ensure_response( array( 'success' => true, 'credits_earned' => 0, 'already_awarded' => true ) );
        }

        $amount  = max( 1, (int) Culture_Gamification::get_credit_bonus( 'magazine_read' ) );
        $credits = Culture_Gamification::award_credits( $user_id, $amount, 'magazine_read', $post_id );
        Culture_Gamification::award_reputation( $user_id, Culture_Gamification::get_point_value( 'magazine_read' ), 'magazine_read', $post_id );
        update_user_meta( $user_id, $meta_key, '1' );

        return rest_ensure_response( array( 'success' => true, 'credits_earned' => max( 0, intval( $credits ) ) ) );
    }

    /**
     * POST /culture/v1/content/bookmark
     * Toggles a bookmark (private save) on any post for a user.
     */
    public static function handle_toggle_bookmark( $request ) {
        $user_id      = (int) $request->get_param( 'user_id' );
        $post_id      = (int) $request->get_param( 'post_id' );
        $content_type = sanitize_key( $request->get_param( 'content_type' ) ?: '' );

        $post = get_post( $post_id );
        if ( ! $post || ! in_array( $post->post_status, array( 'publish' ), true ) ) {
            return new WP_Error( 'not_found', 'Post not found.', array( 'status' => 404 ) );
        }

        // Route to the correct meta key based on content_type or post_type.
        if ( $content_type === 'quote' || $post->post_type === 'culture_quote' ) {
            $meta_key = '_culture_bookmark_quote_ids';
        } elseif ( $content_type === 'article' || $post->post_type === 'post' ) {
            $meta_key = '_culture_bookmark_article_ids';
        } else {
            $meta_key = '_culture_bookmarked_posts';
        }

        $bookmarked_ids     = (array) get_user_meta( $user_id, $meta_key, true );
        $already_bookmarked = in_array( $post_id, $bookmarked_ids, true );

        if ( $already_bookmarked ) {
            $bookmarked_ids = array_values( array_diff( $bookmarked_ids, array( $post_id ) ) );
        } else {
            $bookmarked_ids[] = $post_id;
        }

        update_user_meta( $user_id, $meta_key, $bookmarked_ids );

        return rest_ensure_response( array(
            'success'    => true,
            'bookmarked' => ! $already_bookmarked,
        ) );
    }

    /**
     * GET /culture/v1/user/saved?user_id=X
     * Returns the user's liked and bookmarked posts with basic data,
     * plus the raw ID lists so the frontend can check state instantly.
     */
    public static function handle_get_user_saved( $request ) {
        $user_id = (int) $request->get_param( 'user_id' );

        if ( ! get_userdata( $user_id ) ) {
            return new WP_Error( 'not_found', 'User not found.', array( 'status' => 404 ) );
        }

        /**
         * Merge all like/bookmark sources so that interactions recorded before
         * and after plugin updates all appear in the collection.
         *
         * Sources:
         *   _culture_liked_posts          – unified list written by current toggle-interaction
         *   _culture_like_quote_ids       – per-kind list from original PR toggle code
         *   _culture_like_article_ids     – per-kind list from original PR toggle code
         */
        $safe_intval_array = function( $meta_key ) use ( $user_id ) {
            $raw = get_user_meta( $user_id, $meta_key, true );
            if ( ! is_array( $raw ) ) { return array(); }
            return array_values( array_filter( array_map( 'intval', $raw ) ) );
        };

        $liked_ids = array_unique( array_merge(
            $safe_intval_array( '_culture_liked_posts' ),
            $safe_intval_array( '_culture_like_quote_ids' ),
            $safe_intval_array( '_culture_like_article_ids' )
        ) );

        $bookmarked_ids = array_unique( array_merge(
            $safe_intval_array( '_culture_bookmarked_posts' ),
            $safe_intval_array( '_culture_bookmark_quote_ids' ),
            $safe_intval_array( '_culture_bookmark_article_ids' )
        ) );

        $liked      = array();
        $bookmarked = array();

        if ( ! empty( $liked_ids ) ) {
            $posts = get_posts( array(
                'post__in'       => $liked_ids,
                'post_type'      => array( 'post', 'culture_quote' ),
                'post_status'    => 'publish',
                'posts_per_page' => 100,
                'orderby'        => 'post__in',
            ) );
            foreach ( $posts as $p ) {
                $liked[] = self::saved_post_summary( $p );
            }
        }

        if ( ! empty( $bookmarked_ids ) ) {
            $posts = get_posts( array(
                'post__in'       => $bookmarked_ids,
                'post_type'      => array( 'post', 'culture_quote', 'culture_post' ),
                'post_status'    => 'publish',
                'posts_per_page' => 100,
                'orderby'        => 'post__in',
            ) );
            foreach ( $posts as $p ) {
                $bookmarked[] = self::saved_post_summary( $p );
            }
        }

        return rest_ensure_response( array(
            'liked'          => $liked,
            'bookmarked'     => $bookmarked,
            'liked_ids'      => $liked_ids,
            'bookmarked_ids' => $bookmarked_ids,
        ) );
    }

    /**
     * POST /culture/v1/visuals/track-download
     * Increments the daily download count for a user.
     */
    public static function handle_track_visual_download( $request ) {
        $user_id = (int) $request->get_param( 'user_id' );
        if ( ! get_userdata( $user_id ) ) {
            return new WP_Error( 'not_found', 'User not found.', array( 'status' => 404 ) );
        }

        $today = current_time( 'Y-m-d' );
        $meta  = get_user_meta( $user_id, '_culture_visual_downloads', true );
        $tier  = get_user_meta( $user_id, '_culture_membership_tier', true ) ?: 'citizen';

        // Unlimited Tiers: patron, leader, admin (WordPress role check as fallback)
        $is_unlimited = in_array( $tier, array( 'patron', 'leader' ) ) || user_can( $user_id, 'manage_options' );

        if ( ! is_array( $meta ) || ! isset( $meta['date'] ) || $meta['date'] !== $today ) {
            $meta = array( 'date' => $today, 'count' => 1 );
        } else {
            // Check limit for non-unlimited users
            if ( ! $is_unlimited && $meta['count'] >= 5 ) {
                return new WP_Error( 'limit_reached', 'Daily download limit reached.', array( 'status' => 403 ) );
            }
            $meta['count']++;
        }

        update_user_meta( $user_id, '_culture_visual_downloads', $meta );

        return rest_ensure_response( array(
            'success' => true,
            'count'   => $meta['count'],
            'date'    => $meta['date'],
        ) );
    }

    /**
     * Helper to get the current daily download count.
     */
    private static function get_daily_visual_downloads( $user_id ) {
        $today = current_time( 'Y-m-d' );
        $meta  = get_user_meta( $user_id, '_culture_visual_downloads', true );

        if ( is_array( $meta ) && isset( $meta['date'] ) && $meta['date'] === $today ) {
            return (int) $meta['count'];
        }

        return 0;
    }

    /** Build a minimal summary for a saved post. */
    private static function saved_post_summary( $post ) {
        $is_quote   = ( 'culture_quote' === $post->post_type );
        $is_community = ( 'culture_post' === $post->post_type );

        $slug = $post->post_name;
        if ( $is_quote ) {
            // Matches get_quote_feed_items()'s href shape — the permalink
            // page parses the leading numeric ID off this segment.
            $url = '/quotes/' . $post->ID . '-' . $slug;
        } elseif ( $is_community ) {
            $url = '/community/' . $slug;
        } else {
            $url = '/magazine/' . $slug;
        }

        // For quotes, use post_content as the title (full quote text, no truncation).
        // get_the_title() decodes HTML entities (e.g. &hellip; → …) unlike $post->post_title.
        $display_title = $is_quote
            ? wp_strip_all_tags( $post->post_content )
            : get_the_title( $post );

        $base = array(
            'id'      => $post->ID,
            'type'    => $is_quote ? 'quote' : ( $is_community ? 'community' : 'article' ),
            'title'   => $display_title,
            'slug'    => $slug,
            'url'     => $url,
            'excerpt' => wp_trim_words( wp_strip_all_tags( $post->post_content ), 20 ),
            'date'    => get_the_date( 'Y-m-d', $post ),
            'likes'   => (int) get_post_meta( $post->ID, '_culture_like_count', true ),
        );

        if ( $is_quote ) {
            $base['quoteAuthor'] = get_post_meta( $post->ID, '_quote_author', true ) ?: '';
            $base['quoteSource'] = get_post_meta( $post->ID, '_quote_source', true ) ?: '';
        }

        if ( $is_community ) {
            $base['templateType']   = get_post_meta( $post->ID, '_template_type', true ) ?: 'post';
            $base['communityTag']   = get_post_meta( $post->ID, '_culture_section_tag', true ) ?: '';
            $base['authorName']     = get_the_author_meta( 'display_name', $post->post_author );
            $base['authorUsername'] = get_the_author_meta( 'user_login', $post->post_author );
            $thumb = get_the_post_thumbnail_url( $post->ID, 'medium' );
            if ( $thumb ) { $base['featuredImage'] = $thumb; }
        }

        if ( ! $is_quote && ! $is_community ) {
            // Article
            $thumb = get_the_post_thumbnail_url( $post->ID, 'medium' );
            if ( $thumb ) { $base['featuredImage'] = $thumb; }
            $categories = get_the_category( $post->ID );
            if ( ! empty( $categories ) ) { $base['category'] = $categories[0]->name; }
            $author_id = $post->post_author;
            $base['author'] = array( 'name' => get_the_author_meta( 'display_name', $author_id ) );
            $base['readingTime'] = (int) get_post_meta( $post->ID, '_reading_time', true ) ?: null;
            $base['publishedAt'] = get_the_date( 'c', $post );
        }

        return $base;
    }

    /**
     * POST /culture/v1/user/upgrade-init
     * Initiates a checkout session for an existing user to upgrade to a
     * paid tier — 'patron' (Moveee Pro) or 'lit' (Moveee Lit, see CLAUDE.md's
     * "Three-tier membership" section).
     */
    public static function handle_upgrade_init( $request ) {
        $user_id = (int) $request->get_param( 'user_id' );
        $user    = get_userdata( $user_id );

        if ( ! $user ) {
            return new WP_Error( 'not_found', 'User not found.', array( 'status' => 404 ) );
        }

        $plan_key    = $request->get_param( 'plan_key' ) ?: 'monthly_ngn';
        $tier        = $request->get_param( 'tier' ) ?: 'patron';
        $tier        = in_array( $tier, array( 'patron', 'lit' ), true ) ? $tier : 'patron';
        // Where to land after checkout (e.g. '/lit-welcome') instead of the
        // generic site root — always joined onto the trusted frontend URL
        // (Culture_Paystack::build_return_url()), never used as a host of
        // its own, so an arbitrary value here can't become an open redirect.
        $return_path = sanitize_text_field( (string) ( $request->get_param( 'return_path' ) ?: '' ) );

        $checkout_url = '';

        // NGN → Flutterwave subscriptions.
        if ( strpos( $plan_key, '_ngn' ) !== false && class_exists( 'Culture_Flutterwave_Subscriptions' ) ) {
            $checkout_url = Culture_Flutterwave_Subscriptions::init_checkout_session( $user_id, $plan_key, $tier, $return_path );
        }
        // If Stripe.
        elseif ( strpos( $plan_key, '_usd' ) !== false && class_exists( 'Culture_Stripe' ) ) {
            $checkout_url = Culture_Stripe::get_checkout_url( $user_id, $plan_key, $tier, $return_path );
        }

        if ( is_wp_error( $checkout_url ) ) {
            return $checkout_url;
        }

        if ( $checkout_url ) {
            return rest_ensure_response( array(
                'success'      => true,
                'checkout_url' => $checkout_url,
            ) );
        }

        return new WP_Error( 'missing_gateway', 'Payment gateway not configured for this plan.', array( 'status' => 500 ) );
    }

    /**
     * GET /culture/v1/user/profile?user_id=X
     * Returns the full live user profile (points, badges, etc.).
     */
    public static function handle_get_user_profile( $request ) {
        $user_id = $request->get_param( 'user_id' );

        if ( ! $user_id ) {
            return new WP_Error( 'missing_user_id', 'user_id is required.', array( 'status' => 400 ) );
        }

        $user = get_userdata( $user_id );
        if ( ! $user ) {
            return new WP_Error( 'not_found', 'User not found.', array( 'status' => 404 ) );
        }

        return rest_ensure_response( self::user_profile( $user ) );
    }

    /**
     * POST /culture/v1/events/submit
     *
     * POST /culture/v1/events/update-image
     * Update _culture_event_image_url on an existing event.
     * Body: { id: int, image_url: string }
     */
    public static function handle_update_event_image( WP_REST_Request $request ) {
        $post_id   = (int) $request->get_param( 'id' );
        $image_url = esc_url_raw( $request->get_param( 'image_url' ) );

        if ( ! $post_id || ! $image_url ) {
            return new WP_Error( 'bad_request', 'id and image_url are required.', array( 'status' => 400 ) );
        }
        $post = get_post( $post_id );
        if ( ! $post || $post->post_type !== 'culture_event' ) {
            return new WP_Error( 'not_found', 'Event not found.', array( 'status' => 404 ) );
        }
        update_post_meta( $post_id, '_culture_event_image_url', $image_url );
        return rest_ensure_response( array( 'success' => true, 'id' => $post_id ) );
    }

    /**
     * GET /culture/v1/events/missing-images
     * Return published culture_event posts that have no featured image and no _culture_event_image_url.
     * Query params: per_page (default 50), page (default 1).
     */
    public static function handle_list_events_missing_images( WP_REST_Request $request ) {
        $per_page = min( (int) ( $request->get_param( 'per_page' ) ?: 50 ), 100 );
        $page     = max( (int) ( $request->get_param( 'page' ) ?: 1 ), 1 );

        $args = array(
            'post_type'      => 'culture_event',
            'post_status'    => 'publish',
            'posts_per_page' => $per_page,
            'paged'          => $page,
            'meta_query'     => array(
                'relation' => 'OR',
                array( 'key' => '_culture_event_image_url', 'value' => '', 'compare' => '=' ),
                array( 'key' => '_culture_event_image_url', 'compare' => 'NOT EXISTS' ),
            ),
        );
        $query = new WP_Query( $args );
        $events = array();
        foreach ( $query->posts as $post ) {
            // Skip if it has a featured image.
            if ( has_post_thumbnail( $post->ID ) ) continue;
            $events[] = array(
                'id'          => $post->ID,
                'title'       => $post->post_title,
                'slug'        => $post->post_name,
                'attribution' => get_post_meta( $post->ID, '_culture_attribution', true ),
                'ticketing_url' => get_post_meta( $post->ID, '_culture_ticketing_url', true ),
            );
        }
        return rest_ensure_response( array(
            'events'    => $events,
            'total'     => $query->found_posts,
            'pages'     => $query->max_num_pages,
        ) );
    }

    /**
     * GET /culture/v1/events/external-images
     * Return published culture_event posts whose _culture_event_image_url is an
     * external URL (i.e. does not start with this site's upload directory or home_url).
     * Query params: per_page (default 50), page (default 1).
     */
    public static function handle_list_events_external_images( WP_REST_Request $request ) {
        $per_page   = min( (int) ( $request->get_param( 'per_page' ) ?: 50 ), 200 );
        $page       = max( (int) ( $request->get_param( 'page' )     ?: 1  ), 1  );
        $upload_dir = wp_upload_dir();
        $base_url   = trailingslashit( $upload_dir['baseurl'] );
        $home       = trailingslashit( home_url() );

        $args = array(
            'post_type'      => 'culture_event',
            'post_status'    => 'publish',
            'posts_per_page' => $per_page,
            'paged'          => $page,
            'meta_query'     => array(
                array(
                    'key'     => '_culture_event_image_url',
                    'value'   => '',
                    'compare' => '!=',
                ),
            ),
        );
        $query  = new WP_Query( $args );
        $events = array();
        foreach ( $query->posts as $post ) {
            $img = get_post_meta( $post->ID, '_culture_event_image_url', true );
            // Skip if already hosted on this WP install.
            if ( strpos( $img, $base_url ) === 0 || strpos( $img, $home ) === 0 ) {
                continue;
            }
            $events[] = array(
                'id'        => $post->ID,
                'title'     => $post->post_title,
                'image_url' => $img,
            );
        }
        return rest_ensure_response( array(
            'events' => $events,
            'total'  => count( $events ),
        ) );
    }

    /**
     * Creates a culture_event post. Called exclusively by the AI events seeder.
     * Deduplicates by a hash of normalised title + event_date + location.
     */
    public static function handle_create_event( WP_REST_Request $request ) {
        $title         = sanitize_text_field( $request->get_param( 'title' ) );
        $excerpt       = sanitize_text_field( $request->get_param( 'excerpt' ) );
        $content       = wp_kses_post( $request->get_param( 'content' ) );
        $event_date    = sanitize_text_field( $request->get_param( 'event_date' ) );
        $end_date      = sanitize_text_field( $request->get_param( 'end_date' ) );
        $location      = sanitize_text_field( $request->get_param( 'location' ) );
        $city          = sanitize_text_field( $request->get_param( 'city' ) );
        $admission     = sanitize_text_field( $request->get_param( 'admission' ) );
        $ticketing_url  = esc_url_raw( $request->get_param( 'ticketing_url' ) );
        $tagline        = sanitize_text_field( $request->get_param( 'tagline' ) );
        $opening_hours  = sanitize_text_field( $request->get_param( 'opening_hours' ) );
        $attribution    = esc_url_raw( $request->get_param( 'attribution' ) );
        $image_url     = esc_url_raw( $request->get_param( 'image_url' ) );
        $interests           = (array) $request->get_param( 'interests' );
        $auto_publish        = (bool) $request->get_param( 'auto_publish' );
        $ai_generated_raw    = $request->get_param( 'ai_generated' );
        $ai_generated        = ( $ai_generated_raw === null ) ? true : (bool) $ai_generated_raw;
        $featured_image_id   = absint( $request->get_param( 'featured_image_id' ) );
        $submitter_name          = sanitize_text_field( $request->get_param( 'submitter_name' ) );
        $submitter_email         = sanitize_email( $request->get_param( 'submitter_email' ) );
        $organiser_directory_id  = absint( $request->get_param( 'organiser_directory_id' ) );

        if ( empty( $title ) || empty( $event_date ) ) {
            return new WP_Error( 'missing_fields', 'title and event_date are required.', array( 'status' => 400 ) );
        }

        // Deduplication: hash of normalised title + date + location.
        // Normalise title: lowercase, strip year numbers, strip noise words
        // (tickets, saturday, sunday, etc.), collapse whitespace.
        $norm_title = strtolower( trim( $title ) );
        $norm_title = preg_replace( '/\b(tickets?|saturday|sunday|monday|tuesday|wednesday|thursday|friday|buy now|register|free)\b/', '', $norm_title );
        $norm_title = preg_replace( '/\b20\d{2}\b/', '', $norm_title ); // strip years
        $norm_title = preg_replace( '/[^a-z0-9\s]/', '', $norm_title ); // strip punctuation
        $norm_title = preg_replace( '/\s+/', ' ', trim( $norm_title ) );
        $dedup_hash = md5( $norm_title . '|' . $event_date . '|' . strtolower( trim( $location ) ) );
        $existing = get_posts( array(
            'post_type'      => 'culture_event',
            'post_status'    => array( 'publish', 'pending' ),
            'posts_per_page' => 1,
            'meta_query'     => array(
                array(
                    'key'     => '_culture_event_dedup_hash',
                    'value'   => $dedup_hash,
                    'compare' => '=',
                ),
            ),
        ) );

        if ( ! empty( $existing ) ) {
            return new WP_Error( 'duplicate_event', 'This event already exists.', array( 'status' => 409 ) );
        }

        $post_status = $auto_publish ? 'publish' : 'pending';

        $post_id = wp_insert_post( array(
            'post_title'   => $title,
            'post_excerpt' => $excerpt,
            'post_content' => $content,
            'post_status'  => $post_status,
            'post_type'    => 'culture_event',
            'post_author'  => 0,
        ), true );

        if ( is_wp_error( $post_id ) ) {
            return new WP_Error( 'insert_failed', $post_id->get_error_message(), array( 'status' => 500 ) );
        }

        // Event-specific meta.
        update_post_meta( $post_id, '_culture_event_date',      $event_date );
        update_post_meta( $post_id, '_culture_event_end_date',  $end_date );
        update_post_meta( $post_id, '_culture_location',        $location );
        update_post_meta( $post_id, '_culture_event_city',      $city );
        update_post_meta( $post_id, '_culture_admission',       $admission );
        update_post_meta( $post_id, '_culture_ticketing_url',   $ticketing_url );
        update_post_meta( $post_id, '_culture_tagline',         $tagline );
        update_post_meta( $post_id, '_culture_opening_hours',   $opening_hours );
        update_post_meta( $post_id, '_culture_attribution',     $attribution );
        update_post_meta( $post_id, '_culture_event_image_url', $image_url );
        update_post_meta( $post_id, '_culture_is_featured',     '0' );
        update_post_meta( $post_id, '_culture_ai_generated',    $ai_generated ? '1' : '0' );
        update_post_meta( $post_id, '_culture_event_dedup_hash', $dedup_hash );
        if ( $organiser_directory_id > 0 ) {
            update_post_meta( $post_id, '_culture_event_organiser_id', $organiser_directory_id );
        }

        // Set featured image if a valid WP media attachment ID was provided.
        if ( $featured_image_id > 0 && get_post( $featured_image_id ) ) {
            set_post_thumbnail( $post_id, $featured_image_id );
        }

        if ( ! empty( $submitter_name ) ) {
            update_post_meta( $post_id, '_culture_submitter_name',  $submitter_name );
        }
        if ( ! empty( $submitter_email ) ) {
            update_post_meta( $post_id, '_culture_submitter_email', $submitter_email );
        }

        // Assign interest terms (only existing slugs to avoid orphan terms).
        if ( ! empty( $interests ) && taxonomy_exists( 'culture_interest' ) ) {
            $valid = array();
            foreach ( array_map( 'sanitize_key', $interests ) as $slug ) {
                if ( term_exists( $slug, 'culture_interest' ) ) {
                    $valid[] = $slug;
                }
            }
            if ( ! empty( $valid ) ) {
                wp_set_object_terms( $post_id, $valid, 'culture_interest' );
            }
        }

        $post = get_post( $post_id );
        return rest_ensure_response( array(
            'success' => true,
            'post_id' => $post_id,
            'slug'    => $post->post_name ?: sanitize_title( $title ),
        ) );
    }

    /**
     * POST /culture/v1/admin/migrate-community-posts
     * One-time migration: converts all posts in the "community" category
     * to the culture_post CPT. Safe to run multiple times (idempotent).
     */
    public static function handle_migrate_community_posts() {
        global $wpdb;

        $category = get_term_by( 'slug', 'community', 'category' );
        if ( ! $category ) {
            return rest_ensure_response( array( 'migrated' => 0, 'message' => 'No community category found.' ) );
        }

        $post_ids = get_posts( array(
            'post_type'      => 'post',
            'post_status'    => 'publish',
            'category'       => $category->term_id,
            'posts_per_page' => -1,
            'fields'         => 'ids',
        ) );

        $migrated = 0;
        foreach ( $post_ids as $id ) {
            $wpdb->update(
                $wpdb->posts,
                array( 'post_type' => 'culture_post' ),
                array( 'ID' => $id ),
                array( '%s' ),
                array( '%d' )
            );
            clean_post_cache( $id );
            $migrated++;
        }

        return rest_ensure_response( array(
            'migrated' => $migrated,
            'message'  => "Migrated {$migrated} posts to culture_post.",
        ) );
    }

    /**
     * POST /culture/v1/user/directory
     * Saves Connect directory settings. Reads all fields directly from the
     * request without relying on has_param() so JSON bodies always persist.
     */
    public static function handle_save_directory_profile( $request ) {
        $user_id = (int) $request->get_param( 'user_id' );
        if ( ! $user_id || ! get_userdata( $user_id ) ) {
            return new WP_Error( 'not_found', 'User not found.', array( 'status' => 404 ) );
        }

        $opt_in         = $request->get_param( 'directory_opt_in' );
        $was_opted_in   = get_user_meta( $user_id, '_culture_directory_opt_in', true ) === '1';
        $new_opt_in_val = ( $opt_in === '1' || $opt_in === true ) ? '1' : '0';
        update_user_meta( $user_id, '_culture_directory_opt_in',     $new_opt_in_val );
        update_user_meta( $user_id, '_culture_directory_bio',         sanitize_textarea_field( (string) $request->get_param( 'directory_bio' ) ) );
        update_user_meta( $user_id, '_culture_directory_disciplines', sanitize_text_field( (string) $request->get_param( 'directory_disciplines' ) ) );
        update_user_meta( $user_id, '_culture_directory_instagram',   sanitize_text_field( (string) $request->get_param( 'directory_instagram' ) ) );
        update_user_meta( $user_id, '_culture_directory_twitter',     sanitize_text_field( (string) $request->get_param( 'directory_twitter' ) ) );
        update_user_meta( $user_id, '_culture_directory_linkedin',    sanitize_text_field( (string) $request->get_param( 'directory_linkedin' ) ) );
        update_user_meta( $user_id, '_culture_directory_website',     sanitize_text_field( (string) $request->get_param( 'directory_website' ) ) );

        // Award reputation the first time a user opts into the directory.
        if ( '1' === $new_opt_in_val && ! $was_opted_in && class_exists( 'Culture_Gamification' ) ) {
            Culture_Gamification::award_points( $user_id, 'directory_opt_in' );
        }

        return rest_ensure_response( array( 'ok' => true ) );
    }

    /**
     * GET /culture/v1/user/directory
     * Returns the Connect directory settings for the given user_id.
     */
    public static function handle_get_directory_profile( $request ) {
        global $wpdb;
        $user_id = (int) $request->get_param( 'user_id' );

        $exists = $wpdb->get_var( $wpdb->prepare(
            "SELECT ID FROM {$wpdb->users} WHERE ID = %d LIMIT 1",
            $user_id
        ) );
        if ( ! $exists ) {
            return new WP_Error( 'not_found', 'User not found.', array( 'status' => 404 ) );
        }

        $keys = array(
            '_culture_directory_opt_in',
            '_culture_directory_bio',
            '_culture_directory_disciplines',
            '_culture_directory_instagram',
            '_culture_directory_twitter',
            '_culture_directory_linkedin',
            '_culture_directory_website',
        );
        $placeholders = implode( ',', array_fill( 0, count( $keys ), '%s' ) );
        $rows = $wpdb->get_results( $wpdb->prepare(
            "SELECT meta_key, meta_value FROM {$wpdb->usermeta}
             WHERE user_id = %d AND meta_key IN ({$placeholders})",
            array_merge( array( $user_id ), $keys )
        ), ARRAY_A );

        $map = array_column( $rows, 'meta_value', 'meta_key' );
        $get  = fn( $k, $default = '' ) => $map[ $k ] ?? $default;

        return rest_ensure_response( array(
            'directory_opt_in'      => $get( '_culture_directory_opt_in' ) === '1',
            'directory_bio'         => $get( '_culture_directory_bio' ),
            'directory_disciplines' => $get( '_culture_directory_disciplines' ),
            'directory_instagram'   => $get( '_culture_directory_instagram' ),
            'directory_twitter'     => $get( '_culture_directory_twitter' ),
            'directory_linkedin'    => $get( '_culture_directory_linkedin' ),
            'directory_website'     => $get( '_culture_directory_website' ),
        ) );
    }

    /**
     * GET /culture/v1/members
     * Returns members opted into the Connect directory.
     * Supports ?search=, ?discipline=, ?location=, ?region=, ?sort=, ?per_page=
     */
    public static function handle_get_members_directory( $request ) {
        $only_directory = $request->get_param( 'directory' ) === '1';
        $search         = $request->get_param( 'search' );
        $discipline     = $request->get_param( 'discipline' );
        $location       = $request->get_param( 'location' );
        $region         = $request->get_param( 'region' );
        $sort           = $request->get_param( 'sort' );
        $per_page       = min( (int) $request->get_param( 'per_page' ), 200 );

        $meta_query = array( 'relation' => 'AND' );

        if ( $only_directory ) {
            $meta_query[] = array(
                'key'     => '_culture_directory_opt_in',
                'value'   => '1',
                'compare' => '=',
            );
            // Unverified accounts (bot/spam signups — see handle_register(),
            // which sets this to '0' on every signup) were previously opted
            // into the directory by default at creation and shown with
            // their raw, often randomly-generated username as display_name,
            // since nothing here checked verification status.
            //
            // Excludes only an explicit '0', not "= '1'" — accounts that
            // predate this field entirely (registered before email
            // verification existed) have no _culture_email_verified row at
            // all, and requiring an exact '1' match would wrongly hide
            // every one of those legitimate, longstanding members too.
            $meta_query[] = array(
                'relation' => 'OR',
                array( 'key' => '_culture_email_verified', 'value' => '0', 'compare' => '!=' ),
                array( 'key' => '_culture_email_verified', 'compare' => 'NOT EXISTS' ),
            );
        }

        if ( $discipline ) {
            $meta_query[] = array(
                'key'     => '_culture_directory_disciplines',
                'value'   => $discipline,
                'compare' => 'LIKE',
            );
        }

        if ( $location ) {
            $meta_query[] = array(
                'relation' => 'OR',
                array(
                    'key'     => '_culture_city',
                    'value'   => $location,
                    'compare' => 'LIKE',
                ),
                array(
                    'key'     => '_culture_country_of_residence',
                    'value'   => $location,
                    'compare' => 'LIKE',
                ),
            );
        }

        // region — a structured alternative to 'location' for the People Near
        // Me page's Location chips. _culture_country_of_residence stores the
        // full country name as picked from LocationSelect.tsx's COUNTRIES list
        // (e.g. "Nigeria", "United Kingdom"), so nigeria/ghana/uk/usa match
        // their exact country string; pan-african is deliberately broader
        // (matches any country name containing "Africa", plus a couple of
        // named non-"Africa" countries) since there's no single literal value
        // for it — mirrors the same broad-fallback approach
        // Culture_Directory::REGION_CITY_KEYWORDS uses for Discover, applied
        // here to a different field (_culture_country_of_residence, not
        // _entry_city).
        if ( $region ) {
            $region_countries = array();
            switch ( $region ) {
                case 'nigeria': $region_countries = array( 'Nigeria' ); break;
                case 'ghana':   $region_countries = array( 'Ghana' ); break;
                case 'uk':      $region_countries = array( 'United Kingdom' ); break;
                case 'usa':     $region_countries = array( 'United States' ); break;
                case 'pan-african': $region_countries = array( 'Senegal', 'Kenya' ); break;
            }
            if ( $region_countries ) {
                $region_or = array( 'relation' => 'OR' );
                foreach ( $region_countries as $country ) {
                    $region_or[] = array(
                        'key'     => '_culture_country_of_residence',
                        'value'   => $country,
                        'compare' => '=',
                    );
                }
                if ( 'pan-african' === $region ) {
                    $region_or[] = array(
                        'key'     => '_culture_country_of_residence',
                        'value'   => 'Africa',
                        'compare' => 'LIKE',
                    );
                }
                $meta_query[] = $region_or;
            }
        }

        $offset = max( 0, (int) $request->get_param( 'offset' ) );

        $args = array(
            'number'     => $per_page,
            'offset'     => $offset,
            'meta_query' => $meta_query,
            'orderby'    => 'recent' === $sort ? 'registered' : 'display_name',
            'order'      => 'recent' === $sort ? 'DESC' : 'ASC',
        );

        if ( $search ) {
            $args['search']         = '*' . $search . '*';
            $args['search_columns'] = array( 'display_name', 'user_nicename' );
        }

        $users = get_users( $args );

        if ( empty( $users ) ) {
            return rest_ensure_response( array() );
        }

        // Fetch all required meta keys in one query instead of 9 get_user_meta()
        // calls per user (up to 1,400 individual meta lookups at per_page=200).
        global $wpdb;
        $user_ids  = array_map( fn( $u ) => (int) $u->ID, $users );
        $id_list   = implode( ',', $user_ids );
        $meta_keys = array(
            '_culture_membership_tier',
            '_culture_occupation',
            '_culture_city',
            '_culture_country_of_residence',
            '_culture_directory_bio',
            '_culture_directory_disciplines',
            '_culture_directory_instagram',
            '_culture_directory_twitter',
            '_culture_directory_linkedin',
            '_culture_directory_website',
            '_culture_avatar_url',
        );
        $keys_in   = implode( ',', array_map( fn( $k ) => "'" . esc_sql( $k ) . "'", $meta_keys ) );
        $rows      = $wpdb->get_results(
            "SELECT user_id, meta_key, meta_value FROM {$wpdb->usermeta}
             WHERE user_id IN ({$id_list}) AND meta_key IN ({$keys_in})",
            ARRAY_A
        );

        $meta_map = array();
        foreach ( $rows as $row ) {
            $meta_map[ $row['user_id'] ][ $row['meta_key'] ] = $row['meta_value'];
        }

        $members = array_map( function( $user ) use ( $meta_map ) {
            $m = $meta_map[ $user->ID ] ?? array();
            return array(
                'id'                     => $user->ID,
                'username'               => $user->user_nicename,
                'display_name'           => $user->display_name,
                'avatar_url'             => $m['_culture_avatar_url']             ?? '',
                'occupation'             => $m['_culture_occupation']             ?? '',
                'city'                   => $m['_culture_city']                   ?? '',
                'country_of_residence'   => $m['_culture_country_of_residence']   ?? '',
                'tier'                   => $m['_culture_membership_tier']        ?? 'citizen',
                'directory_bio'          => $m['_culture_directory_bio']          ?? '',
                'directory_disciplines'  => $m['_culture_directory_disciplines']  ?? '',
                'directory_instagram'    => $m['_culture_directory_instagram']    ?? '',
                'directory_twitter'      => $m['_culture_directory_twitter']      ?? '',
                'directory_linkedin'     => $m['_culture_directory_linkedin']     ?? '',
                'directory_website'      => $m['_culture_directory_website']      ?? '',
                'registered_at'          => $user->user_registered,
            );
        }, $users );

        return rest_ensure_response( $members );
    }

    /**
     * Assign a vendor as the owner of a newly created shipping zone.
     */
    /**
     * Set a vendor's store avatar or banner by WP attachment ID. Merges into
     * the existing _wcfm_vendor_data array (WCFM's own consolidated vendor
     * settings) under the 'gravatar' / 'banner' keys, matching exactly what
     * moveee_vendor_profile_by_id() in moveee-graphql-bridge.php reads and
     * what WCFM's own native dashboard writes when a vendor uploads there.
     */
    public static function handle_set_vendor_profile_image( $request ) {
        $vendor_id     = $request->get_param( 'vendor_id' );
        $type          = $request->get_param( 'type' );
        $attachment_id = $request->get_param( 'attachment_id' );

        $user = get_userdata( $vendor_id );
        if ( ! $user ) {
            return new WP_Error( 'not_found', 'Vendor not found.', array( 'status' => 404 ) );
        }
        if ( ! wp_attachment_is_image( $attachment_id ) ) {
            return new WP_Error( 'invalid_attachment', 'Attachment is not an image.', array( 'status' => 422 ) );
        }

        $key = $type === 'avatar' ? 'gravatar' : 'banner';
        $d   = get_user_meta( $vendor_id, '_wcfm_vendor_data', true );
        if ( ! is_array( $d ) ) $d = array();
        $d[ $key ] = $attachment_id;
        update_user_meta( $vendor_id, '_wcfm_vendor_data', $d );

        $size = $type === 'avatar' ? 'medium' : 'full';
        return rest_ensure_response( array(
            'success' => true,
            'url'     => wp_get_attachment_image_url( $attachment_id, $size ),
        ) );
    }

    public static function handle_assign_shipping_zone_owner( $request ) {
        $zone_id   = $request->get_param( 'zone_id' );
        $vendor_id = $request->get_param( 'vendor_id' );

        $assigned = Culture_Vendor_Shipping_Zones::assign_owner( $zone_id, $vendor_id );
        if ( ! $assigned && Culture_Vendor_Shipping_Zones::get_owner( $zone_id ) !== 0 ) {
            return new WP_Error( 'already_owned', 'This zone already has an owner.', array( 'status' => 409 ) );
        }

        return rest_ensure_response( array( 'success' => $assigned ) );
    }

    /**
     * Look up shipping-zone ownership — by zone_id (owner) or vendor_id (owned zones).
     */
    public static function handle_get_shipping_zone_owner( $request ) {
        $zone_id   = $request->get_param( 'zone_id' );
        $vendor_id = $request->get_param( 'vendor_id' );

        if ( $zone_id ) {
            return rest_ensure_response( array( 'vendor_id' => Culture_Vendor_Shipping_Zones::get_owner( (int) $zone_id ) ) );
        }
        if ( $vendor_id ) {
            return rest_ensure_response( array( 'zone_ids' => Culture_Vendor_Shipping_Zones::get_owned_zone_ids( (int) $vendor_id ) ) );
        }
        return new WP_Error( 'missing_param', 'Provide zone_id or vendor_id.', array( 'status' => 400 ) );
    }

    /**
     * Promote an existing WP user to WCFM vendor.
     * Creates the WCFM vendor data, assigns the wcfm_vendor role, and sets up
     * the basic store profile so the vendor can immediately use the dashboard.
     */
    public static function handle_vendor_apply( $request ) {
        $user_id    = $request->get_param( 'user_id' );
        $store_name = $request->get_param( 'store_name' );
        $store_url  = $request->get_param( 'store_url' );
        $bio        = $request->get_param( 'bio' );
        $country    = $request->get_param( 'country' );
        $category   = $request->get_param( 'category' );
        $instagram  = $request->get_param( 'instagram' );
        $website    = $request->get_param( 'website' );

        $user = get_userdata( $user_id );
        if ( ! $user ) {
            return new WP_Error( 'not_found', 'User not found.', array( 'status' => 404 ) );
        }

        // Idempotency — already a vendor.
        $vendor_roles = array( 'wcfm_vendor', 'seller', 'vendor' );
        if ( array_intersect( $vendor_roles, (array) $user->roles ) ) {
            return rest_ensure_response( self::user_profile( $user ) );
        }

        // Validate/slugify the store URL.
        $slug = sanitize_title( $store_url ?: $store_name );
        if ( empty( $slug ) ) {
            return new WP_Error( 'invalid_slug', 'Store URL is invalid.', array( 'status' => 422 ) );
        }

        // Check slug uniqueness (WC stores use user_nicename / shop slug).
        $existing = get_users( array(
            'meta_key'    => '_store_url',
            'meta_value'  => $slug,
            'number'      => 1,
            'fields'      => 'ID',
        ) );
        if ( ! empty( $existing ) && (int) $existing[0] !== $user_id ) {
            return new WP_Error( 'slug_taken', 'That store URL is already taken.', array( 'status' => 409 ) );
        }

        // Assign vendor role.
        $user->add_role( 'wcfm_vendor' );

        // Core WCFM vendor data. 'shop_description' (not 'seller_info') is the
        // key moveee_vendor_profile_by_id() (moveee-graphql-bridge.php) and the
        // vendor dashboard's Store Profile page both read as the bio — using
        // any other key here means a bio set at application time would never
        // show up anywhere until the vendor re-saved it elsewhere.
        $wcfm_vendor_data = array(
            'store_name'       => $store_name,
            'store_url'        => $slug,
            'shop_description' => $bio,
        );
        update_user_meta( $user_id, '_wcfm_vendor_data', $wcfm_vendor_data );
        update_user_meta( $user_id, '_store_url',    $slug );
        update_user_meta( $user_id, '_store_name',   $store_name );

        // WCFM profile extras. '_wcfmmp_profile_bio' is the standalone-meta
        // fallback moveee_vendor_profile_by_id() checks when the array key
        // above is empty — same reasoning as above, not '_seller_info'.
        if ( $bio )       update_user_meta( $user_id, '_wcfmmp_profile_bio', $bio );
        if ( $country )   update_user_meta( $user_id, '_store_country',   $country );
        if ( $category )  update_user_meta( $user_id, '_store_category',  $category );
        if ( $instagram ) update_user_meta( $user_id, '_wcfm_instagram',  $instagram );
        if ( $website )   update_user_meta( $user_id, '_store_url_ext',   $website );

        // Update nicename to match the store slug so /makers/{slug} works.
        wp_update_user( array( 'ID' => $user_id, 'user_nicename' => $slug ) );

        // Fire WCFM's own hook if available so any WCFM automations run.
        do_action( 'wcfmmp_vendor_registration_complete', $user_id );

        return rest_ensure_response( self::user_profile( get_userdata( $user_id ) ) );
    }

    /**
     * POST /culture/v1/community/poll-vote
     * Vote on a poll post. Validates expiry and prevents double-voting.
     */
    public static function handle_poll_vote( WP_REST_Request $request ) {
        $post_id      = (int) $request->get_param( 'post_id' );
        $option_index = (int) $request->get_param( 'option_index' );
        $user_id      = (int) $request->get_param( 'user_id' );

        if ( ! $user_id ) {
            return new WP_Error( 'missing_user', 'user_id is required.', array( 'status' => 400 ) );
        }
        if ( ! get_user_by( 'id', $user_id ) ) {
            return new WP_Error( 'invalid_user', 'User not found.', array( 'status' => 400 ) );
        }

        $post = get_post( $post_id );
        if ( ! $post || $post->post_type !== 'culture_post' ) {
            return new WP_Error( 'invalid_post', 'Post not found.', array( 'status' => 404 ) );
        }

        $template = get_post_meta( $post_id, '_template_type', true );
        if ( $template !== 'poll' ) {
            return new WP_Error( 'not_poll', 'This post is not a poll.', array( 'status' => 400 ) );
        }

        // Check expiry.
        $expires = get_post_meta( $post_id, '_poll_expires_at', true );
        if ( $expires && strtotime( $expires ) < time() ) {
            return new WP_Error( 'poll_expired', 'This poll has ended.', array( 'status' => 400 ) );
        }

        // Check double-voting.
        $voters = json_decode( get_post_meta( $post_id, '_poll_voters', true ) ?: '[]', true ) ?: array();
        if ( in_array( $user_id, $voters, true ) ) {
            return new WP_Error( 'already_voted', 'You have already voted.', array( 'status' => 409 ) );
        }

        // Get options and validate index.
        $options = json_decode( get_post_meta( $post_id, '_poll_options', true ) ?: '[]', true ) ?: array();
        if ( $option_index < 0 || $option_index >= count( $options ) ) {
            return new WP_Error( 'invalid_option', 'Invalid option.', array( 'status' => 400 ) );
        }

        // Increment vote.
        $options[ $option_index ]['votes'] = ( $options[ $option_index ]['votes'] ?? 0 ) + 1;
        update_post_meta( $post_id, '_poll_options', wp_json_encode( $options ) );

        // Record voter.
        $voters[] = $user_id;
        update_post_meta( $post_id, '_poll_voters', wp_json_encode( $voters ) );

        // Award reputation + credits for participation.
        if ( class_exists( 'Culture_Gamification' ) ) {
            Culture_Gamification::award_reputation( $user_id, Culture_Gamification::get_point_value( 'poll_vote' ), 'poll_vote', $post_id );
            Culture_Gamification::award_credits( $user_id, Culture_Gamification::get_credit_bonus( 'poll_vote' ), 'poll_vote', $post_id );
        }

        return rest_ensure_response( array(
            'success' => true,
            'options' => $options,
            'voted'   => $option_index,
        ) );
    }

    // -------------------------------------------------------------------------
    // Phase 5 — Public Profiles
    // -------------------------------------------------------------------------

    /**
     * GET /culture/v1/member/{username}
     * Returns public-safe profile data for the given username. No auth required.
     */
    public static function handle_get_public_profile( $request ) {
        $username = sanitize_user( $request->get_param( 'username' ) );

        $user = get_user_by( 'login', $username );
        if ( ! $user ) {
            return new WP_Error( 'not_found', 'Member not found.', array( 'status' => 404 ) );
        }

        $uid        = $user->ID;
        $reputation = class_exists( 'Culture_Gamification' ) ? Culture_Gamification::get_reputation( $uid ) : 0;

        return rest_ensure_response( array(
            'id'              => $uid,
            'username'        => $user->user_login,
            'display_name'    => $user->display_name,
            'avatar_url'      => get_user_meta( $uid, '_culture_avatar_url', true ) ?: '',
            'cover_photo_url' => get_user_meta( $uid, '_culture_cover_photo_url', true ) ?: '',
            'bio'             => get_user_meta( $uid, '_culture_directory_bio', true ) ?: '',
            'city'            => get_user_meta( $uid, '_culture_city', true ) ?: '',
            'country'         => get_user_meta( $uid, '_culture_country_of_residence', true ) ?: '',
            'occupation'      => get_user_meta( $uid, '_culture_occupation', true ) ?: '',
            'tier'            => get_user_meta( $uid, '_culture_membership_tier', true ) ?: 'citizen',
            'reputation'      => $reputation,
            'reputation_tier' => class_exists( 'Culture_Gamification' ) ? Culture_Gamification::get_reputation_tier( $reputation ) : 'member',
            'badges'          => class_exists( 'Culture_Gamification' ) ? Culture_Gamification::get_badges( $uid ) : array(),
            'interests'       => json_decode( get_user_meta( $uid, '_culture_interests', true ) ?: '[]', true ) ?: array(),
            'joined'          => date( 'Y-m-d', strtotime( $user->user_registered ) ),
            'post_count'      => (int) count_user_posts( $uid, 'culture_post' ),
            'followers_count' => class_exists( 'Culture_Follows' ) ? Culture_Follows::followers_count( $uid ) : 0,
            'following_count' => class_exists( 'Culture_Follows' ) ? Culture_Follows::following_count( $uid ) : 0,
        ) );
    }

    /**
     * GET /culture/v1/community/posts
     * Returns published culture_post entries, optionally filtered by author_id
     * and/or template_type. No auth required.
     */
    public static function handle_get_community_posts( $request ) {
        $author_id     = (int) $request->get_param( 'author_id' );
        $template_type = sanitize_text_field( $request->get_param( 'template_type' ) );
        $per_page      = max( 1, min( 100, (int) $request->get_param( 'per_page' ) ) );
        $page          = max( 1, (int) $request->get_param( 'page' ) );

        $query_args = array(
            'post_type'      => 'culture_post',
            'post_status'    => 'publish',
            'posts_per_page' => $per_page,
            'paged'          => $page,
            'meta_query'     => array( 'relation' => 'AND' ),
        );

        if ( $author_id > 0 ) {
            $query_args['meta_query'][] = array(
                'key'     => 'community_author_id',
                'value'   => $author_id,
                'compare' => '=',
                'type'    => 'NUMERIC',
            );
        }

        if ( '' !== $template_type ) {
            $query_args['meta_query'][] = array(
                'key'     => '_template_type',
                'value'   => $template_type,
                'compare' => '=',
            );
        }

        $posts  = get_posts( $query_args );

        // Prime the WP object cache for all post metas in one SQL query so the
        // get_post_meta() calls below are served from memory, not individual DB queries.
        if ( ! empty( $posts ) ) {
            update_meta_cache( 'post', wp_list_pluck( $posts, 'ID' ) );
        }

        $result = array_map( array( __CLASS__, 'format_community_post_row' ), $posts );

        return rest_ensure_response( $result );
    }

    // Shared per-post field shape (snake_case, web's community-post listing shape)
    // — used by handle_get_community_posts() and the portfolio pinned-posts resolver
    // so both surfaces render identically.
    /**
     * Convert post_content HTML to plain text, preserving paragraph breaks as \n\n.
     * wp_strip_all_tags() alone collapses </p><p> without a separator.
     */
    private static function post_content_to_plain( string $html ): string {
        $text = preg_replace( '#</p>\s*<p[^>]*>#i', "\n\n", $html );
        $text = preg_replace( '#<br\s*/?>(\s*<br\s*/?>)+#i', "\n\n", $text );
        $text = preg_replace( '#<br\s*/?>#i', "\n", $text );
        return trim( wp_strip_all_tags( $text ) );
    }

    /**
     * Resolve the current display name for a post's author.
     * Always reads from the live user record so renames are reflected immediately.
     * get_userdata() is cached in WP's object cache, so repeated calls within
     * a single feed request for the same user_id are free.
     */
    public static function resolve_author_name( int $pid ): string {
        $author_id = (int) get_post_meta( $pid, 'community_author_id', true );
        if ( $author_id ) {
            $user = get_userdata( $author_id );
            if ( $user ) {
                return $user->display_name ?: $user->user_login;
            }
        }
        // Fallback for posts missing community_author_id (very old posts)
        return get_post_meta( $pid, 'community_author_name', true ) ?: '';
    }

    /**
     * Resolve the current avatar for a post's author.
     * Always reads from the live user meta so avatar changes are reflected immediately.
     */
    public static function resolve_author_avatar( int $pid ): string {
        $author_id = (int) get_post_meta( $pid, 'community_author_id', true );
        if ( $author_id ) {
            $avatar = get_user_meta( $author_id, '_culture_avatar_url', true ) ?: '';
            if ( $avatar ) {
                return $avatar;
            }
        }
        // Fallback for posts missing community_author_id (very old posts)
        return get_post_meta( $pid, 'community_author_avatar', true ) ?: '';
    }

    private static function format_community_post_row( WP_Post $post ): array {
        $pid = $post->ID;
        return array(
            'id'             => $pid,
            'slug'           => $post->post_name,
            'date'           => get_the_date( 'c', $pid ),
            'text'           => self::post_content_to_plain( $post->post_content ),
            'image_url'      => get_post_meta( $pid, 'community_image_url', true ) ?: '',
            'tag'            => get_post_meta( $pid, 'community_tag', true ) ?: '',
            'region'         => get_post_meta( $pid, 'community_region', true ) ?: '',
            'author_name'    => self::resolve_author_name( $pid ),
            'author_username' => get_post_meta( $pid, 'community_author_username', true ) ?: '',
            'author_tier'    => get_post_meta( $pid, 'community_author_tier', true ) ?: '',
            'author_avatar'  => self::resolve_author_avatar( $pid ),
            'template_type'  => get_post_meta( $pid, '_template_type', true ) ?: 'post',
            'star_rating'    => (int) get_post_meta( $pid, '_star_rating', true ),
            'location_name'  => get_post_meta( $pid, '_location_name', true ) ?: '',
            'gallery_images' => json_decode( get_post_meta( $pid, '_gallery_images', true ) ?: '[]', true ),
            'video_url'      => get_post_meta( $pid, '_video_url', true ) ?: '',
            'food_dish_name' => get_post_meta( $pid, '_food_dish_name', true ) ?: '',
            'showcase_collaborator_username' => get_post_meta( $pid, '_showcase_collaborator_username', true ) ?: '',
            'reactions'      => array(
                'love' => (int) get_post_meta( $pid, 'reaction_love', true ),
                'fire' => (int) get_post_meta( $pid, 'reaction_fire', true ),
                'clap' => (int) get_post_meta( $pid, 'reaction_clap', true ),
            ),
            'comment_count'  => (int) $post->comment_count,
            // Music review fields
            'music_title'               => get_post_meta( $pid, '_music_title', true ) ?: '',
            'music_artist'              => get_post_meta( $pid, '_music_artist', true ) ?: '',
            'music_overall_rating'      => (int) get_post_meta( $pid, '_music_overall_rating', true ),
            'music_rating_production'   => (int) get_post_meta( $pid, '_music_rating_production', true ),
            'music_rating_lyrics'       => (int) get_post_meta( $pid, '_music_rating_lyrics', true ),
            'music_rating_replay'       => (int) get_post_meta( $pid, '_music_rating_replay', true ),
            'music_rating_vibe'         => (int) get_post_meta( $pid, '_music_rating_vibe', true ),
            'music_fav_lyric'           => get_post_meta( $pid, '_music_fav_lyric', true ) ?: '',
            'music_recommend'           => get_post_meta( $pid, '_music_recommend', true ) === '1',
            'music_genres'              => json_decode( get_post_meta( $pid, '_music_genres', true ) ?: '[]', true ),
            'music_preview_url'         => get_post_meta( $pid, '_music_preview_url', true ) ?: '',
            'music_cover_url'           => get_post_meta( $pid, '_music_cover_url', true ) ?: '',
            // Book review fields
            'book_title'                => get_post_meta( $pid, '_book_title', true ) ?: '',
            'book_author'               => get_post_meta( $pid, '_book_author', true ) ?: '',
            'book_status'               => get_post_meta( $pid, '_book_status', true ) ?: '',
            'book_overall_rating'       => (int) get_post_meta( $pid, '_book_overall_rating', true ),
            'book_rating_writing'       => (int) get_post_meta( $pid, '_book_rating_writing', true ),
            'book_rating_story'         => (int) get_post_meta( $pid, '_book_rating_story', true ),
            'book_rating_characters'    => (int) get_post_meta( $pid, '_book_rating_characters', true ),
            'book_rating_pacing'        => (int) get_post_meta( $pid, '_book_rating_pacing', true ),
            'book_fav_quote'            => get_post_meta( $pid, '_book_fav_quote', true ) ?: '',
            'book_recommend'            => get_post_meta( $pid, '_book_recommend', true ) === '1',
            'book_genres'               => json_decode( get_post_meta( $pid, '_book_genres', true ) ?: '[]', true ),
            'book_cover_url'            => get_post_meta( $pid, '_book_cover_url', true ) ?: '',
            // Film review fields
            'film_title'                => get_post_meta( $pid, '_film_title', true ) ?: '',
            'film_director'             => get_post_meta( $pid, '_film_director', true ) ?: '',
            'film_overall_rating'       => (int) get_post_meta( $pid, '_film_overall_rating', true ),
            'film_rating_story'         => (int) get_post_meta( $pid, '_film_rating_story', true ),
            'film_rating_acting'        => (int) get_post_meta( $pid, '_film_rating_acting', true ),
            'film_rating_visuals'       => (int) get_post_meta( $pid, '_film_rating_visuals', true ),
            'film_rating_pacing'        => (int) get_post_meta( $pid, '_film_rating_pacing', true ),
            'film_fav_line'             => get_post_meta( $pid, '_film_fav_line', true ) ?: '',
            'film_recommend'            => get_post_meta( $pid, '_film_recommend', true ) === '1',
            'film_genres'               => json_decode( get_post_meta( $pid, '_film_genres', true ) ?: '[]', true ),
            'film_cover_url'            => get_post_meta( $pid, '_film_cover_url', true ) ?: '',
        );
    }

    // Resolves pinned community-post IDs into the same row shape as
    // handle_get_community_posts(), preserving the caller's pin order.
    private static function resolve_pinned_posts_web( array $post_ids ): array {
        if ( empty( $post_ids ) ) {
            return array();
        }

        $query = new WP_Query( array(
            'post_type'      => 'culture_post',
            'post_status'    => 'publish',
            'post__in'       => $post_ids,
            'orderby'        => 'post__in',
            'posts_per_page' => count( $post_ids ),
        ) );

        return array_map( array( __CLASS__, 'format_community_post_row' ), $query->posts );
    }

    /**
     * GET /culture/v1/user/portfolio
     * Returns pinned posts and portfolio items for the given user. Requires Bearer auth.
     */
    public static function handle_get_portfolio( $request ) {
        global $wpdb;
        $user_id = (int) $request->get_param( 'user_id' );

        $exists = $wpdb->get_var( $wpdb->prepare(
            "SELECT ID FROM {$wpdb->users} WHERE ID = %d LIMIT 1",
            $user_id
        ) );
        if ( ! $exists ) {
            return new WP_Error( 'not_found', 'User not found.', array( 'status' => 404 ) );
        }

        $rows = $wpdb->get_results( $wpdb->prepare(
            "SELECT meta_key, meta_value FROM {$wpdb->usermeta}
             WHERE user_id = %d AND meta_key IN ('_portfolio_pinned_posts','_portfolio_items')",
            $user_id
        ), ARRAY_A );

        $map          = array_column( $rows, 'meta_value', 'meta_key' );
        $pinned_posts = json_decode( $map['_portfolio_pinned_posts'] ?? '[]', true ) ?: array();
        $items        = json_decode( $map['_portfolio_items']        ?? '[]', true ) ?: array();

        return rest_ensure_response( array(
            'pinned_posts'      => $pinned_posts,
            'items'             => $items,
            'pinned_posts_data' => self::resolve_pinned_posts_web( array_map( 'absint', $pinned_posts ) ),
        ) );
    }

    /**
     * POST /culture/v1/user/portfolio
     * Saves pinned posts and portfolio items for the given user. Requires Bearer auth.
     */
    public static function handle_save_portfolio( $request ) {
        $user_id      = (int) $request->get_param( 'user_id' );
        $pinned_posts = $request->get_param( 'pinned_posts' );
        $items        = $request->get_param( 'items' );

        $user = get_userdata( $user_id );
        if ( ! $user ) {
            return new WP_Error( 'not_found', 'User not found.', array( 'status' => 404 ) );
        }

        // Only touch the keys that were actually sent — a caller that only
        // wants to update pinned posts (or only items) must not blow away
        // the other half of the portfolio by omitting it.
        if ( is_array( $pinned_posts ) ) {
            $pinned_posts = array_values( array_map( 'absint', $pinned_posts ) );
            update_user_meta( $user_id, '_portfolio_pinned_posts', wp_json_encode( $pinned_posts ) );
        }
        if ( is_array( $items ) ) {
            update_user_meta( $user_id, '_portfolio_items', wp_json_encode( $items ) );
        }

        return rest_ensure_response( array( 'success' => true ) );
    }

    /**
     * POST /culture/v1/user/portfolio/pin
     * Toggles a single community post in/out of a user's pinned set without
     * touching their manually-added items. Mirrors the mobile
     * Culture_Mobile_API::handle_pin_portfolio_post() but takes an explicit
     * user_id (API-key auth — caller is the trusted Next.js proxy).
     */
    public static function handle_pin_portfolio_post( $request ) {
        $user_id = (int) $request->get_param( 'user_id' );
        $post_id = absint( $request->get_param( 'post_id' ) );
        $pinned  = (bool) $request->get_param( 'pinned' );

        if ( ! $post_id || get_post_type( $post_id ) !== 'culture_post' ) {
            return new WP_Error( 'invalid_post', 'Invalid post.', array( 'status' => 400 ) );
        }
        if ( (int) get_post_field( 'post_author', $post_id ) !== $user_id ) {
            return new WP_Error( 'forbidden', 'You can only pin your own posts.', array( 'status' => 403 ) );
        }

        $raw = get_user_meta( $user_id, '_portfolio_pinned_posts', true );
        $ids = json_decode( $raw ?: '[]', true ) ?: array();
        $ids = array_values( array_unique( array_map( 'absint', $ids ) ) );

        if ( $pinned && ! in_array( $post_id, $ids, true ) ) {
            $ids[] = $post_id;
        } elseif ( ! $pinned ) {
            $ids = array_values( array_diff( $ids, array( $post_id ) ) );
        }

        update_user_meta( $user_id, '_portfolio_pinned_posts', wp_json_encode( $ids ) );

        return rest_ensure_response( array( 'success' => true, 'pinned_posts' => $ids ) );
    }

    // ── Phase 6: Partner Perks & Wallet Handlers ─────────────────────────────

    public static function handle_list_perks( $request ) {
        return rest_ensure_response( Culture_Perks::get_perks() );
    }

    public static function handle_redeem_perk( $request ) {
        $user_id       = (int) $request->get_param( 'user_id' );
        $perk_id       = (int) $request->get_param( 'perk_id' );
        $step_up_token = (string) $request->get_param( 'step_up_token' );
        $phone         = (string) $request->get_param( 'phone' );
        if ( ! $step_up_token || ! Culture_WebAuthn::validate_step_up( $user_id, $step_up_token ) ) {
            return new WP_Error( 'step_up_required', 'Passkey step-up verification required.', array( 'status' => 403 ) );
        }
        $result = Culture_Perks::redeem_perk( $user_id, $perk_id, $phone );
        if ( is_wp_error( $result ) ) return $result;
        return rest_ensure_response( $result );
    }

    public static function handle_verify_qr( $request ) {
        return rest_ensure_response( Culture_Perks::verify_qr( $request->get_param( 'token' ) ) );
    }

    public static function handle_wallet_balance( $request ) {
        $user_id = (int) $request->get_param( 'user_id' );
        if ( ! get_userdata( $user_id ) ) {
            return new WP_Error( 'not_found', 'User not found.', array( 'status' => 404 ) );
        }

        $credits         = Culture_Gamification::get_credits( $user_id );
        $daily_remaining = Culture_Gamification::get_daily_credits_remaining( $user_id );
        $earned_today    = Culture_Gamification::DAILY_CREDIT_CAP - $daily_remaining;
        $credits_per_gbp = max( 1, (int) get_option( 'culture_credits_per_gbp', Culture_Perks::DEFAULT_CREDITS_PER_GBP ) );
        $credit_value_gbp_pence = (int) round( ( $credits / $credits_per_gbp ) * 100 );

        return rest_ensure_response( array(
            'credits'               => $credits,
            'earned_today'          => $earned_today,
            'daily_remaining'       => $daily_remaining,
            'credit_value_gbp'      => $credit_value_gbp_pence,
            'credits_per_gbp'       => $credits_per_gbp,
        ) );
    }

    public static function handle_wallet_history( $request ) {
        global $wpdb;
        $user_id  = (int) $request->get_param( 'user_id' );
        $per_page = min( (int) $request->get_param( 'per_page' ), 100 );
        $page     = max( (int) $request->get_param( 'page' ), 1 );
        $offset   = ( $page - 1 ) * $per_page;

        if ( ! get_userdata( $user_id ) ) {
            return new WP_Error( 'not_found', 'User not found.', array( 'status' => 404 ) );
        }

        $table = $wpdb->prefix . 'culture_credit_ledger';
        $total = (int) $wpdb->get_var( $wpdb->prepare(
            "SELECT COUNT(*) FROM {$table} WHERE user_id = %d AND type = 'credit'", $user_id
        ) );
        $rows = $wpdb->get_results( $wpdb->prepare(
            "SELECT id, amount, source, source_id, created_at FROM {$table}
             WHERE user_id = %d AND type = 'credit' ORDER BY id DESC LIMIT %d OFFSET %d",
            $user_id, $per_page, $offset
        ), ARRAY_A ) ?: array();

        return rest_ensure_response( array(
            'entries'  => $rows,
            'total'    => $total,
            'page'     => $page,
            'per_page' => $per_page,
            'pages'    => (int) ceil( $total / max( 1, $per_page ) ),
        ) );
    }

    public static function handle_wallet_cashout( $request ) {
        $user_id       = (int) $request->get_param( 'user_id' );
        $step_up_token = (string) $request->get_param( 'step_up_token' );
        if ( ! $step_up_token || ! Culture_WebAuthn::validate_step_up( $user_id, $step_up_token ) ) {
            return new WP_Error( 'step_up_required', 'Passkey step-up verification required.', array( 'status' => 403 ) );
        }
        $result = Culture_Perks::request_cashout(
            $user_id,
            (int) $request->get_param( 'credits' ),
            $request->get_param( 'method' ),
            $request->get_param( 'account_name' ),
            $request->get_param( 'account_ref' ),
            $request->get_param( 'currency' ) ?: 'GBP'
        );
        if ( is_wp_error( $result ) ) return $result;
        return rest_ensure_response( $result );
    }

    public static function handle_cashout_queue( $request ) {
        return rest_ensure_response( Culture_Perks::get_cashout_queue(
            sanitize_key( $request->get_param( 'status' ) ?: 'pending' )
        ) );
    }

    public static function handle_cashout_approve( $request ) {
        $result = Culture_Perks::approve_cashout(
            (int) $request->get_param( 'redemption_id' ),
            (int) $request->get_param( 'admin_id' )
        );
        if ( is_wp_error( $result ) ) return $result;
        return rest_ensure_response( $result );
    }

    public static function handle_cashout_reject( $request ) {
        $result = Culture_Perks::reject_cashout(
            (int) $request->get_param( 'redemption_id' ),
            (int) $request->get_param( 'admin_id' ),
            $request->get_param( 'reason' ) ?: ''
        );
        if ( is_wp_error( $result ) ) return $result;
        return rest_ensure_response( $result );
    }

    public static function handle_admin_list_perks( $request ) {
        $status = sanitize_key( $request->get_param( 'status' ) ?: '' );
        $args   = array( 'limit' => 200, 'offset' => 0 );
        if ( $status ) {
            $args['status'] = $status;
        } else {
            $args['status'] = '';
        }
        return rest_ensure_response( Culture_Perks::get_perks( $args ) );
    }

    public static function handle_admin_create_perk( $request ) {
        global $wpdb;
        $data = self::_sanitize_perk_data( $request );
        if ( is_wp_error( $data ) ) return $data;
        $table = $wpdb->prefix . 'culture_partner_perks';
        if ( ! $wpdb->insert( $table, $data['values'], $data['formats'] ) ) {
            return new WP_Error( 'db_error', 'Could not create perk.', array( 'status' => 500 ) );
        }
        return rest_ensure_response( array( 'success' => true, 'perk' => Culture_Perks::get_perk( (int) $wpdb->insert_id ) ) );
    }

    public static function handle_admin_update_perk( $request ) {
        global $wpdb;
        $perk_id = (int) $request->get_param( 'id' );
        if ( ! Culture_Perks::get_perk( $perk_id ) ) {
            return new WP_Error( 'not_found', 'Perk not found.', array( 'status' => 404 ) );
        }
        $data = self::_sanitize_perk_data( $request );
        if ( is_wp_error( $data ) ) return $data;
        $wpdb->update( $wpdb->prefix . 'culture_partner_perks', $data['values'], array( 'id' => $perk_id ), $data['formats'], array( '%d' ) );
        return rest_ensure_response( array( 'success' => true, 'perk' => Culture_Perks::get_perk( $perk_id ) ) );
    }

    public static function handle_admin_delete_perk( $request ) {
        global $wpdb;
        $perk_id = (int) $request->get_param( 'id' );
        if ( ! Culture_Perks::get_perk( $perk_id ) ) {
            return new WP_Error( 'not_found', 'Perk not found.', array( 'status' => 404 ) );
        }
        $wpdb->update( $wpdb->prefix . 'culture_partner_perks', array( 'status' => 'paused' ), array( 'id' => $perk_id ), array( '%s' ), array( '%d' ) );
        return rest_ensure_response( array( 'success' => true, 'perk_id' => $perk_id, 'status' => 'paused' ) );
    }

    public static function handle_user_redemptions( $request ) {
        $user_id = (int) $request->get_param( 'user_id' );
        $status  = $request->get_param( 'status' ) ?: null;
        $rows    = Culture_Perks::get_user_redemptions( $user_id, $status );
        $perks_table = $GLOBALS['wpdb']->prefix . 'culture_partner_perks';
        foreach ( $rows as &$row ) {
            if ( (int) $row['perk_id'] > 0 ) {
                $perk = Culture_Perks::get_perk( (int) $row['perk_id'] );
                $row['perk_title'] = $perk ? $perk['title'] : '';
                $row['perk_description'] = $perk ? $perk['description'] : '';
                $partner_id = $perk ? (int) $perk['partner_directory_id'] : 0;
                $row['perk_partner_name'] = $partner_id ? get_the_title( $partner_id ) : '';
            }
        }
        return rest_ensure_response( $rows );
    }

    private static function _sanitize_perk_data( $request ) {
        $title = sanitize_text_field( $request->get_param( 'title' ) ?: '' );
        if ( empty( $title ) ) {
            return new WP_Error( 'missing_title', 'Perk title is required.', array( 'status' => 400 ) );
        }
        $allowed = array( 'active', 'paused', 'expired' );
        $status  = sanitize_key( $request->get_param( 'status' ) ?: 'active' );
        if ( ! in_array( $status, $allowed, true ) ) $status = 'active';
        $perk_type = in_array( $request->get_param( 'perk_type' ), array( 'partner', 'airtime', 'data_bundle' ), true )
            ? $request->get_param( 'perk_type' ) : 'partner';
        return array(
            'values'  => array(
                'title'                => $title,
                'description'          => sanitize_textarea_field( $request->get_param( 'description' ) ?: '' ),
                'credit_cost'          => max( 0, (int) $request->get_param( 'credit_cost' ) ),
                'min_spend'            => max( 0, (int) $request->get_param( 'min_spend' ) ),
                'min_spend_currency'   => strtoupper( substr( sanitize_text_field( $request->get_param( 'min_spend_currency' ) ?: 'GBP' ), 0, 3 ) ),
                'expiry_days'          => max( 1, (int) $request->get_param( 'expiry_days' ) ),
                'max_per_user'         => max( 0, (int) $request->get_param( 'max_per_user' ) ),
                'max_total'            => max( 0, (int) $request->get_param( 'max_total' ) ),
                'status'               => $status,
                'partner_directory_id' => max( 0, (int) $request->get_param( 'partner_directory_id' ) ),
                'partner_vendor_id'    => max( 0, (int) $request->get_param( 'partner_vendor_id' ) ),
                'min_rep_tier'         => in_array( $request->get_param( 'min_rep_tier' ), array( 'member', 'culture-contributor', 'taste-maker', 'culture-authority', 'culture-icon' ), true )
                                          ? $request->get_param( 'min_rep_tier' ) : 'member',
                'perk_type'            => $perk_type,
                'airtime_country'      => strtoupper( substr( sanitize_text_field( $request->get_param( 'airtime_country' ) ?: 'NG' ), 0, 3 ) ),
                'airtime_amount_local' => max( 0, (int) $request->get_param( 'airtime_amount_local' ) ),
                'data_bundle_code'     => sanitize_text_field( $request->get_param( 'data_bundle_code' ) ?: '' ),
            ),
            'formats' => array( '%s', '%s', '%d', '%d', '%s', '%d', '%d', '%d', '%s', '%d', '%d', '%s', '%s', '%s', '%d', '%s' ),
        );
    }

    /* ——————————————————————————————————————
     *  Phase 9 — Event QR Check-in handlers
     * —————————————————————————————————————— */

    /**
     * POST /culture/v1/events/{id}/generate-checkin-token
     * Generates (or regenerates) a check-in token for the event and returns the QR URL.
     */
    public static function handle_generate_checkin_token( $request ) {
        $event_id = (int) $request['id'];
        $post     = get_post( $event_id );
        if ( ! $post || 'culture_event' !== $post->post_type ) {
            return new WP_Error( 'not_found', 'Event not found.', array( 'status' => 404 ) );
        }
        $token = bin2hex( random_bytes( 16 ) );
        update_post_meta( $event_id, '_event_checkin_token_hash', hash( 'sha256', $token ) );
        $url = "https://themoveee.com/events/checkin?id={$event_id}&t={$token}";
        return rest_ensure_response( array(
            'token'       => $token,
            'checkin_url' => $url,
            'event_id'    => $event_id,
        ) );
    }

    /**
     * POST /culture/v1/events/self-checkin
     * Verifies the token and records a check-in for the given user.
     */
    public static function handle_self_checkin( $request ) {
        global $wpdb;

        $event_id = (int) $request->get_param( 'event_id' );
        $token    = sanitize_text_field( $request->get_param( 'token' ) );
        $user_id  = (int) $request->get_param( 'user_id' );

        if ( ! $event_id || ! $token || ! $user_id ) {
            return new WP_Error( 'missing_params', 'event_id, token, and user_id are required.', array( 'status' => 400 ) );
        }

        $post = get_post( $event_id );
        if ( ! $post || 'culture_event' !== $post->post_type ) {
            return new WP_Error( 'not_found', 'Event not found.', array( 'status' => 404 ) );
        }

        // Verify token.
        $stored_hash = get_post_meta( $event_id, '_event_checkin_token_hash', true );
        if ( empty( $stored_hash ) || hash( 'sha256', $token ) !== $stored_hash ) {
            return new WP_Error( 'invalid_token', 'Invalid check-in token.', array( 'status' => 403 ) );
        }

        // Check event date window (within 1 day before or after).
        $start_date = get_post_meta( $event_id, '_event_start_date', true );
        if ( $start_date ) {
            $event_ts = strtotime( $start_date );
            $now_ts   = current_time( 'timestamp' );
            if ( abs( $now_ts - $event_ts ) > DAY_IN_SECONDS ) {
                return new WP_Error( 'outside_window', 'Check-in is only available on the day of the event.', array( 'status' => 400 ) );
            }
        }

        // Check for duplicate check-in.
        $table     = $wpdb->prefix . 'culture_attendance';
        $existing  = $wpdb->get_var( $wpdb->prepare(
            "SELECT id FROM {$table} WHERE user_id = %d AND event_id = %d AND status = 'checked_in' LIMIT 1",
            $user_id, $event_id
        ) );
        if ( $existing ) {
            return rest_ensure_response( array(
                'already_checked_in' => true,
                'message'            => 'You have already checked in to this event.',
            ) );
        }

        // Insert check-in record.
        $wpdb->insert(
            $table,
            array(
                'user_id'      => $user_id,
                'event_id'     => $event_id,
                'status'       => 'checked_in',
                'checkin_time' => current_time( 'mysql' ),
            ),
            array( '%d', '%d', '%s', '%s' )
        );

        // Award reputation and credits directly — the previous do_action() hooks
        // ('culture_award_points' / 'culture_award_credits') had no listeners
        // anywhere in the codebase, so check-ins were silently awarding 0
        // reputation despite the response message claiming otherwise.
        $rep_earned     = Culture_Gamification::get_point_value( 'event_checkin' );
        $credits_earned = Culture_Gamification::get_credit_bonus( 'event_checkin' );
        Culture_Gamification::award_reputation( $user_id, $rep_earned, 'event_checkin', $event_id );
        Culture_Gamification::award_credits( $user_id, $credits_earned, 'event_checkin', $event_id );

        return rest_ensure_response( array(
            'success'        => true,
            'message'        => "Check-in successful! You earned {$rep_earned} points and {$credits_earned} credits.",
            'rep_earned'     => $rep_earned,
            'credits_earned' => $credits_earned,
        ) );
    }

    /* ——————————————————————————————————————
     *  Reloadly — instant rewards
     * —————————————————————————————————————— */

    public static function handle_reloadly_operators( $request ) {
        if ( ! Culture_Reloadly::is_configured() ) {
            return new WP_Error( 'reloadly_disabled', 'Instant rewards are not available right now.', array( 'status' => 503 ) );
        }

        $country_iso = strtoupper( sanitize_text_field( $request->get_param( 'country_iso' ) ) );
        $phone       = sanitize_text_field( $request->get_param( 'phone' ) ?? '' );

        if ( $phone ) {
            $result = Culture_Reloadly::detect_operator( $phone, $country_iso );
        } else {
            $result = Culture_Reloadly::get_operators( $country_iso );
        }

        if ( is_wp_error( $result ) ) {
            return $result;
        }

        return rest_ensure_response( $result );
    }

    public static function handle_reloadly_products( $request ) {
        if ( ! Culture_Reloadly::is_configured() ) {
            return new WP_Error( 'reloadly_disabled', 'Instant rewards are not available right now.', array( 'status' => 503 ) );
        }

        $country_iso = strtoupper( sanitize_text_field( $request->get_param( 'country_iso' ) ) );
        $result      = Culture_Reloadly::get_gift_card_products( $country_iso );

        if ( is_wp_error( $result ) ) return $result;
        return rest_ensure_response( $result );
    }

    public static function handle_reloadly_topup( $request ) {
        if ( ! Culture_Reloadly::is_configured() ) {
            return new WP_Error( 'reloadly_disabled', 'Instant rewards are not available right now.', array( 'status' => 503 ) );
        }

        $user_id     = absint( $request->get_param( 'user_id' ) );
        $operator_id = absint( $request->get_param( 'operator_id' ) );
        $amount      = (float) $request->get_param( 'amount' );
        $currency    = strtoupper( sanitize_text_field( $request->get_param( 'currency' ) ?? 'NGN' ) );
        $phone       = sanitize_text_field( $request->get_param( 'phone' ) ?? '' );
        $country_iso = strtoupper( sanitize_text_field( $request->get_param( 'country_iso' ) ?? '' ) );

        if ( ! $user_id || ! $operator_id || $amount <= 0 || ! $phone || ! $country_iso ) {
            return new WP_Error( 'bad_request', 'Missing required fields.', array( 'status' => 400 ) );
        }
        if ( ! get_userdata( $user_id ) ) {
            return new WP_Error( 'invalid_user', 'User not found.', array( 'status' => 404 ) );
        }

        $credits_required = Culture_Reloadly::credits_for_amount( $amount, $currency );
        $balance          = Culture_Gamification::get_credit_balance( $user_id );

        if ( $balance < $credits_required ) {
            return new WP_Error( 'insufficient_credits',
                "You need {$credits_required} credits but only have {$balance}.",
                array( 'status' => 400 )
            );
        }

        $result = Culture_Reloadly::send_topup( $operator_id, $amount, $phone, $country_iso );
        if ( is_wp_error( $result ) ) return $result;

        Culture_Gamification::deduct_credits( $user_id, $credits_required, 'reloadly_topup', $result['transactionId'] ?? 0 );

        return rest_ensure_response( array(
            'success'          => true,
            'transaction_id'   => $result['transactionId'] ?? null,
            'credits_deducted' => $credits_required,
            'new_balance'      => Culture_Gamification::get_credit_balance( $user_id ),
        ) );
    }

    public static function handle_reloadly_giftcard( $request ) {
        if ( ! Culture_Reloadly::is_configured() ) {
            return new WP_Error( 'reloadly_disabled', 'Instant rewards are not available right now.', array( 'status' => 503 ) );
        }

        $user_id    = absint( $request->get_param( 'user_id' ) );
        $product_id = absint( $request->get_param( 'product_id' ) );
        $amount     = (float) $request->get_param( 'amount' );
        $currency   = strtoupper( sanitize_text_field( $request->get_param( 'currency' ) ?? 'USD' ) );
        $email      = sanitize_email( $request->get_param( 'email' ) ?? '' );

        if ( ! $user_id || ! $product_id || $amount <= 0 || ! $email ) {
            return new WP_Error( 'bad_request', 'Missing required fields.', array( 'status' => 400 ) );
        }
        if ( ! get_userdata( $user_id ) ) {
            return new WP_Error( 'invalid_user', 'User not found.', array( 'status' => 404 ) );
        }

        $credits_required = Culture_Reloadly::credits_for_amount( $amount, $currency );
        $balance          = Culture_Gamification::get_credit_balance( $user_id );

        if ( $balance < $credits_required ) {
            return new WP_Error( 'insufficient_credits',
                "You need {$credits_required} credits but only have {$balance}.",
                array( 'status' => 400 )
            );
        }

        $result = Culture_Reloadly::order_gift_card( $product_id, $amount, $email );
        if ( is_wp_error( $result ) ) return $result;

        Culture_Gamification::deduct_credits( $user_id, $credits_required, 'reloadly_giftcard', $result['transactionId'] ?? 0 );

        return rest_ensure_response( array(
            'success'          => true,
            'transaction_id'   => $result['transactionId'] ?? null,
            'credits_deducted' => $credits_required,
            'new_balance'      => Culture_Gamification::get_credit_balance( $user_id ),
            'redeemCode'       => $result['redeemCode'] ?? null,
            'pinCode'          => $result['pinCode'] ?? null,
            'cardNumber'       => $result['cardNumber'] ?? null,
        ) );
    }
}
