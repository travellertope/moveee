<?php
/**
 * Culture Directory – REST endpoint for community entry submissions.
 *
 * Flow:
 *   1. Next.js frontend posts to /culture/v1/directory/submit (with Bearer secret).
 *   2. This handler creates a pending culture_directory post and sets meta/terms.
 *   3. Gamification: 25 XP awarded to the submitter immediately.
 *   4. Admin reviews and publishes the entry via WP admin.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class Culture_Directory {

    /**
     * Verify the shared bearer secret sent from the Next.js backend.
     *
     * The secret is stored in the WP option `culture_api_secret` and must match
     * the CULTURE_API_SECRET environment variable on the Next.js side.
     */
    public static function verify_secret( WP_REST_Request $request ) {
        $secret = get_option( 'culture_api_secret', '' );

        if ( empty( $secret ) ) {
            return new WP_Error(
                'no_secret',
                __( 'API secret not configured on the server.', 'culture-community' ),
                array( 'status' => 503 )
            );
        }

        $auth = $request->get_header( 'Authorization' );
        if ( ! $auth ) {
            return new WP_Error(
                'unauthorized',
                __( 'Missing Authorization header.', 'culture-community' ),
                array( 'status' => 401 )
            );
        }

        $token = trim( str_replace( 'Bearer', '', $auth ) );
        if ( ! hash_equals( $secret, $token ) ) {
            return new WP_Error(
                'forbidden',
                __( 'Invalid API secret.', 'culture-community' ),
                array( 'status' => 403 )
            );
        }

        return true;
    }

    /**
     * Handle a new directory entry submission from the Next.js frontend.
     */
    public static function handle_submit( WP_REST_Request $request ) {
        $user_id        = $request->get_param( 'user_id' );
        $title          = $request->get_param( 'title' );
        $excerpt        = $request->get_param( 'excerpt' );
        $content        = $request->get_param( 'content' );
        $entry_type     = $request->get_param( 'entry_type' );
        $interests      = (array) $request->get_param( 'interests' );
        $ai_gen         = (bool) $request->get_param( 'ai_generated' );
        $improving_slug = $request->get_param( 'improving_slug' );

        // Validate the submitting user exists.
        if ( $user_id > 0 && ! get_userdata( $user_id ) ) {
            return new WP_Error(
                'invalid_user',
                __( 'Submitting user not found.', 'culture-community' ),
                array( 'status' => 404 )
            );
        }

        // auto_publish flag: set by the auto-populate system job only.
        // Human submissions always go to pending for editorial review.
        $auto_publish = (bool) $request->get_param( 'auto_publish' );
        $post_status  = $auto_publish ? 'publish' : 'pending';

        // Create the post.
        $post_id = wp_insert_post( array(
            'post_title'   => $title,
            'post_excerpt' => $excerpt,
            'post_content' => $content,
            'post_status'  => $post_status,
            'post_type'    => 'culture_directory',
            'post_author'  => $user_id > 0 ? $user_id : 0,
        ), true );

        if ( is_wp_error( $post_id ) ) {
            return new WP_Error(
                'insert_failed',
                $post_id->get_error_message(),
                array( 'status' => 500 )
            );
        }

        // Persist meta.
        update_post_meta( $post_id, '_culture_dir_submitted_by', $user_id );
        update_post_meta( $post_id, '_culture_dir_ai_generated', $ai_gen ? '1' : '0' );

        // When this is an improvement of an existing entry, record the reference.
        if ( ! empty( $improving_slug ) ) {
            update_post_meta( $post_id, '_culture_dir_improves', sanitize_title( $improving_slug ) );
        }

        // Assign entry type term.
        if ( $entry_type && taxonomy_exists( 'culture_dir_type' ) ) {
            wp_set_object_terms( $post_id, $entry_type, 'culture_dir_type' );
        }

        // Assign interest terms (slugs passed from the AI output).
        if ( ! empty( $interests ) && taxonomy_exists( 'culture_interest' ) ) {
            $clean_slugs = array_map( 'sanitize_key', $interests );
            // Only set terms that actually exist to avoid creating orphan terms.
            $valid = array();
            foreach ( $clean_slugs as $slug ) {
                if ( term_exists( $slug, 'culture_interest' ) ) {
                    $valid[] = $slug;
                }
            }
            if ( ! empty( $valid ) ) {
                wp_set_object_terms( $post_id, $valid, 'culture_interest' );
            }
        }

        // Award gamification points to the submitter.
        $points_awarded = 25;
        if ( $user_id > 0 && class_exists( 'Culture_Gamification' ) ) {
            Culture_Gamification::award_points( $user_id, 'directory_submission', $points_awarded );
        }

        $post = get_post( $post_id );
        $slug = $post->post_name ?: sanitize_title( $title );

        return rest_ensure_response( array(
            'success'        => true,
            'post_id'        => $post_id,
            'slug'           => $slug,
            'points_awarded' => $points_awarded,
        ) );
    }

    /**
     * POST /culture/v1/directory/attach-image
     *
     * Accepts a base64-encoded JPEG image, uploads it to the WordPress
     * media library, and sets it as the featured image of the given post.
     *
     * Request body:
     *   post_id      int     Required. The culture_directory post ID.
     *   image_base64 string  Required. Base64-encoded JPEG data.
     *   filename     string  Optional. Suggested filename (default: image.jpg).
     */
    public static function handle_attach_image( WP_REST_Request $request ) {
        $post_id      = (int) $request->get_param( 'post_id' );
        $image_base64 = $request->get_param( 'image_base64' );
        $filename     = sanitize_file_name( $request->get_param( 'filename' ) ?: 'directory-image.jpg' );

        if ( ! $post_id || ! $image_base64 ) {
            return new WP_Error(
                'missing_params',
                __( 'post_id and image_base64 are required.', 'culture-community' ),
                array( 'status' => 400 )
            );
        }

        // Verify the target post exists and is a directory entry.
        $post = get_post( $post_id );
        if ( ! $post || 'culture_directory' !== $post->post_type ) {
            return new WP_Error(
                'invalid_post',
                __( 'Post not found or is not a directory entry.', 'culture-community' ),
                array( 'status' => 404 )
            );
        }

        // Decode the base64 image data.
        $image_data = base64_decode( $image_base64, true );
        if ( false === $image_data ) {
            return new WP_Error(
                'invalid_image',
                __( 'Could not decode base64 image data.', 'culture-community' ),
                array( 'status' => 400 )
            );
        }

        // Upload into the WordPress uploads directory.
        $upload = wp_upload_bits( $filename, null, $image_data );
        if ( ! empty( $upload['error'] ) ) {
            return new WP_Error(
                'upload_failed',
                $upload['error'],
                array( 'status' => 500 )
            );
        }

        // Determine MIME type from the filename extension.
        $mime = wp_check_filetype( $filename );

        // Create the media attachment post.
        $attachment_id = wp_insert_attachment(
            array(
                'post_mime_type' => $mime['type'] ?: 'image/jpeg',
                'post_title'     => sanitize_text_field( pathinfo( $filename, PATHINFO_FILENAME ) ),
                'post_content'   => '',
                'post_status'    => 'inherit',
            ),
            $upload['file'],
            $post_id
        );

        if ( is_wp_error( $attachment_id ) ) {
            return new WP_Error(
                'attachment_failed',
                $attachment_id->get_error_message(),
                array( 'status' => 500 )
            );
        }

        // Generate image size metadata (thumbnails etc.).
        if ( ! function_exists( 'wp_generate_attachment_metadata' ) ) {
            require_once ABSPATH . 'wp-admin/includes/image.php';
        }
        $meta = wp_generate_attachment_metadata( $attachment_id, $upload['file'] );
        wp_update_attachment_metadata( $attachment_id, $meta );

        // Set as the post's featured image.
        set_post_thumbnail( $post_id, $attachment_id );

        return rest_ensure_response( array(
            'success'       => true,
            'attachment_id' => $attachment_id,
            'url'           => $upload['url'],
        ) );
    }
}
