<?php
/**
 * Newsletter send queue — batched WP-Cron dispatch, email builder, unsubscribe handling.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class Culture_Newsletter_Queue {

    const CRON_HOOK  = 'culture_nl_process_batch';
    const BATCH_SIZE = 50;

    /**
     * The 4 region "editions" a single culture_drop/getmelit/culture_newsletter
     * post can carry its own appendix for (see Culture_ACF_Fields' "Edition
     * Appendix" group) — a US/UK/Australia/Africa newsletter no longer needs
     * 4 separate posts tagged with the same issue number and 4 different
     * _culture_nl_segment values (September 2026). Each slug maps 1:1 onto a
     * $region_filter value Culture_Subscribers_DB::resolve_send_emails()
     * already understands (real region-list slugs, plus the 'africa'
     * aggregate) — deliberately NOT sourced from the full region registry
     * (Culture_Newsletter_Lists::get_all(TYPE_REGION)), which can carry
     * arbitrary rows (ca/ke/za/...) with no matching ACF field. Add a 5th
     * entry here (and a matching field in class-culture-acf-fields.php) if a
     * 5th edition is ever needed.
     */
    const EDITIONS = array(
        'us'     => 'US',
        'uk'     => 'UK',
        'au'     => 'Australia',
        'africa' => 'Africa',
    );

    public static function init() {
        add_action( self::CRON_HOOK, array( __CLASS__, 'process_batch' ), 10, 2 );
        add_action( 'init', array( __CLASS__, 'handle_unsubscribe' ) );
    }

    /**
     * Which newsletter list a post belongs to, uniformly across all three
     * post types content can now live under:
     *  - getmelit / culture_drop: the post type itself IS the list (no meta
     *    involved — see class-culture-post-types.php's CPT registration).
     *  - culture_newsletter: legacy behaviour, unchanged — read from the
     *    _culture_nl_list post meta exactly as before.
     *
     * Every place in the plugin that used to read _culture_nl_list meta
     * directly (the send queue, analytics, the Send Newsletter meta box)
     * should go through this instead, so all three post types are handled
     * the same way with one source of truth.
     *
     * @param int    $post_id
     * @param string $default Fallback when a culture_newsletter post has no
     *                        meta set yet. Irrelevant for getmelit/culture_drop.
     * @return string
     */
    public static function resolve_nl_list( $post_id, $default = '' ) {
        switch ( get_post_type( $post_id ) ) {
            case 'getmelit':
                return 'getmelit';
            case 'culture_drop':
                return 'culture-drop';
            default:
                return get_post_meta( $post_id, '_culture_nl_list', true ) ?: $default;
        }
    }

    /**
     * Snapshot subscribers and schedule the first batch.
     *
     * Resolves recipients via Culture_Subscribers_DB::resolve_send_emails()
     * against the real subscriber/list tables (September 2026) — this used
     * to filter the flat culture_newsletter_subscribers option array
     * in-line; that option is now only read once, by the one-time migration
     * in Culture_Subscribers_DB.
     *
     * @param int $post_id Newsletter post ID.
     * @return int|false Total count queued, or false if no subscribers.
     */
    public static function schedule_send( $post_id ) {
        // Default matches send_to()/send_test() below ('getmelit') — NOT an
        // empty string, so an unset list always resolves to a real list row.
        $nl_list_slug     = self::resolve_nl_list( $post_id, 'getmelit' );
        $segment_filters  = Culture_Newsletter_Lists::get_segment_filters_for_post( $post_id );

        $list = Culture_Newsletter_Lists::get_by_slug( $nl_list_slug );
        if ( ! $list ) {
            return false;
        }

        $recipients = self::resolve_recipients( $post_id, $list['id'], $segment_filters );

        if ( empty( $recipients ) ) {
            return false;
        }

        // Snapshot into a transient so changes to the list mid-send don't affect this job.
        set_transient( "culture_nl_job_{$post_id}", $recipients, DAY_IN_SECONDS );

        update_post_meta( $post_id, '_culture_nl_send_status', 'sending' );
        update_post_meta( $post_id, '_culture_nl_send_total', count( $recipients ) );
        update_post_meta( $post_id, '_culture_nl_send_offset', 0 );
        delete_post_meta( $post_id, '_culture_nl_sent_at' );

        // Fire first batch after 5 seconds to allow the AJAX response to return first.
        wp_schedule_single_event( time() + 5, self::CRON_HOOK, array( $post_id, 0 ) );

        return count( $recipients );
    }

    /**
     * Builds the recipient snapshot for a send.
     *
     * Explicit $segment_filters (the "Segment Filters" checkboxes — any
     * combination of Region/Age/Tier/a custom axis, see
     * Culture_Newsletter_Lists::get_axes()) always wins and returns the
     * original flat email list, exactly as before — an editor who checked at
     * least one box clearly wants a single, uniformly-filtered send, not a
     * multi-edition one, even if edition-appendix fields also happen to be
     * filled in.
     *
     * Otherwise, if the post has at least one non-empty edition-appendix
     * field (see EDITIONS/Culture_ACF_Fields' "Edition Appendix" group),
     * this is a multi-edition send: returns an array of
     * ['email' => ..., 'edition' => <slug>] pairs (one edition's recipient
     * pool per filled field, unioned and deduped by email — a subscriber
     * who happens to be in two region lists gets whichever edition is
     * listed first in EDITIONS) so send_to()/process_batch() know which
     * appendix to splice in per recipient.
     *
     * Falls back to the original plain-email, no-segment-filter behaviour
     * when neither applies.
     *
     * @param array $segment_filters Already-normalized array( axis_type => array(slugs) ).
     * @return array String[] of emails, or an array of {email, edition} pairs.
     */
    private static function resolve_recipients( $post_id, $list_id, array $segment_filters ) {
        if ( $segment_filters ) {
            return Culture_Subscribers_DB::resolve_send_emails( $list_id, $segment_filters );
        }

        $editions_used = self::filled_editions( $post_id );
        if ( ! $editions_used ) {
            return Culture_Subscribers_DB::resolve_send_emails( $list_id, '' );
        }

        $recipients = array();
        $seen       = array();
        foreach ( $editions_used as $edition ) {
            foreach ( Culture_Subscribers_DB::resolve_send_emails( $list_id, $edition ) as $email ) {
                if ( isset( $seen[ $email ] ) ) {
                    continue;
                }
                $seen[ $email ] = true;
                $recipients[]   = array( 'email' => $email, 'edition' => $edition );
            }
        }

        // Fallback: any subscriber not matched by a regional segment filter
        // (e.g. unsegmented, Canada, or any other region not in EDITIONS)
        // receives the Africa edition — shared body + Africa appendix.
        foreach ( Culture_Subscribers_DB::resolve_send_emails( $list_id, '' ) as $email ) {
            if ( isset( $seen[ $email ] ) ) {
                continue;
            }
            $seen[ $email ] = true;
            $recipients[]   = array( 'email' => $email, 'edition' => 'africa' );
        }

        return $recipients;
    }

    /**
     * Which of EDITIONS actually have non-empty appendix content on this post.
     *
     * @param int $post_id
     * @return string[] Edition slugs, in EDITIONS' own order.
     */
    public static function filled_editions( $post_id ) {
        $used = array();
        foreach ( array_keys( self::EDITIONS ) as $edition ) {
            $raw = get_post_meta( $post_id, "edition_appendix_{$edition}", true );
            if ( '' !== trim( wp_strip_all_tags( (string) $raw ) ) ) {
                $used[] = $edition;
            }
        }
        return $used;
    }

    /**
     * WP-Cron callback: process one batch and schedule the next.
     *
     * @param int $post_id Newsletter post ID.
     * @param int $offset  Current position in the subscriber list.
     */
    public static function process_batch( $post_id, $offset ) {
        $subscribers = get_transient( "culture_nl_job_{$post_id}" );

        if ( false === $subscribers ) {
            // Transient expired. Check if all batches already completed.
            $total  = (int) get_post_meta( $post_id, '_culture_nl_send_total',  true );
            $offset = (int) get_post_meta( $post_id, '_culture_nl_send_offset', true );
            if ( $total > 0 && $offset >= $total ) {
                self::mark_complete( $post_id );
            } else {
                update_post_meta( $post_id, '_culture_nl_send_status', 'idle' );
            }
            return;
        }

        $batch = array_slice( $subscribers, $offset, self::BATCH_SIZE );

        if ( empty( $batch ) ) {
            self::mark_complete( $post_id );
            return;
        }

        foreach ( $batch as $recipient ) {
            // A multi-edition send's transient holds {email, edition} pairs
            // (see resolve_recipients()); every other send still holds plain
            // email strings, exactly as before.
            if ( is_array( $recipient ) ) {
                self::send_to( $recipient['email'], $post_id, $recipient['edition'] );
            } else {
                self::send_to( $recipient, $post_id );
            }
        }

        $new_offset = $offset + count( $batch );
        update_post_meta( $post_id, '_culture_nl_send_offset', $new_offset );

        if ( $new_offset >= count( $subscribers ) ) {
            self::mark_complete( $post_id );
        } else {
            // Next batch in 60 seconds — keeps us well within ZeptoMail rate limits.
            wp_schedule_single_event( time() + 60, self::CRON_HOOK, array( $post_id, $new_offset ) );
        }
    }

    /**
     * Mark a send job as complete.
     *
     * @param int $post_id
     */
    private static function mark_complete( $post_id ) {
        update_post_meta( $post_id, '_culture_nl_send_status', 'sent' );
        update_post_meta( $post_id, '_culture_nl_sent_at', current_time( 'mysql' ) );
        delete_transient( "culture_nl_job_{$post_id}" );
    }

    /**
     * Send the newsletter to a single email address.
     *
     * @param string $email
     * @param int    $post_id
     * @param string $edition Optional — one of EDITIONS' keys. When set,
     *                        that edition's appendix (if any) is appended
     *                        after the shared body. See resolve_recipients().
     */
    public static function send_to( $email, $post_id, $edition = '' ) {
        if ( ! is_email( $email ) ) {
            return;
        }

        $post = get_post( $post_id );
        if ( ! $post ) {
            return;
        }

        $title          = get_the_title( $post_id );
        $unsub_token    = self::generate_unsub_token( $email );
        $tracking_token = Culture_NL_Analytics::generate_token( $email, $post_id );

        $frontend_url = rtrim( get_option( 'culture_frontend_url', home_url( '/' ) ), '/' );
        $permalink    = $frontend_url . '/newsletter/' . $post->post_name;
        $unsub_url    = $frontend_url . '/newsletter/unsubscribe'
                      . '?email=' . rawurlencode( $email )
                      . '&token=' . rawurlencode( $unsub_token )
                      . '&c='    . $post_id;

        $nl_list       = self::resolve_nl_list( $post_id, 'getmelit' );
        $list_label    = self::list_label( $nl_list );
        $email_subject = $list_label . ': ' . $title;
        $content       = self::render_content( $post ) . self::render_edition_appendix( $post, $edition );
        $body          = self::build_email( $title, $content, $permalink, $unsub_url, false, $post_id, $tracking_token, $list_label, $email );

        wp_mail(
            $email,
            $email_subject,
            $body,
            array( 'Content-Type: text/html; charset=UTF-8' )
        );
    }

    /**
     * Send a test copy to a specific address without touching send state.
     *
     * @param int    $post_id
     * @param string $test_email
     * @param string $edition    Optional — preview one edition's appendix
     *                           spliced onto the shared body. See EDITIONS.
     * @return bool
     */
    public static function send_test( $post_id, $test_email, $edition = '' ) {
        if ( ! is_email( $test_email ) ) {
            return false;
        }

        $post = get_post( $post_id );
        if ( ! $post ) {
            return false;
        }

        $frontend_url    = rtrim( get_option( 'culture_frontend_url', home_url( '/' ) ), '/' );
        $raw_title       = get_the_title( $post_id );
        $body_title      = '[TEST] ' . $raw_title;
        if ( $edition && isset( self::EDITIONS[ $edition ] ) ) {
            $body_title .= ' (' . self::EDITIONS[ $edition ] . ' edition)';
        }
        $permalink       = $frontend_url . '/newsletter/' . $post->post_name;
        $nl_list_test    = self::resolve_nl_list( $post_id, 'getmelit' );
        $list_label_test = self::list_label( $nl_list_test );
        $email_subject   = '[TEST] ' . $list_label_test . ': ' . $raw_title;
        $content         = self::render_content( $post ) . self::render_edition_appendix( $post, $edition );
        $body            = self::build_email( $body_title, $content, $permalink, '#', true, 0, '', $list_label_test );

        return wp_mail(
            $test_email,
            $email_subject,
            $body,
            array( 'Content-Type: text/html; charset=UTF-8' )
        );
    }

    /**
     * Render a post's content for email delivery.
     *
     * Runs the_content filters (so blocks/shortcodes work) but FIRST removes
     * any image-optimisation or lazy-load hooks (Optimole, Smush, etc.) so
     * that email clients receive real <img src> values. Those plugins rely on
     * JavaScript to swap placeholder images for the real ones; email clients
     * don't run JavaScript, so without this suspension images simply never
     * appear.
     *
     * @param WP_Post $post
     * @return string Rendered HTML, safe for email.
     */
    private static function render_content( $post ) {
        return self::render_html( $post->post_content, $post );
    }

    /**
     * Same rendering pipeline as render_content(), but for an arbitrary HTML
     * string rather than $post->post_content — lets an edition's ACF
     * appendix field go through the identical the_content-filter /
     * image-lazy-load-suspension / CMS-link-rewrite treatment as the main
     * body, instead of being appended raw. See render_edition_appendix().
     *
     * @param string  $raw_content
     * @param WP_Post $post        Only used for the transient $GLOBALS['post']/
     *                             setup_postdata() context the_content filters
     *                             may rely on (e.g. shortcodes reading the
     *                             current post) — its own post_content is
     *                             never read here.
     * @return string Rendered HTML, safe for email.
     */
    private static function render_html( $raw_content, $post ) {
        global $more, $page, $pages, $multipage, $preview;
        $prev_more      = $more;
        $prev_page      = isset( $page )      ? $page      : 1;
        $prev_pages     = isset( $pages )     ? $pages     : array();
        $prev_multipage = isset( $multipage ) ? $multipage : false;

        $more      = 1;
        $page      = 1;
        $pages     = array( $raw_content );
        $multipage = false;

        $prev_post       = isset( $GLOBALS['post'] ) ? $GLOBALS['post'] : null;
        $GLOBALS['post'] = $post;
        setup_postdata( $post );

        // Suspend Optimole / lazy-load hooks before running the_content so
        // images are rendered with their real src URLs, not JS placeholders.
        $suspended = self::suspend_image_filters();

        $content = apply_filters( 'the_content', $raw_content );

        // Immediately restore so normal page rendering is unaffected.
        self::restore_image_filters( $suspended );

        $more            = $prev_more;
        $page            = $prev_page;
        $pages           = $prev_pages;
        $multipage       = $prev_multipage;
        $GLOBALS['post'] = $prev_post;
        wp_reset_postdata();

        // Strip residual <!--more--> comments.
        $content = preg_replace( '/<!--more(.*?)-->/i', '', $content );

        // Rewrite CMS-domain page links → frontend URL.
        // IMPORTANT: Use href-scoped regex, NOT a blanket str_replace.
        // Optimole CDN URLs embed the original WordPress domain in their path:
        //   https://cdn.optimole.com/.../https://cms.themoveee.com/wp-content/uploads/img.jpg
        // A str_replace( $cms_url, $frontend_url ) would corrupt that embedded
        // domain, making Optimole try to fetch from the Next.js server → 403.
        $cms_url      = rtrim( home_url( '/' ), '/' );
        $frontend_url = rtrim( get_option( 'culture_frontend_url', '' ), '/' );
        if ( $frontend_url && $cms_url !== $frontend_url ) {
            $content = preg_replace(
                '/(href=["\'])' . preg_quote( $cms_url, '/' ) . '/',
                '$1' . $frontend_url,
                $content
            );
        }

        return $content;
    }

    /**
     * Renders one edition's ACF appendix field (see Culture_ACF_Fields'
     * "Edition Appendix" group) through the same pipeline as the shared
     * body, so it gets identical block/shortcode expansion and image
     * handling — never appended as raw, unfiltered HTML.
     *
     * @param WP_Post $post
     * @param string  $edition One of EDITIONS' keys, or '' for none.
     * @return string Rendered HTML, or '' when there's no edition, or the
     *                 field is empty.
     */
    private static function render_edition_appendix( $post, $edition ) {
        if ( ! $edition ) {
            return '';
        }
        $raw = get_post_meta( $post->ID, "edition_appendix_{$edition}", true );
        if ( '' === trim( wp_strip_all_tags( (string) $raw ) ) ) {
            return '';
        }
        return self::render_html( $raw, $post );
    }

    /**
     * Remove any image-optimisation / lazy-load callbacks from the_content.
     *
     * Scans all registered the_content callbacks and removes those whose
     * class or function name contains a known image-plugin keyword. This is
     * version-agnostic — it works regardless of how Optimole names its hooks
     * internally.
     *
     * @return array Descriptors needed to re-add the callbacks.
     */
    private static function suspend_image_filters() {
        global $wp_filter;

        $suspended = array();

        if ( empty( $wp_filter['the_content'] ) ) {
            return $suspended;
        }

        // Keywords that identify image-optimisation / lazy-load plugins.
        $keywords = array(
            'optml',
            'optimole',
            'smush',
            'lazyload',
            'lazy_load',
            'lazy-load',
            'jetpack_lazy',
            'rocket_lazy',
            'bj_lazy',
        );

        foreach ( $wp_filter['the_content']->callbacks as $priority => $callbacks ) {
            foreach ( $callbacks as $id => $callback ) {
                $func = $callback['function'];

                if ( is_string( $func ) ) {
                    $cb_str = $func;
                } elseif ( is_array( $func ) && isset( $func[1] ) ) {
                    $obj    = $func[0];
                    $cb_str = ( is_object( $obj ) ? get_class( $obj ) : (string) $obj ) . '::' . $func[1];
                } else {
                    $cb_str = $id; // Closure — use WP's internal unique key
                }

                $cb_lower = strtolower( $cb_str );

                foreach ( $keywords as $kw ) {
                    if ( strpos( $cb_lower, $kw ) !== false ) {
                        remove_filter( 'the_content', $func, $priority );
                        $suspended[] = array(
                            'function'      => $func,
                            'priority'      => $priority,
                            'accepted_args' => $callback['accepted_args'],
                        );
                        break;
                    }
                }
            }
        }

        return $suspended;
    }

    /**
     * Re-attach callbacks removed by suspend_image_filters().
     *
     * @param array $suspended Return value of suspend_image_filters().
     */
    private static function restore_image_filters( array $suspended ) {
        foreach ( $suspended as $cb ) {
            add_filter( 'the_content', $cb['function'], $cb['priority'], $cb['accepted_args'] );
        }
    }

    /**
     * Generate an HMAC unsubscribe token.
     *
     * @param string $email
     * @return string
     */
    public static function generate_unsub_token( $email ) {
        return hash_hmac( 'sha256', strtolower( trim( $email ) ), AUTH_SALT );
    }

    /**
     * Verify an unsubscribe token.
     *
     * @param string $email
     * @param string $token
     * @return bool
     */
    public static function verify_unsub_token( $email, $token ) {
        return hash_equals( self::generate_unsub_token( $email ), $token );
    }

    /**
     * Handle ?culture_unsubscribe=1 on any page load.
     */
    public static function handle_unsubscribe() {
        if ( empty( $_GET['culture_unsubscribe'] ) ) {
            return;
        }

        $email       = isset( $_GET['email'] ) ? sanitize_email( rawurldecode( $_GET['email'] ) ) : '';
        $token       = isset( $_GET['token'] ) ? sanitize_text_field( $_GET['token'] ) : '';
        $post_id     = ! empty( $_GET['c'] ) ? absint( $_GET['c'] ) : 0;
        $campaign_id = ! empty( $_GET['campaign'] ) ? absint( $_GET['campaign'] ) : 0;

        if ( ! $email || ! $token || ! self::verify_unsub_token( $email, $token ) ) {
            wp_die(
                esc_html__( 'Invalid unsubscribe link. Please contact us if you need assistance.', 'culture-community' ),
                esc_html__( 'Unsubscribe Error', 'culture-community' ),
                array( 'response' => 400 )
            );
        }

        // Scoped unsubscribe: remove the subscriber from only the list(s)
        // the email that carried this link actually came from, not their
        // whole account — matches what "unsubscribe from GetMeLit" actually
        // implies when someone is also on Culture Drop or a Hub list.
        // Falls back to removing every list membership only when neither a
        // newsletter post nor a campaign can be resolved (e.g. a
        // pre-September-2026 link with no c=/campaign= param at all).
        if ( $post_id ) {
            $list_slug = self::resolve_nl_list( $post_id, '' );
            if ( $list_slug ) {
                Culture_Subscribers_DB::remove_from_list_slug( $email, $list_slug );
            } else {
                Culture_Subscribers_DB::delete_subscriber_by_email( $email );
            }
        } elseif ( $campaign_id ) {
            $campaign = class_exists( 'Culture_Campaigns' ) ? Culture_Campaigns::get( $campaign_id ) : null;
            if ( $campaign ) {
                foreach ( $campaign['listIds'] as $list_id ) {
                    $list = Culture_Newsletter_Lists::get( $list_id );
                    if ( $list ) {
                        Culture_Subscribers_DB::remove_from_list_slug( $email, $list['slug'] );
                    }
                }
            } else {
                Culture_Subscribers_DB::delete_subscriber_by_email( $email );
            }
        } else {
            Culture_Subscribers_DB::delete_subscriber_by_email( $email );
        }

        Culture_NL_Analytics::log_unsub( $email, $post_id ?: $campaign_id );

        $site_name = get_bloginfo( 'name' );
        $home_url  = home_url( '/' );

        wp_die(
            '<div style="font-family:-apple-system,BlinkMacSystemFont,\'Segoe UI\',sans-serif;max-width:480px;margin:80px auto;text-align:center;color:#14110d;">'
            . '<p style="font-size:11px;letter-spacing:.2em;text-transform:uppercase;color:#7a6f5c;margin-bottom:16px;">' . esc_html( $site_name ) . '</p>'
            . '<h2 style="font-size:28px;font-weight:300;margin:0 0 16px;">You\'ve been unsubscribed.</h2>'
            . '<p style="color:#7a6f5c;font-size:15px;line-height:1.6;margin-bottom:28px;">'
            . esc_html( $email ) . ' has been unsubscribed from The Moveee newsletters.'
            . '</p>'
            . '<a href="' . esc_url( $home_url ) . '" style="font-size:11px;letter-spacing:.15em;text-transform:uppercase;color:#14110d;text-decoration:none;border-bottom:1px solid currentColor;padding-bottom:2px;">Return Home</a>'
            . '</div>',
            esc_html__( 'Unsubscribed', 'culture-community' ),
            array( 'response' => 200 )
        );
    }

    /**
     * Resolve a list slug (getmelit/culture-drop/a Hub list/a custom list/
     * etc.) to its human-readable name via the list registry — replaces the
     * old hardcoded $nl_labels lookup, which only covered the 6 slugs every
     * install was seeded with and had no way to label a Hub or admin-created
     * list correctly.
     *
     * @param string $list_slug
     * @return string
     */
    public static function list_label( $list_slug ) {
        $list = class_exists( 'Culture_Newsletter_Lists' ) ? Culture_Newsletter_Lists::get_by_slug( $list_slug ) : null;
        return $list ? $list['name'] : ( $list_slug ? ucwords( str_replace( '-', ' ', $list_slug ) ) : 'GetMeLit' );
    }

    /**
     * Public wrapper around build_email() for Culture_Campaigns — one-off
     * campaigns have no WP_Post/list-slug to resolve a label from, so they
     * pass a plain label string directly.
     */
    public static function build_campaign_email( $title, $content, $permalink, $is_test = false, $campaign_id = 0, $tracking_token = '', $list_label = 'Moveee', $unsub_url = '#', $email = '' ) {
        return self::build_email( $title, $content, $permalink, $unsub_url, $is_test, $campaign_id, $tracking_token, $list_label, $email );
    }

    /**
     * Build the full HTML email body.
     *
     * @param string $title
     * @param string $content
     * @param string $permalink
     * @param string $unsub_url
     * @param bool   $is_test
     * @param int    $campaign_id
     * @param string $tracking_token
     * @param string $list_label     Human-readable list name for the footer
     *                                ("You are receiving this because you
     *                                subscribed to {list_label}.").
     * @return string
     */
    public static function build_email(
        $title,
        $content,
        $permalink,
        $unsub_url,
        $is_test        = false,
        $campaign_id    = 0,
        $tracking_token = '',
        $list_label     = 'GetMeLit',
        $email          = ''
    ) {
        $site_name = get_bloginfo( 'name' );
        $nl_label  = $list_label ?: 'GetMeLit';

        // ── Link rewriting (click tracking) ──────────────────────────────────
        if ( ! $is_test && $campaign_id && $tracking_token ) {
            $track_base = rest_url( 'culture/v1/track/click' );

            $content = preg_replace_callback(
                '/href=(["\'])(https?:\/\/[^"\'>\s]+)\1/i',
                function ( $m ) use ( $campaign_id, $tracking_token, $track_base, $email ) {
                    $url = $m[2];
                    if ( strpos( $url, 'culture_unsubscribe' ) !== false
                        || strpos( $url, 'track/click' ) !== false ) {
                        return $m[0];
                    }
                    $tracked = esc_url( add_query_arg( array(
                        'c' => $campaign_id,
                        't' => $tracking_token,
                        'u' => rawurlencode( $url ),
                        's' => Culture_NL_Analytics::sign_url( $url, $campaign_id, $email ),
                    ), $track_base ) );
                    return 'href=' . $m[1] . $tracked . $m[1];
                },
                $content
            );
        }

        // ── Tracking pixel ───────────────────────────────────────────────────
        $pixel_html = '';
        if ( ! $is_test && $campaign_id && $tracking_token ) {
            $pixel_url  = esc_url( add_query_arg( array(
                'c' => $campaign_id,
                't' => $tracking_token,
            ), rest_url( 'culture/v1/track/open' ) ) );
            $pixel_html = '<img src="' . $pixel_url . '" width="1" height="1"'
                        . ' style="position:absolute;visibility:hidden;width:1px;height:1px;" alt="">';
        }

        // ── HTML template ────────────────────────────────────────────────────
        ob_start();
        ?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?php echo esc_html( $title ); ?></title>
<style>
  body { margin:0; padding:0; background:#ffffff; font-family:Georgia,'Times New Roman',serif; color:#14110d; }
  .wrap { max-width:600px; margin:0 auto; background:#ffffff; }
  .content { padding:16px 16px 12px; font-size:16px; line-height:1.75; }
  .content p { margin:0 0 20px; }
  .content h1,.content h2,.content h3 { font-weight:400; line-height:1.3; margin:32px 0 14px; }
  .content h2 { font-size:22px; }
  .content h3 { font-size:18px; }
  .content a { color:#8b6f47; }
  .content img { max-width:100%; height:auto; display:block; margin:24px 0; }
  .content hr { border:none; border-top:1px solid #e8e0d4; margin:32px 0; }
  .footer { padding:12px 16px 18px; border-top:1px solid #e8e0d4; font-family:-apple-system,BlinkMacSystemFont,'Courier New',monospace; font-size:10px; letter-spacing:.1em; color:#a09080; }
  .footer a { color:#7a6f5c; text-decoration:none; }
</style>
</head>
<body>
<div class="wrap">
  <div class="content">
    <?php
    // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
    echo $content;
    ?>
  </div>
  <div class="footer">
    <p>
      You are receiving this because you subscribed to <?php echo esc_html( $nl_label ); ?>.<br>
      <?php if ( $permalink && '#' !== $permalink ) : ?>
      <a href="<?php echo esc_url( $permalink ); ?>">Read online</a> &middot;
      <?php endif; ?>
      <a href="<?php echo esc_url( $unsub_url ); ?>">Unsubscribe</a>
    </p>
  </div>
  <?php
  // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
  echo $pixel_html;
  ?>
</div>
</body>
</html>
        <?php
        return ob_get_clean();
    }

    /**
     * Get the current send status for a newsletter post.
     *
     * @param int $post_id
     * @return array { status, total, offset, percent, sent_at }
     */
    public static function get_send_status( $post_id ) {
        $status  = get_post_meta( $post_id, '_culture_nl_send_status', true ) ?: 'idle';
        $total   = (int) get_post_meta( $post_id, '_culture_nl_send_total', true );
        $offset  = (int) get_post_meta( $post_id, '_culture_nl_send_offset', true );
        $sent_at = get_post_meta( $post_id, '_culture_nl_sent_at', true );

        return array(
            'status'  => $status,
            'total'   => $total,
            'offset'  => $offset,
            'percent' => $total > 0 ? min( 100, (int) round( ( $offset / $total ) * 100 ) ) : 0,
            'sent_at' => $sent_at,
        );
    }
}
