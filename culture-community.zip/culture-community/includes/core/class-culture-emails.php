<?php
/**
 * Email notification system.
 *
 * Sends branded HTML emails for key lifecycle events:
 * - Welcome (on registration)
 * - Referral confirmation (to referrer when someone joins via their link)
 * - Payment receipt (on successful Paystack payment)
 * - Grace period warning (when payment fails, before downgrade)
 * - Downgrade notice (when grace period expires)
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class Culture_Emails {

    /** Default from name for all outgoing emails. */
    const FROM_NAME = 'Culture Community';

    /**
     * Get the configured from name.
     *
     * @return string
     */
    private static function get_from_name() {
        return class_exists( 'Culture_Settings' ) ? Culture_Settings::get( 'culture_email_from_name' ) : self::FROM_NAME;
    }

    /**
     * Get the configured header background color.
     *
     * @return string Hex color.
     */
    private static function get_header_color() {
        return class_exists( 'Culture_Settings' ) ? Culture_Settings::get( 'culture_email_header_color' ) : '#2c3e50';
    }

    /**
     * Get the configured button color.
     *
     * @return string Hex color.
     */
    private static function get_button_color() {
        return class_exists( 'Culture_Settings' ) ? Culture_Settings::get( 'culture_email_button_color' ) : '#e67e22';
    }

    /**
     * Get the public-facing frontend URL.
     *
     * Uses the culture_frontend_url option (set in plugin settings) so that
     * email links point to the Next.js frontend rather than the WordPress CMS.
     * Falls back to home_url('/') if the option is not configured.
     *
     * @return string Trailing-slashed URL.
     */
    private static function get_frontend_url() {
        $url = get_option( 'culture_frontend_url', '' );
        return $url ? trailingslashit( esc_url_raw( $url ) ) : home_url( '/' );
    }

    public static function init() {
        // Welcome email is sent explicitly by each registration handler after
        // all user meta has been saved.  Do NOT hook it to user_register here —
        // wp_create_user() fires that action before meta is written, which would
        // produce an email with empty tier data and duplicate sends.

        // Referral confirmation to the referrer.
        add_action( 'culture_referral_completed', array( __CLASS__, 'send_referral_confirmation' ), 10, 2 );

        // Payment receipt after Paystack subscription created.
        add_action( 'culture_payment_completed', array( __CLASS__, 'send_payment_receipt' ), 10, 2 );

        // Grace period warning when payment fails.
        add_action( 'culture_grace_period_started', array( __CLASS__, 'send_grace_period_warning' ), 10, 1 );

        // Downgrade notice when grace period expires.
        add_action( 'culture_grace_period_expired', array( __CLASS__, 'send_downgrade_notice' ), 10, 1 );

        // Set HTML content type for our emails.
        add_filter( 'wp_mail_content_type', array( __CLASS__, 'set_html_content_type' ) );

        // Set from name.
        add_filter( 'wp_mail_from_name', array( __CLASS__, 'set_from_name' ) );
    }

    /**
     * Send welcome email to a newly registered user.
     *
     * @param int $user_id
     */
    public static function send_welcome_email( $user_id ) {
        $user = get_userdata( $user_id );
        if ( ! $user ) {
            return;
        }

        $tier         = get_user_meta( $user_id, '_culture_membership_tier', true ) ?: 'citizen';

        $merge = array(
            '{display_name}' => esc_html( $user->display_name ),
            '{tier}'         => esc_html( ucfirst( $tier ) ),
        );

        $tpl     = Culture_Email_Templates::get_template( 'welcome' );
        $subject = Culture_Email_Templates::merge( $tpl['subject'], $merge );

        $body  = self::get_header( Culture_Email_Templates::merge( $tpl['heading'], $merge ) );
        $body .= Culture_Email_Templates::merge( $tpl['body'], $merge );
        $body .= self::get_button( self::get_frontend_url(), Culture_Email_Templates::merge( $tpl['button'], $merge ) );
        $body .= self::get_footer();

        self::send( $user->user_email, $subject, $body );
    }

    /**
     * Send email verification link to a newly registered user.
     *
     * @param int    $user_id
     * @param string $token     Plain-text token (not the stored hash).
     * @param string $next_url  Optional path to redirect to after completing registration.
     */
    public static function send_verification_email( $user_id, $token, $next_url = '' ) {
        $user = get_userdata( $user_id );
        if ( ! $user ) {
            return;
        }

        $base      = self::get_frontend_url();
        $link      = $base . 'register/complete?uid=' . $user_id . '&token=' . rawurlencode( $token );
        if ( $next_url ) {
            $link .= '&next=' . rawurlencode( $next_url );
        }

        $subject = 'Verify your Moveee account';

        $body  = self::get_header( 'Almost there, ' . esc_html( $user->display_name ) . '!' );
        $body .= '<p style="font-size:15px;line-height:1.7;color:#3d3d3d;margin:0 0 20px;">Thanks for signing up. Click the button below to verify your email address and complete your profile — it only takes a minute.</p>';
        $body .= self::get_button( $link, 'Verify my email' );
        $body .= '<p style="font-size:13px;color:#7a6f5c;margin:20px 0 0;">This link expires in 24 hours. If you didn\'t create a Moveee account you can safely ignore this email.</p>';
        $body .= self::get_footer();

        self::send( $user->user_email, $subject, $body );
    }

    /**
     * Send account-deletion confirmation link. See class-culture-account-deletion.php
     * for the request/confirm flow this is one step of.
     *
     * @param int    $user_id
     * @param string $token Plain-text token (not the stored hash).
     */
    public static function send_account_deletion_email( $user_id, $token ) {
        $user = get_userdata( $user_id );
        if ( ! $user ) {
            return;
        }

        $base = self::get_frontend_url();
        $link = $base . 'account/delete/confirm?uid=' . $user_id . '&token=' . rawurlencode( $token );

        $subject = 'Confirm deletion of your Moveee account';

        $body  = self::get_header( 'Confirm account deletion' );
        $body .= '<p style="font-size:15px;line-height:1.7;color:#3d3d3d;margin:0 0 20px;">We received a request to permanently delete the Moveee account for ' . esc_html( $user->display_name ) . ' (' . esc_html( $user->user_email ) . '). This cannot be undone — your profile, posts, and account data will be removed.</p>';
        $body .= self::get_button( $link, 'Confirm deletion' );
        $body .= '<p style="font-size:13px;color:#7a6f5c;margin:20px 0 0;">This link expires in 24 hours. If you didn\'t request this, ignore this email and your account will stay exactly as it is.</p>';
        $body .= self::get_footer();

        self::send( $user->user_email, $subject, $body );
    }

    /**
     * Send a reading-verification code for The Moveee Literary — sent to a
     * raw email address, not a WP user (the reader may not have an account
     * at all). See class-culture-literary-access.php for the request/verify
     * flow this is one step of.
     *
     * @param string $email
     * @param string $code Plain 6-digit code (never stored in the clear).
     */
    public static function send_literary_otp_email( $email, $code ) {
        $subject = 'Your reading code for The Moveee Literary: ' . $code;

        $body  = self::get_header( 'Your reading code' );
        $body .= '<p style="font-size:15px;line-height:1.7;color:#3d3d3d;margin:0 0 20px;">Enter this code to keep reading:</p>';
        $body .= '<p style="text-align:center;margin:0 0 20px;"><span style="display:inline-block;padding:14px 28px;background:#f4f4f4;border-radius:6px;font-size:28px;font-weight:700;letter-spacing:6px;color:#161412;">' . esc_html( $code ) . '</span></p>';
        $body .= '<p style="font-size:13px;color:#7a6f5c;margin:0;">This code expires in 10 minutes. If you didn\'t request this, you can safely ignore this email.</p>';
        $body .= self::get_footer();

        self::send( $email, $subject, $body );
    }

    /**
     * Magic-code sign-in — see Culture_Magic_OTP. Used by any "enter your
     * email, get a code, you're signed in" surface (first: The Moveee
     * Literary's newsletter-subscribe landing page); copy is deliberately
     * generic, not Literary-specific.
     *
     * @param string $email
     * @param string $code
     */
    public static function send_magic_otp_email( $email, $code ) {
        $subject = 'Your Moveee sign-in code: ' . $code;

        $body  = self::get_header( 'Your sign-in code' );
        $body .= '<p style="font-size:15px;line-height:1.7;color:#3d3d3d;margin:0 0 20px;">Enter this code to continue on Moveee:</p>';
        $body .= '<p style="text-align:center;margin:0 0 20px;"><span style="display:inline-block;padding:14px 28px;background:#f4f4f4;border-radius:6px;font-size:28px;font-weight:700;letter-spacing:6px;color:#161412;">' . esc_html( $code ) . '</span></p>';
        $body .= '<p style="font-size:13px;color:#7a6f5c;margin:0;">This code expires in 10 minutes. If you didn\'t request this, you can safely ignore this email.</p>';
        $body .= self::get_footer();

        self::send( $email, $subject, $body );
    }

    /**
     * Send a magic link to a guest so they can complete a free-event RSVP.
     *
     * @param string $email       Recipient email address.
     * @param string $magic_url   The one-time magic link URL.
     * @param string $event_title Human-readable event title.
     */
    public static function send_guest_rsvp_email( string $email, string $magic_url, string $event_title ): void {
        $subject = 'Your RSVP link for: ' . $event_title;

        $body  = self::get_header( 'You\'re almost in!' );
        $body .= '<p style="font-size:15px;line-height:1.7;color:#3d3d3d;margin:0 0 12px;">Click the button below to confirm your spot at <strong>' . esc_html( $event_title ) . '</strong>. The link also creates (or signs in to) your free Moveee account.</p>';
        $body .= self::get_button( $magic_url, 'Confirm my RSVP' );
        $body .= '<p style="font-size:13px;color:#7a6f5c;margin:20px 0 0;">This link expires in 24 hours and can only be used once. If you didn\'t request this, you can safely ignore this email.</p>';
        $body .= self::get_footer();

        self::send( $email, $subject, $body );
    }

    /**
     * Notify a contributor to The Moveee Literary that their emailed submission has
     * been accepted or rejected. Fired by Culture_Literary_Submissions on a
     * status transition into 'accepted'/'rejected' — never on every save, and
     * never when the writer left no email address (nothing to send to).
     *
     * @param string $email         Writer's email address.
     * @param string $writer_name
     * @param string $section_label e.g. "Poetry" or "The Moveee Flash".
     * @param string $title         Piece title, may be blank.
     * @param string $status        'accepted' | 'rejected'.
     * @param string $payment_label e.g. "$15–$25" or "$10 flat" — only used on acceptance.
     */
    public static function send_literary_submission_decision( $email, $writer_name, $section_label, $title, $status, $payment_label = '' ) {
        if ( ! is_email( $email ) || ! in_array( $status, array( 'accepted', 'rejected' ), true ) ) {
            return false;
        }

        $merge = array(
            '{writer_name}'   => esc_html( $writer_name ),
            '{piece}'         => $title ? '&ldquo;' . esc_html( $title ) . '&rdquo;' : 'your piece',
            '{section}'       => esc_html( $section_label ),
            '{payment_label}' => esc_html( $payment_label ),
        );

        $slug    = 'accepted' === $status ? 'literary_accepted' : 'literary_rejected';
        $tpl     = Culture_Email_Templates::get_template( $slug );
        $subject = Culture_Email_Templates::merge( $tpl['subject'], $merge );

        $body  = self::get_header( Culture_Email_Templates::merge( $tpl['heading'], $merge ) );
        $body .= Culture_Email_Templates::merge( $tpl['body'], $merge );
        $body .= self::get_button( self::get_frontend_url() . 'literary', Culture_Email_Templates::merge( $tpl['button'], $merge ) );
        $body .= self::get_footer();

        return self::send( $email, $subject, $body );
    }

    /**
     * Confirms receipt of an online submission to The Moveee Literary — fired the
     * moment a submission is actually created (Flash: immediately; a paid
     * section: once payment or a waiver code is confirmed). Distinct from
     * send_literary_submission_decision() above, which fires later once an
     * editor accepts/rejects the piece.
     *
     * @param string $email
     * @param string $writer_name
     * @param string $section_label
     * @param string $title
     */
    public static function send_literary_submission_received( $email, $writer_name, $section_label, $title ) {
        if ( ! is_email( $email ) ) {
            return false;
        }

        $merge = array(
            '{writer_name}' => esc_html( $writer_name ),
            '{piece}'       => $title ? '&ldquo;' . esc_html( $title ) . '&rdquo;' : 'your piece',
            '{section}'     => esc_html( $section_label ),
        );

        $tpl     = Culture_Email_Templates::get_template( 'literary_received' );
        $subject = Culture_Email_Templates::merge( $tpl['subject'], $merge );

        $body  = self::get_header( Culture_Email_Templates::merge( $tpl['heading'], $merge ) );
        $body .= Culture_Email_Templates::merge( $tpl['body'], $merge );
        $body .= self::get_button( self::get_frontend_url() . 'literary', Culture_Email_Templates::merge( $tpl['button'], $merge ) );
        $body .= self::get_footer();

        return self::send( $email, $subject, $body );
    }

    /**
     * Send referral confirmation to the referrer.
     *
     * @param int $referrer_id
     * @param int $new_user_id
     */
    public static function send_referral_confirmation( $referrer_id, $new_user_id ) {
        $referrer = get_userdata( $referrer_id );
        $new_user = get_userdata( $new_user_id );
        if ( ! $referrer || ! $new_user ) {
            return;
        }

        $points         = Culture_Gamification::get_points( $referrer_id );
        $referral_count = Culture_Referrals::get_referral_count( $referrer_id );

        $merge = array(
            '{referrer_name}'   => esc_html( $referrer->display_name ),
            '{new_member_name}' => esc_html( $new_user->display_name ),
            '{referral_points}' => Culture_Gamification::get_point_value( 'referral' ),
            '{referral_count}'  => esc_html( $referral_count ),
            '{total_points}'    => esc_html( $points ),
        );

        $tpl     = Culture_Email_Templates::get_template( 'referral' );
        $subject = Culture_Email_Templates::merge( $tpl['subject'], $merge );

        $body  = self::get_header( Culture_Email_Templates::merge( $tpl['heading'], $merge ) );
        $body .= Culture_Email_Templates::merge( $tpl['body'], $merge );
        $body .= self::get_button( self::get_frontend_url(), Culture_Email_Templates::merge( $tpl['button'], $merge ) );
        $body .= self::get_footer();

        self::send( $referrer->user_email, $subject, $body );
    }

    /**
     * Send payment receipt after successful Paystack transaction.
     *
     * @param int   $user_id
     * @param array $transaction_data Paystack transaction data.
     */
    public static function send_payment_receipt( $user_id, $transaction_data = array() ) {
        $user = get_userdata( $user_id );
        if ( ! $user ) {
            return;
        }

        $amount    = isset( $transaction_data['amount'] ) ? $transaction_data['amount'] / 100 : 0;
        $currency  = $transaction_data['currency'] ?? 'NGN';
        $reference = $transaction_data['reference'] ?? '';

        // Fall back to whichever tier this payment just granted the user —
        // 'lit' (Moveee Lit) or 'patron' (Moveee Pro), see CLAUDE.md's
        // "Three-tier membership" section — rather than always assuming Pro.
        $granted_tier      = get_user_meta( $user_id, '_culture_membership_tier', true );
        $default_plan_name = ( 'lit' === $granted_tier )
            ? __( 'Moveee Lit Membership', 'culture-community' )
            : __( 'Patron Membership', 'culture-community' );
        $plan_name = $transaction_data['plan']['name'] ?? $default_plan_name;

        $merge = array(
            '{display_name}' => esc_html( $user->display_name ),
            '{plan_name}'    => esc_html( $plan_name ),
            '{amount}'       => esc_html( number_format( $amount, 2 ) ),
            '{currency}'     => esc_html( $currency ),
            '{reference}'    => esc_html( $reference ),
            '{date}'         => esc_html( date_i18n( get_option( 'date_format' ) ) ),
        );

        $tpl     = Culture_Email_Templates::get_template( 'payment_receipt' );
        $subject = Culture_Email_Templates::merge( $tpl['subject'], $merge );

        $body  = self::get_header( Culture_Email_Templates::merge( $tpl['heading'], $merge ) );
        $body .= Culture_Email_Templates::merge( $tpl['body'], $merge );
        $body .= self::get_button( self::get_frontend_url(), Culture_Email_Templates::merge( $tpl['button'], $merge ) );
        $body .= self::get_footer();

        self::send( $user->user_email, $subject, $body );
    }

    /**
     * Send grace period warning when payment fails.
     *
     * @param int $user_id
     */
    public static function send_grace_period_warning( $user_id ) {
        $user = get_userdata( $user_id );
        if ( ! $user ) {
            return;
        }

        $grace_days = Culture_Cron::get_grace_period_days();

        $merge = array(
            '{display_name}' => esc_html( $user->display_name ),
            '{grace_days}'   => $grace_days,
        );

        $tpl     = Culture_Email_Templates::get_template( 'grace_period' );
        $subject = Culture_Email_Templates::merge( $tpl['subject'], $merge );

        $body  = self::get_header( Culture_Email_Templates::merge( $tpl['heading'], $merge ) );
        $body .= Culture_Email_Templates::merge( $tpl['body'], $merge );
        $body .= self::get_button( self::get_frontend_url(), Culture_Email_Templates::merge( $tpl['button'], $merge ) );
        $body .= self::get_footer();

        self::send( $user->user_email, $subject, $body );
    }

    /**
     * Send downgrade notice when grace period expires.
     *
     * @param int $user_id
     */
    public static function send_downgrade_notice( $user_id ) {
        $user = get_userdata( $user_id );
        if ( ! $user ) {
            return;
        }

        $merge = array(
            '{display_name}' => esc_html( $user->display_name ),
        );

        $tpl     = Culture_Email_Templates::get_template( 'downgrade' );
        $subject = Culture_Email_Templates::merge( $tpl['subject'], $merge );

        $body  = self::get_header( Culture_Email_Templates::merge( $tpl['heading'], $merge ) );
        $body .= Culture_Email_Templates::merge( $tpl['body'], $merge );
        $body .= self::get_button( self::get_frontend_url(), Culture_Email_Templates::merge( $tpl['button'], $merge ) );
        $body .= self::get_footer();

        self::send( $user->user_email, $subject, $body );
    }

    /**
     * Send an HTML email.
     *
     * @param string $to      Recipient email.
     * @param string $subject Email subject.
     * @param string $body    HTML body.
     * @return bool
     */
    private static function send( $to, $subject, $body ) {
        $headers = array(
            'Content-Type: text/html; charset=UTF-8',
        );

        return wp_mail( $to, $subject, $body, $headers );
    }

    /**
     * Get the branded email header.
     *
     * @param string $heading
     * @return string
     */
    private static function get_header( $heading ) {
        $html  = '<!DOCTYPE html><html><head><meta charset="UTF-8"></head>';
        $html .= '<body style="margin:0;padding:0;background:#f4f4f4;font-family:-apple-system,BlinkMacSystemFont,Segoe UI,Roboto,Helvetica,Arial,sans-serif;">';
        $html .= '<table width="100%" cellpadding="0" cellspacing="0" style="background:#f4f4f4;padding:40px 20px;">';
        $html .= '<tr><td align="center">';
        $html .= '<table width="600" cellpadding="0" cellspacing="0" style="background:#fff;border-radius:8px;overflow:hidden;box-shadow:0 2px 8px rgba(0,0,0,0.1);">';

        // Header bar.
        $html .= '<tr><td style="background:' . esc_attr( self::get_header_color() ) . ';padding:30px 40px;text-align:center;">';
        $html .= '<h1 style="margin:0;color:#fff;font-size:24px;font-weight:700;">' . esc_html( $heading ) . '</h1>';
        $html .= '</td></tr>';

        // Body area starts.
        $html .= '<tr><td style="padding:30px 40px;color:#2c3e50;font-size:15px;line-height:1.6;">';

        return $html;
    }

    /**
     * Get a CTA button.
     *
     * @param string $url
     * @param string $text
     * @return string
     */
    private static function get_button( $url, $text ) {
        return '<p style="text-align:center;margin:30px 0 10px;">'
            . '<a href="' . esc_url( $url ) . '" style="display:inline-block;padding:14px 32px;background:' . esc_attr( self::get_button_color() ) . ';color:#fff;text-decoration:none;border-radius:6px;font-weight:600;font-size:15px;">'
            . esc_html( $text )
            . '</a></p>';
    }

    /**
     * Get the branded email footer.
     *
     * @return string
     */
    private static function get_footer() {
        $html  = '</td></tr>';

        // Footer.
        $html .= '<tr><td style="padding:20px 40px;background:#f8f9fa;text-align:center;font-size:12px;color:#7f8c8d;border-top:1px solid #eee;">';
        $html .= '<p style="margin:0 0 4px;">' . esc_html( get_bloginfo( 'name' ) ) . '</p>';
        $html .= '<p style="margin:0;">' . __( 'You are receiving this email because you are a member of Culture Community.', 'culture-community' ) . '</p>';
        $html .= '</td></tr>';

        $html .= '</table>';
        $html .= '</td></tr></table>';
        $html .= '</body></html>';

        return $html;
    }

    /**
     * Set HTML content type for wp_mail.
     *
     * @return string
     */
    public static function set_html_content_type() {
        return 'text/html';
    }

    /**
     * Confirm a paid RSVP to a guest — lets them know their spot is secured
     * and includes a magic sign-in link to access their new Moveee account.
     */
    public static function send_paid_rsvp_confirmation_email( string $email, string $event_title, int $amount, string $currency, string $magic_url ): void {
        $sym = [ 'NGN' => '₦', 'USD' => '$', 'GBP' => '£', 'EUR' => '€' ];
        $price_label = ( $sym[ $currency ] ?? $currency ) . number_format( $amount );

        $subject = 'Your spot is confirmed — ' . $event_title;
        $body  = self::get_header( 'You\'re in!' );
        $body .= '<p style="font-size:15px;line-height:1.7;color:#3d3d3d;margin:0 0 12px;">Your payment of <strong>' . esc_html( $price_label ) . '</strong> for <strong>' . esc_html( $event_title ) . '</strong> went through — your spot is confirmed.</p>';
        $body .= '<p style="font-size:15px;line-height:1.7;color:#3d3d3d;margin:0 0 20px;">Click below to sign in to your Moveee account, where you can manage your RSVPs and connect with the community.</p>';
        $body .= self::get_button( $magic_url, 'Access my account' );
        $body .= '<p style="font-size:13px;color:#7a6f5c;margin:20px 0 0;">This link expires in 24 hours and can only be used once.</p>';
        $body .= self::get_footer();

        self::send( $email, $subject, $body );
    }

    /**
     * Set from name for wp_mail.
     *
     * @return string
     */
    public static function set_from_name() {
        return self::get_from_name();
    }
}
