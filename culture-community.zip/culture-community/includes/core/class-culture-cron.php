<?php
/**
 * Scheduled jobs for Culture Community.
 *
 * This class is the canonical owner for the five jobs below — automation runs
 * via WordPress cron, triggered by a real server cron on Lightsail every 30
 * minutes (see wp-config.php: DISABLE_WP_CRON = true). These same five jobs
 * must NOT also be scheduled on cron-job.org (the external scheduler used for
 * jobs that have no WP-side logic) — running both would double-fire the seed
 * with mismatched frequencies. See "Split cron ownership" in CLAUDE.md.
 *
 * Jobs:
 *  - Grace period check (daily) — downgrades lapsed Patron accounts.
 *  - Directory seed (weekly)    — triggers Next.js /api/directory/auto-populate.
 *  - Pulse refresh (daily)      — triggers Next.js /api/pulse/refresh.
 *  - Events seed (daily)        — RETIRED (October 2026). See "retire the seeder" decision.
 *  - Stoop cluster forming-expiry sweep (daily) — pure WP-side
 *    logic, archives 'forming' clusters past their window (no Next.js call).
 *  - Stoop host service award (monthly) — Phase 4 — awards
 *    'cluster_host_served' once per active cluster's host per month.
 *  - Stoop check-in reminder (daily) — Phase 4 — notifies all
 *    active members of clusters meeting today.
 *  - Literati Connect attendance sweep (daily) — Phase 5 — awards
 *    'literati_connect_attended' once per event per confirmed RSVP attendee,
 *    for literati-flagged culture_event posts that ended in the last 48h.
 *
 * Retired (September 2026): Quotes seed (weekly), which used to trigger
 * Next.js /api/quotes/auto-populate — removed at explicit user request
 * ("the seeding dont even work autonomously anyways") alongside the wider
 * quotes/feed-merge work (see CLAUDE.md). The auto-populate routes and
 * most of packages/shared/lib/quotes-seeder.ts were deleted; existing
 * seeded quotes are unaffected and now render as normal feed cards via a
 * synthetic system author (Culture_System_Author). Manual curation via WP
 * Admin still works — only the automated weekly seed is gone.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class Culture_Cron {

    // ── Hook names ────────────────────────────────────────────────────────

    const HOOK_GRACE_CHECK      = 'culture_check_grace_periods';
    // HOOK_SEED_DIRECTORY retired November 2026 — human/catalog submissions only going forward.
    const HOOK_SEED_DIRECTORY   = 'culture_seed_directory';
    const HOOK_REFRESH_PULSE    = 'culture_refresh_pulse';
    // HOOK_SEED_EVENTS retired October 2026 — community-posted events only going forward.
    const HOOK_CLUSTER_SWEEP           = 'culture_check_cluster_forming_expiry';
    const HOOK_CLUSTER_ELECTION_TALLY  = 'culture_check_cluster_elections';
    const HOOK_CLUSTER_GRACE_SWEEP     = 'culture_check_cluster_host_vacancy_grace';
    const HOOK_CLUSTER_HOST_SERVICE    = 'culture_award_cluster_host_service';
    const HOOK_CLUSTER_CHECKIN_REMINDER = 'culture_send_cluster_checkin_reminders';
    const HOOK_LITERATI_ATTENDANCE      = 'culture_sweep_literati_attendance';

    /** Default grace period in days. */
    const GRACE_PERIOD_DAYS = 7;

    // ── Bootstrap ─────────────────────────────────────────────────────────

    public static function init() {
        add_filter( 'cron_schedules',      array( __CLASS__, 'add_schedules' ) );
        add_action( self::HOOK_GRACE_CHECK,    array( __CLASS__, 'process_grace_periods' ) );
        // HOOK_SEED_DIRECTORY retired November 2026 — no longer registered.
        add_action( self::HOOK_REFRESH_PULSE,  array( __CLASS__, 'refresh_pulse' ) );
        add_action( self::HOOK_CLUSTER_SWEEP,  array( __CLASS__, 'sweep_forming_clusters' ) );
        add_action( self::HOOK_CLUSTER_ELECTION_TALLY, array( __CLASS__, 'tally_cluster_elections' ) );
        add_action( self::HOOK_CLUSTER_GRACE_SWEEP,    array( __CLASS__, 'sweep_cluster_host_vacancy' ) );
        add_action( self::HOOK_CLUSTER_HOST_SERVICE,   array( __CLASS__, 'award_cluster_host_service' ) );
        add_action( self::HOOK_CLUSTER_CHECKIN_REMINDER, array( __CLASS__, 'send_cluster_checkin_reminders' ) );
        add_action( self::HOOK_LITERATI_ATTENDANCE,      array( __CLASS__, 'sweep_literati_attendance' ) );

        self::maybe_clear_retired_jobs();
        // maybe_reschedule_directory_seed() retired alongside HOOK_SEED_DIRECTORY (November 2026).

        // Deferred gamification: newsletter subscribe fires this instead of calling
        // award_points() synchronously inside the public unauthenticated endpoint.
        add_action( 'culture_award_newsletter_points', function( $user_id ) {
            if ( class_exists( 'Culture_Gamification' ) ) {
                Culture_Gamification::award_points( (int) $user_id, 'newsletter_subscribed' );
            }
        } );

        // Self-heal: schedule any jobs that are missing without requiring re-activation.
        // Runs on admin_init (not init) so REST/GraphQL requests are not affected,
        // and only once per hour via transient to avoid 7 wp_next_scheduled() calls
        // on every admin page load.
        add_action( 'admin_init', array( __CLASS__, 'maybe_schedule' ), 99 );
    }

    /**
     * Register custom cron intervals that WordPress doesn't include by default.
     */
    public static function add_schedules( $schedules ) {
        if ( ! isset( $schedules['thirtyminutes'] ) ) {
            $schedules['thirtyminutes'] = array(
                'interval' => 30 * MINUTE_IN_SECONDS,
                'display'  => __( 'Every 30 Minutes', 'culture-community' ),
            );
        }
        if ( ! isset( $schedules['weekly'] ) ) {
            $schedules['weekly'] = array(
                'interval' => 7 * DAY_IN_SECONDS,
                'display'  => __( 'Once a Week', 'culture-community' ),
            );
        }
        if ( ! isset( $schedules['monthly'] ) ) {
            $schedules['monthly'] = array(
                'interval' => 30 * DAY_IN_SECONDS,
                'display'  => __( 'Once a Month', 'culture-community' ),
            );
        }
        return $schedules;
    }

    // ── Schedule / Unschedule ─────────────────────────────────────────────

    /**
     * Self-heal wrapper: only runs the schedule check once per hour.
     */
    public static function maybe_schedule() {
        if ( get_transient( 'culture_cron_scheduled' ) ) {
            return;
        }
        set_transient( 'culture_cron_scheduled', 1, HOUR_IN_SECONDS );
        self::schedule();
    }

    /**
     * Register all recurring events. Called on plugin activation and by maybe_schedule().
     */
    public static function schedule() {
        $jobs = array(
            self::HOOK_GRACE_CHECK      => 'daily',
            // HOOK_SEED_DIRECTORY retired November 2026.
            self::HOOK_REFRESH_PULSE    => 'daily',
            'culture_check_perk_expiry'        => 'hourly',
            self::HOOK_CLUSTER_SWEEP           => 'daily',
            self::HOOK_CLUSTER_ELECTION_TALLY  => 'daily',
            self::HOOK_CLUSTER_GRACE_SWEEP     => 'daily',
            self::HOOK_CLUSTER_HOST_SERVICE      => 'monthly',
            self::HOOK_CLUSTER_CHECKIN_REMINDER  => 'daily',
            self::HOOK_LITERATI_ATTENDANCE       => 'daily',
        );

        foreach ( $jobs as $hook => $recurrence ) {
            if ( ! wp_next_scheduled( $hook ) ) {
                wp_schedule_event( time(), $recurrence, $hook );
            }
        }
    }

    /**
     * Remove all recurring events. Called on plugin deactivation.
     */
    public static function unschedule() {
        $hooks = array(
            self::HOOK_GRACE_CHECK,
            // HOOK_SEED_DIRECTORY retired November 2026 — cleared via maybe_clear_retired_jobs().
            self::HOOK_REFRESH_PULSE,
            'culture_check_perk_expiry',
            self::HOOK_CLUSTER_SWEEP,
            self::HOOK_CLUSTER_ELECTION_TALLY,
            self::HOOK_CLUSTER_GRACE_SWEEP,
            self::HOOK_CLUSTER_HOST_SERVICE,
            self::HOOK_CLUSTER_CHECKIN_REMINDER,
            self::HOOK_LITERATI_ATTENDANCE,
        );

        foreach ( $hooks as $hook ) {
            $timestamp = wp_next_scheduled( $hook );
            if ( $timestamp ) {
                wp_unschedule_event( $timestamp, $hook );
            }
        }
    }

    /**
     * One-time cleanup for jobs retired from this class (currently just
     * 'culture_seed_quotes' — see the docblock above). Removing a job's
     * add_action() alone leaves its wp_schedule_event() row in the cron
     * table forever, still firing on schedule into a do_action() with no
     * listener — harmless, but it clutters WP Admin's cron/health views
     * and keeps hitting the DB for nothing. Gated by option so this only
     * runs once per retired-job batch, same shape as every other
     * maybe_backfill_ / maybe_clear_ method in this plugin.
     */
    private static function maybe_clear_retired_jobs() {
        if ( '3' === get_option( 'culture_cron_retired_jobs_cleared', '' ) ) {
            return;
        }

        // v1: culture_seed_quotes (retired September 2026)
        // v2: culture_seed_events (retired October 2026 — community-posted events only)
        // v3: culture_seed_directory (retired November 2026 — human/catalog submissions only)
        $retired_hooks = array( 'culture_seed_quotes', 'culture_seed_events', 'culture_seed_directory' );
        foreach ( $retired_hooks as $hook ) {
            wp_clear_scheduled_hook( $hook );
        }

        update_option( 'culture_cron_retired_jobs_cleared', '3' );
    }

    /**
     * One-time migration: directory seed moved from weekly to daily
     * (November 2026). wp_schedule_event() never changes an *already*
     * scheduled event's recurrence — only schedule()'s own
     * `if ( ! wp_next_scheduled( $hook ) )` guard, which does nothing once
     * a row already exists — so changing the interval above alone would
     * silently keep firing weekly forever on any site where this job was
     * already scheduled. Clears the existing row so the next schedule()
     * call (same request, right after this) re-registers it with the new
     * interval. Same one-time-migration shape as maybe_clear_retired_jobs().
     */
    private static function maybe_reschedule_directory_seed() {
        if ( get_option( 'culture_cron_directory_seed_daily', '' ) ) {
            return;
        }

        $timestamp = wp_next_scheduled( self::HOOK_SEED_DIRECTORY );
        if ( $timestamp ) {
            wp_unschedule_event( $timestamp, self::HOOK_SEED_DIRECTORY );
        }

        // Reschedule immediately in the same request, rather than leaving it
        // to schedule()/maybe_schedule() — that one only runs on admin_init,
        // which a wp-cron.php run (the real trigger, every 30 min via the
        // Lightsail server crontab) never fires. Leaving it to admin_init
        // would mean the job sits unscheduled until someone next opens WP
        // Admin, exactly the kind of silent gap this whole pass is trying
        // to close, not reintroduce.
        wp_schedule_event( time(), 'daily', self::HOOK_SEED_DIRECTORY );

        update_option( 'culture_cron_directory_seed_daily', '1' );
    }

    // ── Job handlers ──────────────────────────────────────────────────────

    /**
     * Downgrade Patron users whose grace period has expired,
     * and also expire any manually-set subscriptions past their expiry date.
     */
    public static function process_grace_periods() {

        // ── 1. Grace-period expiry (payment gateway lapsed subscribers) ──────
        $days   = class_exists( 'Culture_Settings' )
            ? (int) Culture_Settings::get( 'culture_grace_period_days' )
            : self::GRACE_PERIOD_DAYS;
        $cutoff = gmdate( 'Y-m-d H:i:s', strtotime( '-' . $days . ' days' ) );

        $grace_users = get_users( array(
            'meta_query' => array(
                'relation' => 'AND',
                array(
                    'key'   => '_culture_subscription_status',
                    'value' => 'non-renewing',
                ),
                array(
                    'key'     => '_culture_grace_period_start',
                    'value'   => $cutoff,
                    'compare' => '<=',
                    'type'    => 'DATETIME',
                ),
            ),
            'fields' => 'ID',
        ) );

        foreach ( $grace_users as $user_id ) {
            update_user_meta( $user_id, '_culture_membership_tier',     'citizen' );
            update_user_meta( $user_id, '_culture_subscription_status', 'expired' );
            delete_user_meta( $user_id, '_culture_grace_period_start' );
            do_action( 'culture_grace_period_expired', $user_id );
        }

        // ── 2. Manual expiry (admin-set expiry date has passed) ──────────────
        $now = time();

        $manual_users = get_users( array(
            'meta_query' => array(
                'relation' => 'AND',
                array(
                    // Covers both paid tiers — Moveee Pro ('patron') and
                    // Moveee Lit ('lit', see CLAUDE.md's "Three-tier
                    // membership" section) — either can have an admin-set
                    // expiry date that needs to lapse back to Citizen.
                    'key'     => '_culture_membership_tier',
                    'value'   => array( 'patron', 'lit' ),
                    'compare' => 'IN',
                ),
                array(
                    'key'     => '_culture_subscription_expiry',
                    'value'   => 0,
                    'compare' => '>',       // only users with a real expiry date set
                    'type'    => 'NUMERIC',
                ),
                array(
                    'key'     => '_culture_subscription_expiry',
                    'value'   => $now,
                    'compare' => '<',       // expiry timestamp is in the past
                    'type'    => 'NUMERIC',
                ),
                array(
                    'key'     => '_culture_subscription_status',
                    'value'   => 'expired',
                    'compare' => '!=',      // skip already-expired rows
                ),
            ),
            'fields' => 'ID',
        ) );

        foreach ( $manual_users as $user_id ) {
            update_user_meta( $user_id, '_culture_membership_tier',     'citizen' );
            update_user_meta( $user_id, '_culture_subscription_status', 'expired' );
            do_action( 'culture_manual_subscription_expired', $user_id );
        }
    }

    /**
     * Trigger the Culture Directory AI seeder on Next.js.
     * Runs daily (was weekly — see maybe_reschedule_directory_seed()).
     * Sends a small batch to stay within Vercel execution limits. Blocking,
     * unlike every other call_nextjs() caller here — this job's own
     * fire-and-forget history (wp_remote_post with blocking=false) is the
     * reason a total, months-long failure never showed up anywhere: the
     * response was never looked at, so a 403 (bad/missing secret) or 503
     * (missing GEMINI_API_KEY) from Next.js logged identically to success.
     * See auto-populate/route.ts's own docblock for the full checklist.
     */
    public static function seed_directory() {
        self::call_nextjs( '/api/directory/auto-populate', array(
            'batchSize'      => 5,
            'generateImages' => true,
        ), true );
    }

    /**
     * Trigger the Pulse story refresh on Next.js.
     * Runs daily.
     */
    public static function refresh_pulse() {
        self::call_nextjs( '/api/pulse/refresh' );
    }

    /**
     * Archive Stoop clusters still 'forming' past their window
     * (default 30 days — see Culture_Clusters::forming_window_days()),
     * notifying the founder with a CTA to merge into a nearby active
     * cluster instead. Runs daily.
     */
    public static function sweep_forming_clusters() {
        if ( ! class_exists( 'Culture_Clusters' ) ) {
            return;
        }

        $window_days = Culture_Clusters::forming_window_days();
        $cutoff      = gmdate( 'Y-m-d H:i:s', strtotime( '-' . $window_days . ' days' ) );

        $stale_ids = get_posts( array(
            'post_type'      => 'culture_cluster',
            'post_status'    => 'publish',
            'posts_per_page' => -1,
            'fields'         => 'ids',
            'meta_query'     => array(
                array(
                    'key'   => '_cluster_status',
                    'value' => Culture_Clusters::STATUS_FORMING,
                ),
                array(
                    'key'     => '_cluster_created_at',
                    'value'   => $cutoff,
                    'compare' => '<=',
                    'type'    => 'DATETIME',
                ),
            ),
        ) );

        foreach ( $stale_ids as $cluster_id ) {
            update_post_meta( $cluster_id, '_cluster_status', 'archived' );

            $founder_id = (int) get_post_meta( $cluster_id, '_cluster_founder_id', true );
            if ( $founder_id && class_exists( 'Culture_Notifications' ) ) {
                Culture_Notifications::add(
                    $founder_id,
                    'cluster_forming_expired',
                    'Your Stoop didn\'t reach activation',
                    get_post_meta( $cluster_id, '_cluster_name', true ) . ' didn\'t reach enough members in time. Try joining a nearby Stoop instead.',
                    '/connect/stoop',
                    array( 'cluster_id' => $cluster_id, 'archived' => true )
                );
            }
        }
    }

    /**
     * Tally any Stoop host election whose voting window has
     * closed. Runs daily. Pure WP-side logic, no Next.js call.
     */
    public static function tally_cluster_elections() {
        if ( ! class_exists( 'Culture_Clusters' ) ) {
            return;
        }

        $now = gmdate( 'Y-m-d H:i:s' );

        $expired_ids = get_posts( array(
            'post_type'      => 'culture_cluster',
            'post_status'    => 'publish',
            'posts_per_page' => -1,
            'fields'         => 'ids',
            'meta_query'     => array(
                array(
                    'key'     => '_cluster_election_open_until',
                    'value'   => $now,
                    'compare' => '<=',
                    'type'    => 'DATETIME',
                ),
            ),
        ) );

        foreach ( $expired_ids as $cluster_id ) {
            Culture_Clusters::tally_election( $cluster_id );
        }
    }

    /**
     * Archive 'active' Stoops that have had zero members for
     * longer than the 14-day grace period. The grace-period start is read
     * from the departed host's own (now 'left') membership row's joined_at
     * column, repurposed as a vacancy marker by
     * Culture_Clusters::handle_host_departure() — no new field needed.
     * Runs daily.
     */
    public static function sweep_cluster_host_vacancy() {
        if ( ! class_exists( 'Culture_Clusters' ) ) {
            return;
        }

        global $wpdb;
        $grace_days = 14;
        $cutoff     = gmdate( 'Y-m-d H:i:s', strtotime( '-' . $grace_days . ' days' ) );
        $table      = Culture_Clusters::table();

        $active_ids = get_posts( array(
            'post_type'      => 'culture_cluster',
            'post_status'    => 'publish',
            'posts_per_page' => -1,
            'fields'         => 'ids',
            'meta_query'     => array(
                array(
                    'key'   => '_cluster_status',
                    'value' => Culture_Clusters::STATUS_ACTIVE,
                ),
            ),
        ) );

        foreach ( $active_ids as $cluster_id ) {
            if ( Culture_Clusters::get_member_count( $cluster_id ) > 0 ) {
                continue;
            }

            $last_row = $wpdb->get_row( $wpdb->prepare(
                "SELECT user_id, joined_at FROM {$table} WHERE cluster_id = %d ORDER BY joined_at DESC LIMIT 1",
                $cluster_id
            ), ARRAY_A );

            if ( ! $last_row || strtotime( $last_row['joined_at'] ) > strtotime( $cutoff ) ) {
                continue; // not stale yet
            }

            update_post_meta( $cluster_id, '_cluster_status', 'archived' );

            $last_user_id = (int) $last_row['user_id'];
            if ( $last_user_id && class_exists( 'Culture_Notifications' ) ) {
                Culture_Notifications::add(
                    $last_user_id,
                    'cluster_forming_expired',
                    'Your Stoop has been archived',
                    get_post_meta( $cluster_id, '_cluster_name', true ) . ' had no remaining members for 14 days and has been archived.',
                    '/connect/stoop',
                    array( 'cluster_id' => $cluster_id, 'archived' => true )
                );
            }
        }
    }

    /**
     * Award the recurring 'cluster_host_served' reward to every current host
     * of an 'active' Stoop, once per calendar month per cluster.
     * Idempotency is checked against the credit ledger directly (source_id =
     * cluster_id, scoped to the current month) rather than
     * Culture_Gamification::ledger_has_entry() — that helper matches on
     * source_id alone with no time window, which would only ever allow one
     * award per host for all time. Runs monthly.
     */
    public static function award_cluster_host_service() {
        if ( ! class_exists( 'Culture_Clusters' ) || ! class_exists( 'Culture_Gamification' ) ) {
            return;
        }

        global $wpdb;

        $active_ids = get_posts( array(
            'post_type'      => 'culture_cluster',
            'post_status'    => 'publish',
            'posts_per_page' => -1,
            'fields'         => 'ids',
            'meta_query'     => array(
                array(
                    'key'   => '_cluster_status',
                    'value' => Culture_Clusters::STATUS_ACTIVE,
                ),
            ),
        ) );

        $month_start = gmdate( 'Y-m-01 00:00:00' );

        foreach ( $active_ids as $cluster_id ) {
            $host_id = (int) get_post_meta( $cluster_id, '_cluster_host_id', true );
            if ( ! $host_id ) {
                continue;
            }

            $already_awarded = (bool) $wpdb->get_var( $wpdb->prepare(
                "SELECT id FROM {$wpdb->prefix}culture_credit_ledger
                 WHERE user_id = %d AND source = 'cluster_host_served' AND source_id = %d AND created_at >= %s LIMIT 1",
                $host_id, $cluster_id, $month_start
            ) );
            if ( $already_awarded ) {
                continue;
            }

            Culture_Gamification::award_points( $host_id, 'cluster_host_served' );
        }
    }

    /**
     * Same-day morning reminder to all active members of a Stoop
     * whose meeting day is today, per §6.4/§6.3 — `cluster_checkin_reminder`.
     * Runs daily; the day-of-week match against `_cluster_meeting_day`
     * (lowercase day name, e.g. "monday") keeps this a single sweep rather
     * than seven separate per-day schedules.
     */
    public static function send_cluster_checkin_reminders() {
        if ( ! class_exists( 'Culture_Clusters' ) || ! class_exists( 'Culture_Notifications' ) ) {
            return;
        }

        $today = strtolower( current_time( 'l' ) ); // e.g. "monday"

        $active_ids = get_posts( array(
            'post_type'      => 'culture_cluster',
            'post_status'    => 'publish',
            'posts_per_page' => -1,
            'fields'         => 'ids',
            'meta_query'     => array(
                array(
                    'key'   => '_cluster_status',
                    'value' => Culture_Clusters::STATUS_ACTIVE,
                ),
                array(
                    'key'   => '_cluster_meeting_day',
                    'value' => $today,
                ),
            ),
        ) );

        foreach ( $active_ids as $cluster_id ) {
            $name = get_post_meta( $cluster_id, '_cluster_name', true );
            foreach ( Culture_Clusters::get_members( $cluster_id ) as $member ) {
                Culture_Notifications::add(
                    (int) $member['id'],
                    'cluster_checkin_reminder',
                    'Stoop meets today',
                    $name . ' meets today — don\'t forget to check in.',
                    '/cluster/' . $cluster_id,
                    array( 'cluster_id' => $cluster_id )
                );
            }
        }
    }

    /**
     * Award `literati_connect_attended` reputation + credits, once per event
     * per attendee, to confirmed RSVPs on Literati Connect editorial events
     * (`culture_event` posts flagged `_culture_event_is_literati`) whose date
     * has passed. Runs daily; only scans events that ended in the last 48h so
     * each event is only checked a couple of times rather than forever.
     *
     * `wp_culture_event_rsvp` (Culture_Event_RSVP) has no `user_id` column —
     * only `email` and `event_slug` — so attendees are resolved to a WP user
     * via get_user_by('email', ...), the same lookup already used by
     * Culture_Event_RSVP::handle_submit(). RSVPs with no matching registered
     * user are silently skipped (mirrors that existing precedent).
     */
    public static function sweep_literati_attendance() {
        if ( ! class_exists( 'Culture_Gamification' ) || ! class_exists( 'Culture_Event_RSVP' ) ) {
            return;
        }

        global $wpdb;

        $window_start = gmdate( 'Y-m-d H:i:s', strtotime( '-48 hours' ) );
        $now          = current_time( 'mysql', true );

        $event_ids = get_posts( array(
            'post_type'      => 'culture_event',
            'post_status'    => 'publish',
            'posts_per_page' => -1,
            'fields'         => 'ids',
            'meta_query'     => array(
                array(
                    'key'   => '_culture_event_is_literati',
                    'value' => '1',
                ),
                array(
                    'key'     => '_culture_event_date',
                    'value'   => array( $window_start, $now ),
                    'compare' => 'BETWEEN',
                    'type'    => 'DATETIME',
                ),
            ),
        ) );

        if ( empty( $event_ids ) ) {
            return;
        }

        $rsvp_table = $wpdb->prefix . 'culture_event_rsvp';

        foreach ( $event_ids as $event_id ) {
            $slug = get_post_field( 'post_name', $event_id );
            if ( ! $slug ) {
                continue;
            }

            $rows = $wpdb->get_results( $wpdb->prepare(
                "SELECT email FROM {$rsvp_table} WHERE event_slug = %s AND status = 'confirmed'",
                $slug
            ), ARRAY_A );

            foreach ( $rows as $row ) {
                $user = get_user_by( 'email', $row['email'] );
                if ( ! $user ) {
                    continue;
                }

                if ( Culture_Gamification::ledger_has_entry( $user->ID, 'literati_connect_attended', $event_id ) ) {
                    continue;
                }

                Culture_Gamification::award_reputation(
                    $user->ID,
                    Culture_Gamification::get_point_value( 'literati_connect_attended' ),
                    'literati_connect_attended',
                    $event_id
                );
                Culture_Gamification::award_credits(
                    $user->ID,
                    Culture_Gamification::get_credit_bonus( 'literati_connect_attended' ),
                    'literati_connect_attended',
                    $event_id
                );
            }
        }
    }

    // ── Helpers ───────────────────────────────────────────────────────────

    /**
     * POST to a Next.js API endpoint using the stored cron secret for auth.
     *
     * @param string $path  API path, e.g. '/api/pulse/refresh'.
     * @param array  $body  Optional JSON body parameters.
     */
    /**
     * @param bool $blocking When true, waits for the actual response and
     *     logs its real status + a body excerpt — both to error_log() and to
     *     the 'culture_cron_last_{basename($path)}' option, so a failure is
     *     checkable from WP Admin (Tools → Site Health → Info → or any
     *     get_option() call) without server log access. When false (the
     *     default, every other caller), stays fire-and-forget exactly as
     *     before — $response is always `true`, nothing to log beyond a
     *     send-side WP_Error.
     */
    private static function call_nextjs( $path, $body = array(), $blocking = false ) {
        $frontend_url = rtrim( Culture_Settings::get( 'culture_frontend_url' ), '/' );
        $cron_secret  = Culture_Settings::get( 'culture_cron_secret' );

        if ( empty( $frontend_url ) || empty( $cron_secret ) ) {
            $msg = $path . ' — Frontend URL or Cron Secret not set in Culture Community → Settings → General.';
            error_log( '[Culture Cron] ' . $msg );
            if ( $blocking ) {
                update_option( 'culture_cron_last_' . trim( basename( $path ), '/' ), array(
                    'at' => current_time( 'mysql' ), 'ok' => false, 'detail' => $msg,
                ) );
            }
            return;
        }

        $url      = $frontend_url . $path;
        $response = wp_remote_post( $url, array(
            'timeout'     => 60, // generous; Vercel Hobby caps at 10s but won't hang WP
            'blocking'    => $blocking,
            'headers'     => array(
                'Content-Type'  => 'application/json',
                'Authorization' => 'Bearer ' . $cron_secret,
            ),
            'body'        => wp_json_encode( $body ),
        ) );

        if ( ! $blocking ) {
            // $response is always true with blocking=false — log if misconfigured.
            if ( is_wp_error( $response ) ) {
                error_log( '[Culture Cron] ' . $path . ' error: ' . $response->get_error_message() );
            } else {
                error_log( '[Culture Cron] Fired ' . $path );
            }
            return;
        }

        if ( is_wp_error( $response ) ) {
            $detail = $response->get_error_message();
            error_log( '[Culture Cron] ' . $path . ' request failed: ' . $detail );
            $result = array( 'at' => current_time( 'mysql' ), 'ok' => false, 'detail' => $detail );
        } else {
            $status = wp_remote_retrieve_response_code( $response );
            $body_excerpt = mb_substr( wp_remote_retrieve_body( $response ), 0, 500 );
            $ok = $status >= 200 && $status < 300;
            error_log( '[Culture Cron] ' . $path . ' responded ' . $status . ': ' . $body_excerpt );
            $result = array( 'at' => current_time( 'mysql' ), 'ok' => $ok, 'status' => $status, 'detail' => $body_excerpt );
        }

        update_option( 'culture_cron_last_' . trim( basename( $path ), '/' ), $result );
    }

    // ── Legacy accessor (used by Culture_Settings UI) ─────────────────────

    public static function get_grace_period_days() {
        return class_exists( 'Culture_Settings' )
            ? (int) Culture_Settings::get( 'culture_grace_period_days' )
            : self::GRACE_PERIOD_DAYS;
    }
}
