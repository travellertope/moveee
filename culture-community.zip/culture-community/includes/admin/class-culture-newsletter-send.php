<?php
/**
 * Newsletter send meta box with Send Test and Send Issue buttons.
 * Registers AJAX handlers for test, send, and status polling.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class Culture_Newsletter_Send {

    /** Every post type that carries newsletter/digest content. */
    const NL_POST_TYPES = array( 'culture_newsletter', 'getmelit', 'culture_drop' );

    public static function init() {
        add_action( 'add_meta_boxes',                array( __CLASS__, 'register_meta_box' ) );
        add_action( 'admin_enqueue_scripts',          array( __CLASS__, 'enqueue_assets' ) );
        add_action( 'save_post_culture_newsletter',   array( __CLASS__, 'save_list_meta' ), 10, 2 );
        add_action( 'save_post_getmelit',             array( __CLASS__, 'save_list_meta' ), 10, 2 );
        add_action( 'save_post_culture_drop',         array( __CLASS__, 'save_list_meta' ), 10, 2 );

        add_action( 'wp_ajax_culture_nl_send_test',  array( __CLASS__, 'ajax_send_test' ) );
        add_action( 'wp_ajax_culture_nl_send_issue', array( __CLASS__, 'ajax_send_issue' ) );
        add_action( 'wp_ajax_culture_nl_get_status', array( __CLASS__, 'ajax_get_status' ) );
        add_action( 'wp_ajax_culture_nl_recount',    array( __CLASS__, 'ajax_recount' ) );

        add_action( 'rest_api_init', array( __CLASS__, 'register_rest_routes' ) );
    }

    /**
     * REST equivalent of the "Send Issue" admin button, for automated/headless
     * publishing (e.g. an Application Password client that creates a
     * culture_newsletter post and then wants to trigger the send without a
     * browser session). The AJAX handlers above can't be used for this — they
     * require check_ajax_referer(), a CSRF nonce tied to a live logged-in
     * browser session, which an Application Password has no way to produce.
     * Application Password auth is exempt from nonce checks under WP core's
     * REST authentication stack, so a plain capability check here is enough.
     */
    public static function register_rest_routes() {
        register_rest_route( 'culture/v1', '/newsletter/send-issue', array(
            'methods'             => 'POST',
            'callback'            => array( __CLASS__, 'rest_send_issue' ),
            'permission_callback' => function ( $request ) {
                $post_id = absint( $request->get_param( 'post_id' ) );
                return $post_id && current_user_can( 'edit_post', $post_id );
            },
            'args'                => array(
                'post_id' => array( 'required' => true, 'type' => 'integer' ),
                'list'    => array( 'required' => false, 'type' => 'string' ),
                'segment' => array( 'required' => false, 'type' => 'string' ),
            ),
        ) );
    }

    /**
     * REST callback for POST /culture/v1/newsletter/send-issue.
     * Same underlying call as ajax_send_issue() — Culture_Newsletter_Queue
     * queues subscribers, WP-Cron dispatches batches of 50 every minute.
     */
    public static function rest_send_issue( WP_REST_Request $request ) {
        $post_id = absint( $request->get_param( 'post_id' ) );

        if ( ! in_array( get_post_type( $post_id ), self::NL_POST_TYPES, true ) ) {
            return new WP_REST_Response( array( 'message' => __( 'Invalid post.', 'culture-community' ) ), 400 );
        }

        // Same as the AJAX handler — let the caller override list/segment at
        // send time without requiring a separate save step first.
        $list = $request->get_param( 'list' );
        if ( null !== $list ) {
            self::persist_list_meta( $post_id, $list, $request->get_param( 'segment' ) ?? '' );
        }

        $count = Culture_Newsletter_Queue::schedule_send( $post_id );

        if ( false === $count ) {
            return new WP_REST_Response( array( 'message' => __( 'No subscribers found.', 'culture-community' ) ), 400 );
        }

        return new WP_REST_Response( array(
            'message' => sprintf(
                /* translators: %s: formatted subscriber count */
                __( 'Queued for %s subscribers. Batches of 50 will go out every minute.', 'culture-community' ),
                number_format( $count )
            ),
            'total'   => $count,
        ), 200 );
    }

    /**
     * Save _culture_nl_list and _culture_nl_segment post meta when the newsletter is saved.
     */
    public static function save_list_meta( $post_id, $post ) {
        if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) return;
        if ( ! current_user_can( 'edit_post', $post_id ) ) return;
        if ( ! isset( $_POST['culture_nl_list_nonce'] ) ) return;
        if ( ! wp_verify_nonce( $_POST['culture_nl_list_nonce'], 'culture_nl_list_' . $post_id ) ) return;

        // getmelit/culture_drop have no editable list dropdown (the post type
        // itself is the list, see resolve_nl_list()) — don't write a
        // _culture_nl_list value that would just be ignored downstream.
        $list = in_array( get_post_type( $post_id ), array( 'getmelit', 'culture_drop' ), true )
            ? null
            : ( $_POST['culture_nl_list'] ?? 'getmelit' );

        self::persist_list_meta( $post_id, $list, $_POST['culture_nl_segment'] ?? array(), (int) ( $_POST['culture_nl_issue_num'] ?? 0 ) );
    }

    /**
     * Validate and persist the target list/segment for a newsletter post.
     * Shared by save_list_meta() (on post save) and the Send Test / Send Issue
     * AJAX handlers (so a send always targets whatever is currently selected
     * in the meta box, even if the post hasn't been saved yet).
     *
     * @param int          $post_id
     * @param string|null  $list     Pass null to leave _culture_nl_list untouched
     *                                (used for getmelit/culture_drop, where the
     *                                post type is the list and there's nothing to save).
     * @param array|string $segment  The posted checkbox groups
     *                                (array( axis_type => array(slugs) )) or a
     *                                legacy bare string — see
     *                                Culture_Newsletter_Lists::normalize_segment_filters().
     */
    private static function persist_list_meta( $post_id, $list, $segment, $issue_num = 0 ) {
        if ( null !== $list ) {
            $list = sanitize_key( $list );
            // Validated against the live registry, not a hardcoded snapshot of
            // its original seed rows — a Hub-auto-provisioned list or anything
            // created later via Lists & Segments would otherwise render fine
            // in the dropdown but silently fail to save. Any content or
            // system list is a valid send target; segment axes aren't lists
            // and aren't picked here.
            $list_row = Culture_Newsletter_Lists::get_by_slug( $list );
            if ( $list_row && in_array( $list_row['type'], array( Culture_Newsletter_Lists::TYPE_CONTENT, Culture_Newsletter_Lists::TYPE_SYSTEM ), true ) ) {
                update_post_meta( $post_id, '_culture_nl_list', $list );
            }
        }

        // Segment filters — normalize_segment_filters() sanitizes every axis
        // and slug against the live registry, so an unknown/stale value from
        // a stale form submission is silently dropped rather than saved.
        $filters = Culture_Newsletter_Lists::normalize_segment_filters( $segment );
        if ( $filters ) {
            update_post_meta( $post_id, '_culture_nl_segment_filters', wp_json_encode( $filters ) );
        } else {
            delete_post_meta( $post_id, '_culture_nl_segment_filters' );
        }

        // Legacy single-string mirror, kept for the frontend edition-scoping
        // GraphQL field (nlSegment on culture_newsletter — see
        // class-culture-post-types.php) which expects a plain region slug or
        // empty string. Only representable when the filter collapses to
        // exactly one axis in one of the shapes that field already
        // understood before multi-axis filters existed; anything else (two+
        // axes, or a Tier/Age-only pick) clears it — those posts simply show
        // as "no segment tag" on the /newsletter/{edition} pages, same as
        // any other post with no _culture_nl_segment set today.
        $legacy = self::legacy_segment_string( $filters );
        if ( $legacy ) {
            update_post_meta( $post_id, '_culture_nl_segment', $legacy );
        } else {
            delete_post_meta( $post_id, '_culture_nl_segment' );
        }

        // Issue number — 0/empty means not set; positive integer means a canonical issue number
        // shared across all regional editions of the same issue.
        $issue_num = absint( $issue_num );
        if ( $issue_num > 0 ) {
            update_post_meta( $post_id, '_culture_nl_issue_num', $issue_num );
        } else {
            delete_post_meta( $post_id, '_culture_nl_issue_num' );
        }
    }

    /**
     * Collapses a normalized multi-axis filter back into the one legacy
     * shape _culture_nl_segment ever held, when possible — see
     * persist_list_meta()'s own comment for why this mirror exists at all.
     *
     * @param array $filters Already-normalized array( axis_type => array(slugs) ).
     * @return string Empty when the filter has no single-string representation.
     */
    private static function legacy_segment_string( array $filters ) {
        if ( 1 !== count( $filters ) ) {
            return '';
        }
        $axis  = array_key_first( $filters );
        $slugs = $filters[ $axis ];

        if ( 'tier' === $axis && array( 'patron' ) === array_values( $slugs ) ) {
            return Culture_Newsletter_Lists::VIRTUAL_PRO_SLUG;
        }
        if ( Culture_Newsletter_Lists::TYPE_REGION === $axis ) {
            if ( 1 === count( $slugs ) ) {
                return $slugs[0];
            }
            $sorted = $slugs;
            sort( $sorted );
            if ( array( 'gh', 'ke', 'ng', 'za' ) === $sorted ) {
                return 'africa';
            }
        }
        return '';
    }

    /**
     * AJAX: recompute the live subscriber count for whatever list/segment
     * combination is currently checked in the meta box — replaces the old
     * client-side lookup table (feasible when "segment" was one flat
     * dropdown; not feasible now that any combination of Region/Age/Tier/a
     * custom axis can be checked at once).
     */
    public static function ajax_recount() {
        check_ajax_referer( 'culture_nl_send_nonce', 'nonce' );

        if ( ! current_user_can( 'edit_posts' ) ) {
            wp_send_json_error();
        }

        $list_row = Culture_Newsletter_Lists::get_by_slug( sanitize_key( $_POST['list'] ?? '' ) );
        if ( ! $list_row ) {
            wp_send_json_success( array( 'count' => 0 ) );
        }

        $filters = Culture_Newsletter_Lists::normalize_segment_filters( is_array( $_POST['segment'] ?? null ) ? wp_unslash( $_POST['segment'] ) : array() );
        $count   = count( Culture_Subscribers_DB::resolve_send_emails( $list_row['id'], $filters ) );

        wp_send_json_success( array(
            'count'   => $count,
            'summary' => Culture_Newsletter_Lists::describe_segment_filters( $filters ),
        ) );
    }

    /**
     * Register meta box on the culture_newsletter edit screen.
     */
    public static function register_meta_box() {
        add_meta_box(
            'culture_nl_send',
            __( 'Send Newsletter', 'culture-community' ),
            array( __CLASS__, 'render_meta_box' ),
            self::NL_POST_TYPES,
            'side',
            'high'
        );
    }

    /**
     * Enqueue CSS + JS only on the newsletter edit screen.
     *
     * @param string $hook
     */
    public static function enqueue_assets( $hook ) {
        if ( ! in_array( $hook, array( 'post.php', 'post-new.php' ), true ) ) {
            return;
        }

        $screen = get_current_screen();
        if ( ! $screen || ! in_array( $screen->post_type, self::NL_POST_TYPES, true ) ) {
            return;
        }

        wp_enqueue_style(
            'culture-nl-send',
            CULTURE_PLUGIN_URL . 'assets/css/culture-newsletter-send.css',
            array(),
            CULTURE_VERSION
        );

        wp_enqueue_script(
            'culture-nl-send',
            CULTURE_PLUGIN_URL . 'assets/js/culture-newsletter-send.js',
            array( 'jquery' ),
            CULTURE_VERSION,
            true
        );

        wp_localize_script( 'culture-nl-send', 'cultureNLSend', array(
            'ajaxUrl' => admin_url( 'admin-ajax.php' ),
            'nonce'   => wp_create_nonce( 'culture_nl_send_nonce' ),
            'postId'  => get_the_ID(),
            'i18n'    => array(
                'confirmSend'   => __( 'Send this issue to all subscribers now? This cannot be undone.', 'culture-community' ),
                'confirmResend' => __( 'Resend to all current subscribers? They may receive a duplicate.', 'culture-community' ),
                'sending'       => __( 'Sending…', 'culture-community' ),
                'sendTest'      => __( 'Send Test', 'culture-community' ),
            ),
        ) );
    }

    /**
     * Render the meta box HTML.
     *
     * @param WP_Post $post
     */
    public static function render_meta_box( $post ) {
        $status_data  = Culture_Newsletter_Queue::get_send_status( $post->ID );
        $status       = $status_data['status'];
        $total        = $status_data['total'];
        $offset       = $status_data['offset'];
        $percent      = $status_data['percent'];
        $sent_at      = $status_data['sent_at'];
        $current_user = wp_get_current_user();

        $nl_list         = Culture_Newsletter_Queue::resolve_nl_list( $post->ID, 'getmelit' );
        $segment_filters = Culture_Newsletter_Lists::get_segment_filters_for_post( $post->ID );
        $nl_issue_num    = (int) ( get_post_meta( $post->ID, '_culture_nl_issue_num', true ) ?: 0 );
        $list_locked     = in_array( get_post_type( $post->ID ), array( 'getmelit', 'culture_drop' ), true );

        // Lists (content + system) are sourced from the real list registry —
        // a Hub list or a custom list an admin creates shows up here
        // immediately, with no code change (September 2026; see
        // Culture_Newsletter_Lists). Segments are now a full multi-axis
        // filter (Region/Age/Tier/any custom axis, see get_axes()) rendered
        // further down, not a single flat dropdown.
        $lists_config = array();
        foreach ( array_merge(
            Culture_Newsletter_Lists::get_all( Culture_Newsletter_Lists::TYPE_CONTENT ),
            Culture_Newsletter_Lists::get_all( Culture_Newsletter_Lists::TYPE_SYSTEM )
        ) as $l ) {
            $lists_config[ $l['slug'] ] = $l['name'];
        }

        $nl_list_row = Culture_Newsletter_Lists::get_by_slug( $nl_list );
        $sub_count   = $nl_list_row ? count( Culture_Subscribers_DB::resolve_send_emails( $nl_list_row['id'], $segment_filters ) ) : 0;
        ?>
        <div class="culture-nl-box"
            data-post-id="<?php echo esc_attr( $post->ID ); ?>"
            data-list-labels="<?php echo esc_attr( wp_json_encode( $lists_config ) ); ?>"
        >

            <?php /* ── LIST ASSIGNMENT ── */ ?>
            <div class="culture-nl-section" style="margin-bottom:0;">
                <label class="culture-nl-label"><?php esc_html_e( 'Newsletter List', 'culture-community' ); ?></label>
                <?php wp_nonce_field( 'culture_nl_list_' . $post->ID, 'culture_nl_list_nonce' ); ?>
                <?php if ( $list_locked ) : ?>
                    <input type="hidden" name="culture_nl_list" class="js-nl-list-select" value="<?php echo esc_attr( $nl_list ); ?>">
                    <p style="margin:4px 0 0;font-weight:600;">
                        <?php echo esc_html( $lists_config[ $nl_list ] ?? $nl_list ); ?>
                    </p>
                    <p style="font-size:11px;color:#666;margin:2px 0 0;">
                        <?php esc_html_e( 'Fixed by post type — this post is a GetMeLit or Culture Drop issue.', 'culture-community' ); ?>
                    </p>
                <?php else : ?>
                    <select name="culture_nl_list" class="js-nl-list-select" style="width:100%;margin-top:4px;">
                        <?php foreach ( $lists_config as $lk => $ln ) : ?>
                            <option value="<?php echo esc_attr( $lk ); ?>"<?php selected( $nl_list, $lk ); ?>>
                                <?php echo esc_html( $ln ); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                <?php endif; ?>
            </div>

            <?php /* ── SEGMENT FILTERS ── */ ?>
            <div class="culture-nl-section js-nl-segment-filters" style="margin-top:12px;margin-bottom:0;">
                <label class="culture-nl-label"><?php esc_html_e( 'Segment Filters', 'culture-community' ); ?></label>
                <p style="font-size:11px;color:#666;margin:2px 0 8px;">
                    <?php esc_html_e( 'Optional — narrow this list to a demographic slice. A List is who subscribed (Culture Drop, GetMeLit…); a Segment is who they are (Region, Age, Tier…).', 'culture-community' ); ?>
                </p>
                <?php Culture_Newsletter_Lists::render_segment_filter_fields( 'culture_nl_segment', $segment_filters ); ?>
            </div>

            <?php
            // ── MULTI-EDITION APPENDIX SUMMARY ──
            // Purely informational — the fields themselves live in the
            // "Edition Appendix" box in the main content column (ACF), not
            // here. See Culture_Newsletter_Queue::EDITIONS/filled_editions().
            $filled_editions = Culture_Newsletter_Queue::filled_editions( $post->ID );
            if ( $filled_editions ) :
            ?>
            <div class="culture-nl-section" style="margin-top:12px;margin-bottom:0;">
                <label class="culture-nl-label"><?php esc_html_e( 'Multi-Edition Appendix', 'culture-community' ); ?></label>
                <?php if ( $segment_filters ) : ?>
                    <p style="font-size:11px;color:#b32d2e;margin:4px 0 0;">
                        <?php esc_html_e( 'A segment filter is checked above, so this will send as one uniform email and the per-edition appendix fields below will be ignored. Uncheck every box above to send each edition its own appendix instead.', 'culture-community' ); ?>
                    </p>
                <?php else : ?>
                    <p style="font-size:11px;color:#2271b1;margin:4px 0 0;">
                        <?php
                        $ed_names = array();
                        foreach ( $filled_editions as $ed ) {
                            $ed_count   = $nl_list_row ? count( Culture_Subscribers_DB::resolve_send_emails( $nl_list_row['id'], $ed ) ) : 0;
                            $ed_names[] = Culture_Newsletter_Queue::EDITIONS[ $ed ] . ' (' . number_format( $ed_count ) . ')';
                        }
                        printf(
                            /* translators: %s: comma-separated list of "Edition (count)" */
                            esc_html__( 'This post has appendix content for: %s. Each region gets the shared body above plus its own appendix. Anyone on this list not in one of those regions will receive the Africa edition.', 'culture-community' ),
                            esc_html( implode( ', ', $ed_names ) )
                        );
                        ?>
                    </p>
                <?php endif; ?>
            </div>
            <?php endif; ?>

            <?php /* ── ISSUE NUMBER ── */ ?>
            <div class="culture-nl-section" style="margin-top:12px;margin-bottom:0;">
                <label class="culture-nl-label"><?php esc_html_e( 'Issue Number', 'culture-community' ); ?></label>
                <input
                    type="number"
                    name="culture_nl_issue_num"
                    value="<?php echo esc_attr( $nl_issue_num ?: '' ); ?>"
                    min="1"
                    step="1"
                    style="width:100%;margin-top:4px;"
                    placeholder="e.g. 12"
                />
                <p style="font-size:11px;color:#666;margin:4px 0 0;">
                    <?php esc_html_e( 'Only needed if you\'re still using separate posts per region (one post per segment, same issue number on each). If you\'re using the Edition Appendix fields below to send every region from this one post, you can leave this blank.', 'culture-community' ); ?>
                </p>
            </div>

            <hr class="culture-nl-sep">

            <div class="culture-nl-sub-count">
                <span class="culture-nl-stat-num js-nl-count-num"><?php echo esc_html( number_format( $sub_count ) ); ?></span>
                <span class="culture-nl-stat-label js-nl-count-label">
                    <?php
                    $label       = $lists_config[ $nl_list ] ?? '';
                    $seg_summary = Culture_Newsletter_Lists::describe_segment_filters( $segment_filters );
                    if ( $seg_summary ) {
                        $label .= ' · ' . $seg_summary;
                    }
                    echo esc_html( sprintf( __( '%s Subscribers', 'culture-community' ), $label ) );
                    ?>
                </span>
            </div>

            <hr class="culture-nl-sep">

            <?php /* ── SEND STATUS ── */ ?>
            <div class="culture-nl-status-wrap js-nl-status" data-status="<?php echo esc_attr( $status ); ?>">
                <?php if ( 'sent' === $status ) : ?>
                    <div class="culture-nl-badge sent">
                        <span class="dashicons dashicons-yes-alt"></span>
                        <?php esc_html_e( 'Issue sent', 'culture-community' ); ?>
                    </div>
                    <p class="culture-nl-sent-detail">
                        <?php
                        printf(
                            /* translators: 1: subscriber count, 2: date/time */
                            esc_html__( '%1$s subscribers · %2$s', 'culture-community' ),
                            number_format( $total ),
                            date_i18n( get_option( 'date_format' ) . ' ' . get_option( 'time_format' ), strtotime( $sent_at ) )
                        );
                        ?>
                    </p>
                    <?php
                    // Quick analytics snapshot.
                    $quick = Culture_NL_Analytics::get_campaign_stats( $post->ID );
                    if ( $quick['unique_opens'] > 0 || $quick['unique_clicks'] > 0 ) :
                        $analytics_url = admin_url( 'admin.php?page=culture-nl-analytics&campaign=' . $post->ID );
                    ?>
                    <div class="culture-nl-quick-analytics">
                        <span class="culture-nl-qa-chip" title="<?php esc_attr_e( 'Open rate', 'culture-community' ); ?>">
                            <span class="dashicons dashicons-visibility"></span>
                            <?php echo esc_html( $quick['open_rate'] ); ?>%
                        </span>
                        <span class="culture-nl-qa-chip" title="<?php esc_attr_e( 'Click-through rate', 'culture-community' ); ?>">
                            <span class="dashicons dashicons-admin-links"></span>
                            <?php echo esc_html( $quick['ctr'] ); ?>%
                        </span>
                        <a href="<?php echo esc_url( $analytics_url ); ?>" class="culture-nl-qa-link">
                            <?php esc_html_e( 'Full analytics →', 'culture-community' ); ?>
                        </a>
                    </div>
                    <?php endif; ?>
                <?php elseif ( 'sending' === $status ) : ?>
                    <div class="culture-nl-badge sending">
                        <span class="dashicons dashicons-update-alt"></span>
                        <?php esc_html_e( 'Sending…', 'culture-community' ); ?>
                    </div>
                    <div class="culture-nl-progress">
                        <div class="culture-nl-progress-bar">
                            <div class="culture-nl-progress-fill js-nl-fill" style="width:<?php echo esc_attr( $percent ); ?>%"></div>
                        </div>
                        <span class="culture-nl-progress-text js-nl-progress-text">
                            <?php echo esc_html( number_format( $offset ) ); ?> / <?php echo esc_html( number_format( $total ) ); ?>
                        </span>
                    </div>
                <?php else : ?>
                    <div class="culture-nl-badge idle">
                        <?php esc_html_e( 'Not yet sent', 'culture-community' ); ?>
                    </div>
                <?php endif; ?>
            </div>

            <?php if ( 'sending' !== $status ) : ?>

                <hr class="culture-nl-sep">

                <?php /* ── SEND TEST ── */ ?>
                <div class="culture-nl-section">
                    <label class="culture-nl-label" for="culture-nl-test-email">
                        <?php esc_html_e( 'Send Test Email', 'culture-community' ); ?>
                    </label>
                    <input
                        type="email"
                        id="culture-nl-test-email"
                        class="widefat"
                        value="<?php echo esc_attr( $current_user->user_email ); ?>"
                        placeholder="test@example.com"
                    >
                    <?php if ( $filled_editions && ! $segment_filters ) : ?>
                        <select id="culture-nl-test-edition" style="width:100%;margin-top:6px;">
                            <option value=""><?php esc_html_e( 'Shared body only (no appendix)', 'culture-community' ); ?></option>
                            <?php foreach ( $filled_editions as $ed ) : ?>
                                <option value="<?php echo esc_attr( $ed ); ?>">
                                    <?php echo esc_html( sprintf( __( 'Preview: %s edition', 'culture-community' ), Culture_Newsletter_Queue::EDITIONS[ $ed ] ) ); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    <?php endif; ?>
                    <button type="button" class="button button-secondary js-nl-test-btn" style="margin-top:6px;width:100%;">
                        <span class="dashicons dashicons-email" style="margin-top:3px;"></span>
                        <?php esc_html_e( 'Send Test', 'culture-community' ); ?>
                    </button>
                </div>

                <hr class="culture-nl-sep">

                <?php /* ── SEND TO ALL ── */ ?>
                <div class="culture-nl-section">
                    <label class="culture-nl-label">
                        <?php esc_html_e( 'Send to All Subscribers', 'culture-community' ); ?>
                    </label>

                    <p class="culture-nl-notice js-nl-notice-empty" style="<?php echo 0 === $sub_count ? '' : 'display:none;'; ?>">
                        <?php esc_html_e( 'No subscribers on this list yet.', 'culture-community' ); ?>
                    </p>
                    <p class="culture-nl-notice js-nl-notice-full" style="<?php echo 0 === $sub_count ? 'display:none;' : ''; ?>">
                        <?php
                        printf(
                            /* translators: 1: formatted subscriber count, 2: list name */
                            esc_html__( 'Will email %1$s %2$s subscribers in batches of 50 per minute via your connected SMTP.', 'culture-community' ),
                            '<strong class="js-nl-notice-count">' . number_format( $sub_count ) . '</strong>',
                            '<span class="js-nl-notice-list">' . esc_html( $lists_config[ $nl_list ] ?? '' ) . '</span>'
                        );
                        ?>
                    </p>
                    <?php if ( 'sent' === $status ) : ?>
                        <button type="button" class="button button-secondary js-nl-send-btn" style="width:100%;" <?php disabled( 0 === $sub_count ); ?>>
                            <span class="dashicons dashicons-controls-repeat" style="margin-top:3px;"></span>
                            <?php esc_html_e( 'Resend to All Subscribers', 'culture-community' ); ?>
                        </button>
                    <?php else : ?>
                        <button type="button" class="button button-primary js-nl-send-btn" style="width:100%;height:36px;line-height:34px;" <?php disabled( 0 === $sub_count ); ?>>
                            <span class="dashicons dashicons-megaphone" style="margin-top:7px;"></span>
                            <?php esc_html_e( 'Send Issue', 'culture-community' ); ?>
                        </button>
                    <?php endif; ?>
                </div>

            <?php endif; ?>

            <div class="culture-nl-feedback js-nl-feedback" style="display:none;"></div>

        </div>
        <?php
    }

    /**
     * AJAX: Send a test email.
     */
    public static function ajax_send_test() {
        check_ajax_referer( 'culture_nl_send_nonce', 'nonce' );

        if ( ! current_user_can( 'edit_posts' ) ) {
            wp_send_json_error( array( 'message' => __( 'Permission denied.', 'culture-community' ) ) );
        }

        $post_id    = absint( $_POST['post_id'] ?? 0 );
        $test_email = sanitize_email( $_POST['test_email'] ?? '' );

        if ( ! $post_id ) {
            wp_send_json_error( array( 'message' => __( 'Invalid post.', 'culture-community' ) ) );
        }

        if ( ! is_email( $test_email ) ) {
            wp_send_json_error( array( 'message' => __( 'Please enter a valid email address.', 'culture-community' ) ) );
        }

        // The dropdowns may not have been saved to post meta yet (no "Update" click) —
        // persist whatever is currently selected so the test reflects the visible UI.
        if ( isset( $_POST['list'] ) ) {
            self::persist_list_meta( $post_id, $_POST['list'], $_POST['segment'] ?? '' );
        }

        $edition = sanitize_key( $_POST['edition'] ?? '' );
        if ( ! isset( Culture_Newsletter_Queue::EDITIONS[ $edition ] ) ) {
            $edition = '';
        }

        $sent = Culture_Newsletter_Queue::send_test( $post_id, $test_email, $edition );

        if ( $sent ) {
            wp_send_json_success( array(
                /* translators: %s: email address */
                'message' => sprintf( __( 'Test sent to %s — check your inbox.', 'culture-community' ), $test_email ),
            ) );
        } else {
            wp_send_json_error( array( 'message' => __( 'Send failed. Please check your SMTP settings.', 'culture-community' ) ) );
        }
    }

    /**
     * AJAX: Queue the full send.
     */
    public static function ajax_send_issue() {
        check_ajax_referer( 'culture_nl_send_nonce', 'nonce' );

        if ( ! current_user_can( 'edit_posts' ) ) {
            wp_send_json_error( array( 'message' => __( 'Permission denied.', 'culture-community' ) ) );
        }

        $post_id = absint( $_POST['post_id'] ?? 0 );

        if ( ! $post_id ) {
            wp_send_json_error( array( 'message' => __( 'Invalid post.', 'culture-community' ) ) );
        }

        // Same as the test-send handler — make sure the actual send targets
        // whatever list/segment is currently selected, not stale saved meta.
        if ( isset( $_POST['list'] ) ) {
            self::persist_list_meta( $post_id, $_POST['list'], $_POST['segment'] ?? '' );
        }

        $count = Culture_Newsletter_Queue::schedule_send( $post_id );

        if ( false === $count ) {
            wp_send_json_error( array( 'message' => __( 'No subscribers found.', 'culture-community' ) ) );
        }

        wp_send_json_success( array(
            'message' => sprintf(
                /* translators: %s: formatted subscriber count */
                __( 'Queued for %s subscribers. Batches of 50 will go out every minute.', 'culture-community' ),
                number_format( $count )
            ),
            'total' => $count,
        ) );
    }

    /**
     * AJAX: Return current send status for progress polling.
     */
    public static function ajax_get_status() {
        check_ajax_referer( 'culture_nl_send_nonce', 'nonce' );

        if ( ! current_user_can( 'edit_posts' ) ) {
            wp_send_json_error();
        }

        $post_id = absint( $_POST['post_id'] ?? 0 );

        if ( ! $post_id ) {
            wp_send_json_error();
        }

        wp_send_json_success( Culture_Newsletter_Queue::get_send_status( $post_id ) );
    }
}
