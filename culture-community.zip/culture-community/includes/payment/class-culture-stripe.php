<?php
/**
 * Stripe integration for international subscriptions.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class Culture_Stripe {

    const API_BASE = 'https://api.stripe.com/v1';

    /**
     * Get the Stripe secret key from settings.
     */
    private static function get_secret_key() {
        return get_option( 'culture_stripe_secret_key', '' );
    }

    /* ── Subscription amounts (USD, major units) ─────────────────────── */

    private static $amount_defaults = array(
        'patron' => array( 'monthly' => 4,  'yearly' => 40  ),
        'lit'    => array( 'monthly' => 1,  'yearly' => 13  ),
    );

    private static function get_amount_usd( string $cycle, string $tier ): float {
        $suffix   = ( 'patron' === $tier ) ? '' : '_' . strtolower( $tier );
        $key      = 'culture_stripe_amount_' . strtolower( $cycle ) . '_usd' . $suffix;
        $fallback = self::$amount_defaults[ $tier ][ $cycle ] ?? 4;
        return (float) get_option( $key, $fallback );
    }

    /* ── Price provisioning ───────────────────────────────────────────── */

    /**
     * Return a cached Stripe Price ID, creating the Product + Price if needed.
     * The stored value can be a manually entered `price_*` ID (old behaviour) or
     * empty (auto-provision on first use).
     *
     * @return string|WP_Error
     */
    private static function get_or_create_price_id( string $cycle, string $tier ): string|\WP_Error {
        $suffix  = ( 'patron' === $tier ) ? '' : '_' . strtolower( $tier );
        $opt_key = 'culture_stripe_price_' . strtolower( $cycle ) . '_usd' . $suffix;

        $cached = (string) get_option( $opt_key, '' );
        if ( str_starts_with( $cached, 'price_' ) ) {
            return $cached;
        }

        // Auto-create via Stripe API.
        $tier_label = ( 'patron' === $tier ) ? 'Moveee Pro' : 'Moveee Lit';
        $interval   = ( 'yearly' === $cycle ) ? 'year' : 'month';
        $name       = $tier_label . ' ' . ucfirst( $cycle ) . ' USD';
        $amount_usd = self::get_amount_usd( $cycle, $tier );

        $result = self::api_request( 'POST', '/prices', array(
            'currency'                => 'usd',
            'unit_amount'             => (int) round( $amount_usd * 100 ),
            'recurring'               => array( 'interval' => $interval ),
            'product_data'            => array( 'name' => $name ),
        ) );

        if ( is_wp_error( $result ) ) {
            return $result;
        }

        $price_id = $result['id'] ?? '';
        if ( str_starts_with( $price_id, 'price_' ) ) {
            update_option( $opt_key, $price_id, false );
        }

        return $price_id ?: new WP_Error( 'stripe_no_price', 'Stripe did not return a price ID.' );
    }

    /**
     * Generate checkout URL for upgrading to a paid tier ('patron' or 'lit') via Stripe.
     *
     * @param int    $user_id
     * @param string $plan_key e.g. 'monthly_usd'
     * @param string $tier 'patron' or 'lit'.
     * @param string $return_path Optional path (e.g. '/lit-welcome') on the
     *                            frontend to land on after checkout, instead
     *                            of the site root — see
     *                            Culture_Paystack::build_return_url().
     * @return string|WP_Error
     */
    public static function get_checkout_url( $user_id, $plan_key = 'monthly_usd', $tier = 'patron', $return_path = '' ) {
        $tier     = in_array( $tier, array( 'patron', 'lit' ), true ) ? $tier : 'patron';
        $cycle    = strpos( $plan_key, 'yearly' ) !== false ? 'yearly' : 'monthly';
        $price_id = self::get_or_create_price_id( $cycle, $tier );

        if ( is_wp_error( $price_id ) ) {
            return $price_id;
        }

        if ( empty( $price_id ) ) {
            return new WP_Error( 'missing_price_id', __( 'Stripe Price ID not configured.', 'culture-community' ) );
        }

        $user = get_userdata( $user_id );
        $frontend_url = get_option( 'culture_frontend_url', home_url( '/' ) );
        $return_base  = Culture_Paystack::build_return_url( $frontend_url, $return_path );

        $response = self::api_request( 'POST', '/checkout/sessions', array(
            'mode'                => 'subscription',
            'client_reference_id' => (string) $user_id,
            'success_url'         => add_query_arg( 'culture_upgraded', '1', $return_base ),
            'cancel_url'          => add_query_arg( 'culture_upgraded', '0', $return_base ),
            'line_items'          => array(
                array(
                    'price'    => $price_id,
                    'quantity' => 1,
                ),
            ),
            'metadata' => array(
                'user_id' => $user_id,
                'tier'    => $tier,
            ),
        ) );

        if ( is_wp_error( $response ) ) {
            return $response;
        }

        return $response['url'] ?? '';
    }

    /**
     * Handle Stripe webhook events.
     * Called by the REST API route.
     *
     * @param WP_REST_Request $request
     * @return WP_REST_Response|WP_Error
     */
    public static function handle_webhook( $request ) {
        $payload = $request->get_body();
        $data    = json_decode( $payload, true );

        if ( ! $data || ! isset( $data['type'] ) ) {
            return new WP_Error( 'invalid_payload', 'Invalid payload.', array( 'status' => 400 ) );
        }

        // Note: For production, we should ideally verify the webhook signature here.
        // However, without the Stripe SDK, verifying 'Stripe-Signature' manually requires
        // a complex implementation of HMAC SHA256 that matches Stripe's specific scheme.

        $event_type = $data['type'];
        $object     = $data['data']['object'] ?? array();

        switch ( $event_type ) {
            case 'checkout.session.completed':
                $user_id = (int) ( $object['client_reference_id'] ?? 0 );
                if ( $user_id ) {
                    self::upgrade_user( $user_id, $object );
                }
                break;

            case 'customer.subscription.deleted':
                $user_id = self::get_user_by_stripe_customer( $object['customer'] ?? '' );
                if ( $user_id ) {
                    update_user_meta( $user_id, '_culture_membership_tier', 'citizen' );
                    update_user_meta( $user_id, '_culture_subscription_status', 'cancelled' );
                }
                break;
        }

        return rest_ensure_response( array( 'status' => 'ok' ) );
    }

    /**
     * Upgrade user to the paid tier they checked out for ('patron' or 'lit').
     *
     * @param int   $user_id
     * @param array $session Stripe Session object.
     */
    private static function upgrade_user( $user_id, $session ) {
        $tier = $session['metadata']['tier'] ?? 'patron';
        $tier = in_array( $tier, array( 'patron', 'lit' ), true ) ? $tier : 'patron';

        update_user_meta( $user_id, '_culture_membership_tier', $tier );
        update_user_meta( $user_id, '_culture_stripe_customer_id', $session['customer'] ?? '' );
        update_user_meta( $user_id, '_culture_stripe_subscription_id', $session['subscription'] ?? '' );
        update_user_meta( $user_id, '_culture_subscription_status', 'active' );

        do_action( 'culture_payment_completed', $user_id, array(
            'gateway'  => 'stripe',
            'amount'   => $session['amount_total'] ?? 0,
            'currency' => strtoupper( $session['currency'] ?? 'USD' ),
            'reference' => $session['id'] ?? '',
        ) );
    }

    /**
     * Find user by Stripe customer ID.
     */
    private static function get_user_by_stripe_customer( $customer_id ) {
        if ( ! $customer_id ) return false;

        $users = get_users( array(
            'meta_key'   => '_culture_stripe_customer_id',
            'meta_value' => $customer_id,
            'number'     => 1,
            'fields'     => 'ID',
        ) );

        return ! empty( $users ) ? (int) $users[0] : false;
    }

    /**
     * Make an API request to Stripe.
     */
    /**
     * Create a one-time payment Checkout Session (used by ticket system).
     */
    public static function payment_session( array $params ): array|\WP_Error {
        return self::api_request( 'POST', '/checkout/sessions', $params );
    }

    private static function api_request( $method, $endpoint, $body = array() ) {
        $secret = self::get_secret_key();
        if ( empty( $secret ) ) {
            return new WP_Error( 'missing_api_key', 'Stripe Secret Key is not configured.' );
        }

        $args = array(
            'method'  => $method,
            'headers' => array(
                'Authorization' => 'Basic ' . base64_encode( $secret . ':' ),
                'Content-Type'  => 'application/x-www-form-urlencoded',
            ),
            'timeout' => 30,
        );

        if ( ! empty( $body ) ) {
            // Stripe API for v1 endpoints expects application/x-www-form-urlencoded with nested brackets.
            // http_build_query handles this correctly for Stripe's style.
            $args['body'] = http_build_query( $body );
        }

        $url      = self::API_BASE . $endpoint;
        $response = wp_remote_request( $url, $args );

        if ( is_wp_error( $response ) ) {
            return $response;
        }

        $code = wp_remote_retrieve_response_code( $response );
        $body = json_decode( wp_remote_retrieve_body( $response ), true );

        if ( $code >= 400 ) {
            return new WP_Error(
                'stripe_error',
                $body['error']['message'] ?? 'Stripe API error.',
                array( 'status' => $code )
            );
        }

        return $body;
    }
}
