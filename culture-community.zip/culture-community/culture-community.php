<?php
/**
 * Plugin Name: Culture Community
 * Plugin URI:  https://themoveee.com
 * Description: Core plugin for Moveee Connect — membership tiers, community feed, newsletters, events, gamification, and mobile API.
 * Version:     3.8.2
 * Author:      Moveee
 * License:     GPL-2.0+
 * Text Domain: culture-community
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

define( 'CULTURE_VERSION', '3.8.2' );
define( 'CULTURE_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
define( 'CULTURE_PLUGIN_URL', plugin_dir_url( __FILE__ ) );
define( 'CULTURE_PLUGIN_FILE', __FILE__ );

// Composer autoload.
$culture_autoload = CULTURE_PLUGIN_DIR . 'vendor/autoload.php';
if ( file_exists( $culture_autoload ) ) {
    require_once $culture_autoload;
}

// Core includes.
require_once CULTURE_PLUGIN_DIR . 'includes/core/class-culture-activator.php';
require_once CULTURE_PLUGIN_DIR . 'includes/core/class-culture-post-types.php';
require_once CULTURE_PLUGIN_DIR . 'includes/core/class-culture-gamification.php';
require_once CULTURE_PLUGIN_DIR . 'includes/core/class-culture-referrals.php';
require_once CULTURE_PLUGIN_DIR . 'includes/core/class-culture-cron.php';
require_once CULTURE_PLUGIN_DIR . 'includes/core/class-culture-emails.php';
require_once CULTURE_PLUGIN_DIR . 'includes/core/class-culture-newsletter-lists.php';
require_once CULTURE_PLUGIN_DIR . 'includes/core/class-culture-subscribers-db.php';
require_once CULTURE_PLUGIN_DIR . 'includes/core/class-culture-newsletter-queue.php';
require_once CULTURE_PLUGIN_DIR . 'includes/core/class-culture-campaigns.php';
require_once CULTURE_PLUGIN_DIR . 'includes/core/class-culture-nl-analytics.php';
require_once CULTURE_PLUGIN_DIR . 'includes/core/class-culture-directory.php';
require_once CULTURE_PLUGIN_DIR . 'includes/core/class-culture-perks.php';
require_once CULTURE_PLUGIN_DIR . 'includes/core/class-culture-webauthn.php';
require_once CULTURE_PLUGIN_DIR . 'includes/core/class-culture-push.php';
require_once CULTURE_PLUGIN_DIR . 'includes/core/class-culture-notifications.php';
require_once CULTURE_PLUGIN_DIR . 'includes/core/class-culture-follows.php';
require_once CULTURE_PLUGIN_DIR . 'includes/core/class-culture-directory-follows.php';
require_once CULTURE_PLUGIN_DIR . 'includes/core/class-culture-community-rsvp.php';
require_once CULTURE_PLUGIN_DIR . 'includes/core/class-culture-reading-tracker.php';
require_once CULTURE_PLUGIN_DIR . 'includes/core/class-culture-geolocation.php';
require_once CULTURE_PLUGIN_DIR . 'includes/core/class-culture-vendor-shipping.php';
require_once CULTURE_PLUGIN_DIR . 'includes/core/class-culture-clusters.php';
require_once CULTURE_PLUGIN_DIR . 'includes/core/class-culture-hubs.php';
require_once CULTURE_PLUGIN_DIR . 'includes/core/class-culture-cli.php';
require_once CULTURE_PLUGIN_DIR . 'includes/core/class-culture-pulse.php';
require_once CULTURE_PLUGIN_DIR . 'includes/core/class-culture-community.php';
require_once CULTURE_PLUGIN_DIR . 'includes/core/class-culture-google-auth.php';
require_once CULTURE_PLUGIN_DIR . 'includes/core/class-culture-apple-auth.php';
require_once CULTURE_PLUGIN_DIR . 'includes/core/class-culture-account-deletion.php';
require_once CULTURE_PLUGIN_DIR . 'includes/core/class-culture-google-play-billing.php';
require_once CULTURE_PLUGIN_DIR . 'includes/core/class-culture-r2.php';
require_once CULTURE_PLUGIN_DIR . 'includes/core/class-culture-country-cleanup.php';
require_once CULTURE_PLUGIN_DIR . 'includes/core/class-culture-reloadly.php';
require_once CULTURE_PLUGIN_DIR . 'includes/core/class-culture-flutterwave.php';
require_once CULTURE_PLUGIN_DIR . 'includes/core/class-culture-system-author.php';
require_once CULTURE_PLUGIN_DIR . 'includes/core/class-culture-guest-byline.php';
require_once CULTURE_PLUGIN_DIR . 'includes/core/class-culture-preview.php';
require_once CULTURE_PLUGIN_DIR . 'includes/core/class-culture-literary-access.php';
require_once CULTURE_PLUGIN_DIR . 'includes/core/class-culture-magic-otp.php';

// API includes.
require_once CULTURE_PLUGIN_DIR . 'includes/api/class-culture-rest-api.php';
require_once CULTURE_PLUGIN_DIR . 'includes/api/class-culture-mobile-api.php';
require_once CULTURE_PLUGIN_DIR . 'includes/api/class-culture-ajax.php';

// Frontend includes.
require_once CULTURE_PLUGIN_DIR . 'includes/frontend/class-culture-shortcodes.php';
require_once CULTURE_PLUGIN_DIR . 'includes/frontend/class-culture-registration.php';
require_once CULTURE_PLUGIN_DIR . 'includes/frontend/class-culture-templates.php';

// Admin includes.
require_once CULTURE_PLUGIN_DIR . 'includes/admin/class-culture-settings.php';
require_once CULTURE_PLUGIN_DIR . 'includes/admin/class-culture-analytics.php';
require_once CULTURE_PLUGIN_DIR . 'includes/admin/class-culture-email-templates.php';
require_once CULTURE_PLUGIN_DIR . 'includes/admin/class-culture-newsletter-send.php';
require_once CULTURE_PLUGIN_DIR . 'includes/admin/class-culture-subscribers.php';
require_once CULTURE_PLUGIN_DIR . 'includes/admin/class-culture-newsletter-lists-admin.php';
require_once CULTURE_PLUGIN_DIR . 'includes/admin/class-culture-campaigns-admin.php';
require_once CULTURE_PLUGIN_DIR . 'includes/admin/class-culture-campaign-send.php';
require_once CULTURE_PLUGIN_DIR . 'includes/admin/class-culture-games-subscribers.php';
require_once CULTURE_PLUGIN_DIR . 'includes/admin/class-culture-newsletter-importer.php';
require_once CULTURE_PLUGIN_DIR . 'includes/admin/class-culture-nl-analytics-admin.php';
require_once CULTURE_PLUGIN_DIR . 'includes/admin/class-culture-directory-tools.php';
require_once CULTURE_PLUGIN_DIR . 'includes/admin/class-culture-acf-fields.php';
require_once CULTURE_PLUGIN_DIR . 'includes/admin/class-culture-redirects.php';
require_once CULTURE_PLUGIN_DIR . 'includes/admin/class-culture-rsvp-admin.php';
require_once CULTURE_PLUGIN_DIR . 'includes/admin/class-culture-clusters-admin.php';
require_once CULTURE_PLUGIN_DIR . 'includes/admin/class-culture-hubs-admin.php';
require_once CULTURE_PLUGIN_DIR . 'includes/admin/class-culture-content-admin.php';
require_once CULTURE_PLUGIN_DIR . 'includes/admin/class-culture-perks-admin.php';
require_once CULTURE_PLUGIN_DIR . 'includes/api/class-culture-event-rsvp.php';

// Payment includes.
require_once CULTURE_PLUGIN_DIR . 'includes/payment/class-culture-paystack.php';
require_once CULTURE_PLUGIN_DIR . 'includes/payment/class-culture-flutterwave-subscriptions.php';
require_once CULTURE_PLUGIN_DIR . 'includes/payment/class-culture-stripe.php';
require_once CULTURE_PLUGIN_DIR . 'includes/payment/class-culture-ticket-payment.php';
require_once CULTURE_PLUGIN_DIR . 'includes/payment/class-culture-creator-earnings.php';
require_once CULTURE_PLUGIN_DIR . 'includes/payment/class-culture-community-rsvp-payment.php';
require_once CULTURE_PLUGIN_DIR . 'includes/payment/class-culture-shop-checkout.php';
require_once CULTURE_PLUGIN_DIR . 'includes/payment/class-culture-services-payment.php';
require_once CULTURE_PLUGIN_DIR . 'includes/admin/class-culture-tickets-admin.php';
require_once CULTURE_PLUGIN_DIR . 'includes/admin/class-culture-payouts-admin.php';
require_once CULTURE_PLUGIN_DIR . 'includes/admin/class-culture-memberships.php';
require_once CULTURE_PLUGIN_DIR . 'includes/admin/class-culture-literary-submissions.php';

/**
 * Plugin activation hook.
 */
function culture_community_activate() {
    Culture_Activator::activate();
}
register_activation_hook( __FILE__, 'culture_community_activate' );

/**
 * Auto-create/upgrade custom DB tables when the plugin version changes.
 *
 * This plugin is deployed via direct file sync rather than the WP plugin
 * repo, so register_activation_hook() above only fires on a manual
 * deactivate/reactivate in WP Admin — a code deploy alone does not run it.
 * Without this check, any dbDelta table added after a site's initial
 * activation (e.g. wp_culture_follows) silently never gets created in
 * production, and writes/reads against it fail with no visible error.
 */
function culture_community_maybe_upgrade() {
    if ( get_option( 'culture_db_version' ) !== CULTURE_VERSION ) {
        Culture_Activator::create_tables();
        update_option( 'culture_db_version', CULTURE_VERSION );
    }
}
add_action( 'plugins_loaded', 'culture_community_maybe_upgrade' );

/**
 * Plugin deactivation hook.
 */
function culture_community_deactivate() {
    Culture_Activator::deactivate();
}
register_deactivation_hook( __FILE__, 'culture_community_deactivate' );

/**
 * Initialize plugin components.
 */
function culture_community_init() {
    Culture_Post_Types::init();
    Culture_Gamification::init();
    Culture_REST_API::init();
    Culture_Mobile_API::init();
    Culture_Ajax::init();
    Culture_Shortcodes::init();
    Culture_Paystack::init();
    Culture_Flutterwave_Subscriptions::init();
    Culture_Referrals::init();
    Culture_Cron::init();
    Culture_Registration::init();
    Culture_Emails::init();
    Culture_Newsletter_Lists::init();
    Culture_Subscribers_DB::init();
    Culture_Newsletter_Queue::init();
    Culture_Campaigns::init();
    Culture_Newsletter_Send::init();
    Culture_Subscribers::init();
    Culture_Newsletter_Lists_Admin::init();
    Culture_Campaigns_Admin::init();
    Culture_Campaign_Send::init();
    Culture_Games_Subscribers::init();
    Culture_NL_Analytics::init();
    Culture_NL_Analytics_Admin::init();
    Culture_Newsletter_Importer::init();
    Culture_Settings::init();
    Culture_Analytics::init();
    Culture_Email_Templates::init();
    Culture_Templates::init();
    Culture_Redirects::init();
    Culture_Event_RSVP::init();
    // Parent menus must be registered (via admin_menu hook) before any class
    // that adds a submenu under them — get_plugin_page_hookname() computes a
    // different hookname depending on whether $admin_page_hooks[$parent] is
    // already set, so a submenu registered before its parent gets the wrong
    // hookname and WP can't find its callback → 404.
    Culture_Content_Admin::init();   // parent: culture-content-manager
    Culture_Directory_Tools::init(); // submenu of culture-content-manager
    Culture_Clusters_Admin::init();
    Culture_Clusters_Admin::init_post_handlers();
    Culture_Hubs_Admin::init();
    Culture_Perks_Admin::init();
    Culture_Ticket_Payment::init();
    Culture_Community_RSVP_Payment::init();
    Culture_Flutterwave::init();
    Culture_Shop_Checkout::init();
    Culture_Services_Payment::init();
    Culture_Tickets_Admin::init();   // parent: culture-ticket-sales
    Culture_RSVP_Admin::init();      // submenu of culture-ticket-sales
    Culture_RSVP_Admin::init_post_handlers();
    Culture_Payouts_Admin::init();   // submenu of culture-ticket-sales
    Culture_Notifications::init();
    Culture_Follows::init();
    Culture_Directory_Follows::init();
    Culture_Hubs::init();
    Culture_Country_Cleanup::init();
    Culture_System_Author::init();
    Culture_Guest_Byline::init();
    Culture_Preview::init();
    Culture_Literary_Submissions::init();
    Culture_Magic_OTP::init();
    Culture_Memberships::init();

    // Register WP-CLI commands.
    if ( defined( 'WP_CLI' ) && WP_CLI ) {
        WP_CLI::add_command( 'culture', 'Culture_CLI' );
    }
}
add_action( 'init', 'culture_community_init', 5 );

// Initialize ACF fields immediately to catch acf/init hook correctly.
Culture_ACF_Fields::init();

/**
 * Enqueue frontend assets.
 */
function culture_community_enqueue_assets() {
    wp_enqueue_style(
        'culture-community',
        CULTURE_PLUGIN_URL . 'assets/css/culture-community.css',
        array(),
        CULTURE_VERSION
    );
    wp_enqueue_script(
        'culture-community',
        CULTURE_PLUGIN_URL . 'assets/js/culture-community.js',
        array( 'jquery' ),
        CULTURE_VERSION,
        true
    );
    wp_localize_script( 'culture-community', 'cultureData', array(
        'ajaxUrl'  => admin_url( 'admin-ajax.php' ),
        'restUrl'  => rest_url( 'culture/v1/' ),
        'nonce'    => wp_create_nonce( 'culture_nonce' ),
        'restNonce' => wp_create_nonce( 'wp_rest' ),
    ) );
}
add_action( 'wp_enqueue_scripts', 'culture_community_enqueue_assets' );

/* Settings page is now handled by Culture_Settings class (includes/admin/class-culture-settings.php). */

/**
 * Check if the current user can view a target user's phone number.
 *
 * Phone numbers are private. Only the user themselves and administrators may
 * see them. (The chapter-leader exception was removed June 2026 along with
 * the rest of the Chapter system — see CLAUDE.md.)
 *
 * @param int $target_user_id The user whose phone number is being viewed.
 * @return bool
 */
function culture_can_view_phone( $target_user_id ) {
    $current_user_id = get_current_user_id();

    if ( ! $current_user_id ) {
        return false;
    }

    // Users can always see their own phone number.
    if ( $current_user_id === (int) $target_user_id ) {
        return true;
    }

    // Administrators can see all phone numbers.
    if ( current_user_can( 'manage_options' ) ) {
        return true;
    }

    return false;
}
