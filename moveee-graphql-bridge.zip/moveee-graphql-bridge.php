<?php
/**
 * Plugin Name: Moveee GraphQL Bridge
 * Description: Bridges JetEngine taxonomies (industry, country, series) to WPGraphQL.
 * Version: 1.0.0
 * Author: Antigravity
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

add_filter( 'register_taxonomy_args', function( $args, $taxonomy ) {
    $taxonomies_to_bridge = [
        'industry' => [
            'single' => 'industry',
            'plural' => 'industries',
        ],
        'country' => [
            'single' => 'country',
            'plural' => 'countries',
        ],
        'series' => [
            'single' => 'seriesItem',
            'plural' => 'series',
        ],
    ];

    if ( array_key_exists( $taxonomy, $taxonomies_to_bridge ) ) {
        $args['show_in_graphql']     = true;
        $args['graphql_single_name'] = $taxonomies_to_bridge[$taxonomy]['single'];
        $args['graphql_plural_name'] = $taxonomies_to_bridge[$taxonomy]['plural'];
    }

    return $args;
}, 10, 2 );
